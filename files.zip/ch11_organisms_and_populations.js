/* ============================================================================
   BioArena — CHAPTER 11 : ORGANISMS AND POPULATIONS
   NCERT Class XII Biology (rationalised, Reprint 2026-27) — lebo111
   Schema-compliant with DATA.chapters.* (notes / mnemonics / flashcards /
   recall / mcqs / match / pathways / boss)
   ============================================================================ */

DATA.chapters.orgpop = {

  /* ---------- 1. METADATA ---------- */
  id: "orgpop",
  num: 11,
  title: "Organisms and Populations",
  subtitle: "Ecology · Population attributes · Growth models · Life-history variation · The six interspecific interactions",
  color: "#2ecc71",
  colorD: "#1e8449",
  glyph: "🌿",

  /* ---------- 2. STUDY NOTES (11 sections) ---------- */
  notes: [

    {
      id: "n1_scope",
      heading: "1. Ecology — Scope, Questions & Levels of Organisation",
      html: `
        <p><span class="kw">Ecology</span> is the study of the interactions <b>among organisms</b> and between <b>an organism and its physical (abiotic) environment</b>.</p>

        <h4>Two kinds of questions in biology</h4>
        <p>When you hear a bulbul singing, you can ask two very different things:</p>
        <table class="cmp">
          <thead><tr><th>Question type</th><th>What it seeks</th><th>Bulbul example</th></tr></thead>
          <tbody>
            <tr><td><b>"How-type"</b></td><td>The <span class="kw">mechanism</span> behind the process</td><td>How the voice box and vibrating bone operate</td></tr>
            <tr><td><b>"Why-type"</b></td><td>The <span class="kw">significance</span> of the process</td><td>The bird needs to communicate with its mate in the breeding season</td></tr>
          </tbody>
        </table>
        <div class="callout"><b>NEET trap:</b> "Why are night-blooming flowers generally white?" is a <b>why-type</b> (significance) question. "How does the bee know which flower has nectar?" is a <b>how-type</b> (mechanism) question.</div>

        <h4>Levels of biological organisation</h4>
        <div class="flow">
          <span class="node">Macromolecules</span><span class="arr">→</span>
          <span class="node">Cells</span><span class="arr">→</span>
          <span class="node">Tissues</span><span class="arr">→</span>
          <span class="node">Organs</span><span class="arr">→</span>
          <span class="node">Individual organisms</span><span class="arr">→</span>
          <span class="node">Populations</span><span class="arr">→</span>
          <span class="node">Communities</span><span class="arr">→</span>
          <span class="node">Ecosystems</span><span class="arr">→</span>
          <span class="node">Biomes</span>
        </div>

        <div class="callout"><b>HIGH-YIELD:</b> Ecology is concerned with <b>FOUR</b> levels of biological organisation — <span class="kw">organisms, populations, communities and biomes</span>. Note carefully: <b>"ecosystem" is NOT in NCERT's list of four.</b> This exact option is used as a distractor every year.</div>

        <h4>Ramdeo Misra (1908–1998) — Father of Ecology in India</h4>
        <ul>
          <li>Born <b>26 August 1908</b>; PhD in Ecology (<b>1937</b>) under <b>Prof. W. H. Pearsall, FRS</b>, at <b>Leeds University, UK</b>.</li>
          <li>Established ecology teaching &amp; research at the <b>Department of Botany, Banaras Hindu University (BHU), Varanasi</b>.</li>
          <li>Formulated the <b>first postgraduate course in ecology in India</b>; over <b>50 scholars</b> earned PhDs under him.</li>
          <li>Fellow of the <b>Indian National Science Academy</b> and the <b>World Academy of Arts and Science</b>; awarded the <b>Sanjay Gandhi Award</b> in Environment and Ecology.</li>
          <li>His efforts led to the <b>National Committee for Environmental Planning and Coordination (1972)</b>, which paved the way for the <b>Ministry of Environment and Forests (1984)</b>.</li>
        </ul>
      `
    },

    {
      id: "n2_attributes",
      heading: "2. Population & Population Attributes",
      html: `
        <h4>What is a population?</h4>
        <p>A <span class="kw">population</span> is a group of individuals of a species that live in a <b>well-defined geographical area</b>, <b>share or compete for similar resources</b>, and can <b>potentially interbreed</b>.</p>
        <div class="callout"><b>Subtlety:</b> Although "interbreeding" implies sexual reproduction, a group produced even by <b>asexual reproduction</b> is still treated as a population for ecological studies (e.g., bacteria in a culture plate).</div>

        <p><b>NCERT's five examples of a population:</b></p>
        <ul>
          <li>All the <b>cormorants</b> in a wetland</li>
          <li><b>Rats</b> in an abandoned dwelling</li>
          <li><b>Teakwood trees</b> in a forest tract</li>
          <li><b>Bacteria</b> in a culture plate</li>
          <li><b>Lotus plants</b> in a pond</li>
        </ul>

        <div class="callout"><b>Why population ecology matters:</b> An <b>individual</b> is what copes with a changed environment, but <b>natural selection operates at the population level</b> to evolve the desired traits. Population ecology therefore <b>links ecology to population genetics and evolution</b>.</div>

        <h4>Individual vs Population — what belongs to whom</h4>
        <table class="cmp">
          <thead><tr><th>An INDIVIDUAL has…</th><th>A POPULATION has…</th></tr></thead>
          <tbody>
            <tr><td>Births and deaths</td><td><b>Birth rates</b> and <b>death rates</b> (per capita)</td></tr>
            <tr><td>Is male <i>or</i> female</td><td><b>Sex ratio</b> (e.g., 60% females, 40% males)</td></tr>
            <tr><td>Has an age</td><td><b>Age distribution</b> → <b>age pyramid</b></td></tr>
            <tr><td>—</td><td><b>Population density (N)</b></td></tr>
          </tbody>
        </table>

        <h4>Birth rate &amp; death rate — the two worked examples</h4>
        <div class="callout">
          <b>Lotus (birth rate):</b> 20 lotus plants last year + 8 new plants → current population 28.<br>
          Birth rate = 8 / 20 = <b>0.4 offspring per lotus per year</b>.<br>
          <i>(Note the denominator is the ORIGINAL 20, not 28.)</i>
        </div>
        <div class="callout">
          <b>Fruitfly (death rate):</b> 4 individuals died out of a lab population of 40 in one week.<br>
          Death rate = 4 / 40 = <b>0.1 individuals per fruitfly per week</b>.
        </div>

        <h4>Age pyramids</h4>
        <p>Plotting the per cent of individuals in each age group (males and females) gives an <span class="kw">age pyramid</span>. Its <b>shape reveals the growth status</b>:</p>
        <table class="cmp">
          <thead><tr><th>Shape</th><th>Base</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td><b>Triangle / pyramid</b></td><td>Broad base, tapering top</td><td><b>Growing (expanding)</b> population</td></tr>
            <tr><td><b>Bell-shaped</b></td><td>Base ≈ middle</td><td><b>Stable</b> population</td></tr>
            <tr><td><b>Urn-shaped</b></td><td>Narrow base, bulging middle/top</td><td><b>Declining</b> population</td></tr>
          </tbody>
        </table>

        <h4>Population density (N) — how it is measured</h4>
        <p>Total number is <b>usually</b> the best measure, but not always:</p>
        <table class="cmp">
          <thead><tr><th>Measure</th><th>When to use it</th><th>NCERT example</th></tr></thead>
          <tbody>
            <tr><td><b>Total number</b></td><td>Default; countable populations</td><td>Cormorants in a wetland</td></tr>
            <tr><td><b>Per cent cover / biomass</b></td><td>When "number" is <b>meaningless</b> — a few huge organisms vs many tiny ones</td><td><b>200 carrot grass</b> (<i>Parthenium hysterophorus</i>) plants vs <b>1 huge banyan</b> with a large canopy</td></tr>
            <tr><td><b>Biomass / optical density</b></td><td>When counting is <b>impossible</b> or too time-consuming</td><td>A dense laboratory culture of bacteria in a petri dish</td></tr>
            <tr><td><b>Relative density</b></td><td>When absolute density is not needed</td><td><b>Number of fish caught per trap</b> in a lake</td></tr>
            <tr><td><b>Indirect estimation</b></td><td>When the animal cannot be seen/counted</td><td><b>Tiger census</b> from <b>pug marks and faecal pellets</b></td></tr>
          </tbody>
        </table>

        <div class="callout"><b>Extremes of population size:</b> as low as <b>&lt;10</b> (Siberian cranes at Bharatpur wetlands in any year) to <b>millions</b> (<i>Chlamydomonas</i> in a pond).</div>
      `
    },

    {
      id: "n3_growth_processes",
      heading: "3. Population Growth — The Four Basic Processes",
      html: `
        <p>Population density is <b>never static</b>. It fluctuates with food availability, predation pressure and adverse weather — and mechanically, through <b>four processes</b>:</p>

        <table class="cmp">
          <thead><tr><th>Process</th><th>Definition</th><th>Effect on density</th></tr></thead>
          <tbody>
            <tr><td><b>Natality (B)</b></td><td>Number of <b>births</b> during a given period, added to the initial density</td><td><b>Increase ▲</b></td></tr>
            <tr><td><b>Immigration (I)</b></td><td>Individuals <b>of the same species</b> that <b>come INTO</b> the habitat from elsewhere</td><td><b>Increase ▲</b></td></tr>
            <tr><td><b>Mortality (D)</b></td><td>Number of <b>deaths</b> during a given period</td><td><b>Decrease ▼</b></td></tr>
            <tr><td><b>Emigration (E)</b></td><td>Individuals of the population who <b>LEFT</b> the habitat and gone elsewhere</td><td><b>Decrease ▼</b></td></tr>
          </tbody>
        </table>

        <div class="callout"><b>THE EQUATION:</b><br>
          <b>N<sub>t+1</sub> = N<sub>t</sub> + [(B + I) &minus; (D + E)]</b><br><br>
          Density <b>rises</b> if (B + I) &gt; (D + E). Density <b>falls</b> if (D + E) &gt; (B + I).
        </div>

        <div class="flow">
          <span class="node">Natality ▲</span><span class="arr">+</span>
          <span class="node">Immigration ▲</span><span class="arr">→</span>
          <span class="node">POPULATION (N)</span><span class="arr">→</span>
          <span class="node">Mortality ▼</span><span class="arr">+</span>
          <span class="node">Emigration ▼</span>
        </div>

        <div class="callout"><b>Which factors dominate?</b> Under <b>normal conditions, births and deaths</b> are the most important. Immigration and emigration matter only under <b>special conditions</b> — e.g., when a <b>new habitat is just being colonised, immigration may contribute more than birth rate</b>.</div>
      `
    },

    {
      id: "n4_models",
      heading: "4. Growth Models — Exponential (J) vs Logistic (S)",
      html: `
        <h4>(i) Exponential / Geometric Growth — UNLIMITED resources</h4>
        <p>When food and space are <b>unlimited</b>, each species realises its <b>innate potential to grow</b> (as Darwin observed while developing natural selection). Growth is <span class="kw">exponential</span> and the curve is <b>J-shaped</b>.</p>

        <div class="callout">
          <b>dN/dt = (b &minus; d) &times; N</b><br>
          Let <b>(b &minus; d) = r</b> &nbsp;⇒&nbsp; <b>dN/dt = rN</b><br><br>
          <b>Integral form:&nbsp; N<sub>t</sub> = N<sub>0</sub> e<sup>rt</sup></b><br>
          N<sub>t</sub> = population density after time t<br>
          N<sub>0</sub> = population density at time zero<br>
          r = intrinsic rate of natural increase<br>
          e = base of natural logarithms = <b>2.71828</b>
        </div>

        <p><b>r</b> = <span class="kw">intrinsic rate of natural increase</span> — "a very important parameter chosen for assessing the impacts of any biotic or abiotic factor on population growth."</p>

        <table class="cmp">
          <thead><tr><th>Organism</th><th>r value</th></tr></thead>
          <tbody>
            <tr><td>Norway rat</td><td><b>0.015</b></td></tr>
            <tr><td>Human population of <b>India, 1981</b></td><td><b>0.0205</b></td></tr>
            <tr><td>Flour beetle</td><td><b>0.12</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Order low → high: Rat (0.015) &lt; India-1981 (0.0205) &lt; Flour beetle (0.12).</b> Remember <b>"R-I-B"</b> — ribs go up.</div>

        <p><b>The chessboard anecdote:</b> A minister bets the king one wheat grain on square 1, two on square 2, four on square 3, doubling across all <b>64 squares</b>. By the time the king covered <b>half the board</b>, all the wheat in his entire kingdom would still be inadequate. Now imagine one <i>Paramecium</i> doubling daily by binary fission for <b>64 days</b> (with unlimited food and space). <b>That is exponential growth.</b></p>
        <p>Darwin used the same logic to show that even a slow-breeding animal like the <b>elephant</b> could reach enormous numbers in the absence of checks.</p>

        <h4>(ii) Logistic Growth — LIMITED resources</h4>
        <p><b>No population in nature has unlimited resources.</b> Limited resources → competition → the "fittest" survive and reproduce. A habitat can support a <b>maximum possible number</b> beyond which no further growth occurs: <span class="kw">nature's carrying capacity (K)</span>.</p>

        <div class="flow">
          <span class="node">Lag phase</span><span class="arr">→</span>
          <span class="node">Acceleration</span><span class="arr">→</span>
          <span class="node">Deceleration</span><span class="arr">→</span>
          <span class="node">Asymptote (N = K)</span>
        </div>

        <div class="callout">
          <b>Verhulst&ndash;Pearl Logistic Growth:</b><br>
          <b>dN/dt = rN [ (K &minus; N) / K ]</b><br><br>
          N = population density at time t &nbsp;|&nbsp; r = intrinsic rate of natural increase &nbsp;|&nbsp; K = carrying capacity<br>
          Plot of N vs t = <b>sigmoid (S-shaped) curve</b>.
        </div>

        <h4>Head-to-head comparison</h4>
        <table class="cmp">
          <thead><tr><th>Feature</th><th>Exponential Growth</th><th>Logistic Growth</th></tr></thead>
          <tbody>
            <tr><td>Resources</td><td><b>Unlimited</b></td><td><b>Limited</b></td></tr>
            <tr><td>Equation</td><td>dN/dt = rN</td><td>dN/dt = rN[(K &minus; N)/K]</td></tr>
            <tr><td>Integral form</td><td>N<sub>t</sub> = N<sub>0</sub>e<sup>rt</sup></td><td>—</td></tr>
            <tr><td>Curve shape</td><td><b>J-shaped</b></td><td><b>S-shaped / sigmoid</b></td></tr>
            <tr><td>Phases</td><td>Continuous acceleration</td><td>Lag → Acceleration → Deceleration → Asymptote</td></tr>
            <tr><td>Carrying capacity</td><td>Not considered</td><td><b>K is central</b></td></tr>
            <tr><td>Competition</td><td>Absent</td><td>Present</td></tr>
            <tr><td>Also called</td><td>Geometric growth</td><td><b>Verhulst&ndash;Pearl</b> growth</td></tr>
            <tr><td>Realism</td><td>Unrealistic long-term</td><td><b>More realistic</b> (resources are finite)</td></tr>
          </tbody>
        </table>

        <div class="callout"><b>Reading the logistic equation like a pro:</b>
          <ul>
            <li>When <b>N is tiny compared to K</b>, the term (K&minus;N)/K ≈ 1 → dN/dt ≈ rN → it <b>behaves exponentially</b>.</li>
            <li>When <b>N = K</b>, (K&minus;N)/K = 0 → <b>dN/dt = 0</b> → growth stops (asymptote).</li>
            <li>When <b>N &gt; K</b>, the bracket becomes <b>negative</b> → population <b>declines</b> back toward K.</li>
            <li>Growth rate is <b>maximum at N = K/2</b> (the inflection point of the S-curve).</li>
          </ul>
        </div>
      `
    },

    {
      id: "n5_lifehistory",
      heading: "5. Life History Variation",
      html: `
        <p>Populations evolve to maximise their <span class="kw">reproductive fitness</span>, also called <span class="kw">Darwinian fitness</span> — i.e., a <b>high r value</b> — in the habitat where they live. Under a given set of selection pressures, organisms evolve towards the <b>most efficient reproductive strategy</b>.</p>

        <table class="cmp">
          <thead><tr><th>Trade-off axis</th><th>Strategy A</th><th>Strategy B</th></tr></thead>
          <tbody>
            <tr>
              <td><b>How often to breed</b></td>
              <td>Breed <b>only ONCE</b> in a lifetime<br><i>Examples:</i> <b>Pacific salmon fish, Bamboo</b></td>
              <td>Breed <b>MANY times</b> in a lifetime<br><i>Examples:</i> <b>most birds and mammals</b></td>
            </tr>
            <tr>
              <td><b>Offspring size vs number</b></td>
              <td><b>Large number of small-sized</b> offspring<br><i>Examples:</i> <b>Oysters, pelagic fishes</b></td>
              <td><b>Small number of large-sized</b> offspring<br><i>Examples:</i> <b>birds, mammals</b></td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>The point NCERT actually makes:</b> There is <b>no single "best" strategy</b>. Life-history traits have evolved <b>in relation to the constraints imposed by the abiotic AND biotic components of the habitat</b> in which the organism lives. This is currently an active area of research in ecology.</div>
      `
    },

    {
      id: "n6_interactions_table",
      heading: "6. Population Interactions — The Master Table (Table 11.1)",
      html: `
        <p>No habitat on earth is inhabited by a single species. Even a plant that makes its own food needs <b>soil microbes</b> to break down organic matter and return inorganic nutrients, and an <b>animal agent</b> for pollination. Species must interact — forming a <b>biological community</b>.</p>

        <p><span class="kw">Interspecific interactions</span> arise from populations of <b>two different species</b>. Assign <b>+</b> = beneficial, <b>&minus;</b> = detrimental, <b>0</b> = neutral:</p>

        <table class="cmp">
          <thead><tr><th>Species A</th><th>Species B</th><th>Name of Interaction</th><th>One-line memory hook</th></tr></thead>
          <tbody>
            <tr><td><b>+</b></td><td><b>+</b></td><td><b>Mutualism</b></td><td>Both win</td></tr>
            <tr><td><b>&minus;</b></td><td><b>&minus;</b></td><td><b>Competition</b></td><td>Both lose</td></tr>
            <tr><td><b>+</b></td><td><b>&minus;</b></td><td><b>Predation</b></td><td>Predator profits, prey pays</td></tr>
            <tr><td><b>+</b></td><td><b>&minus;</b></td><td><b>Parasitism</b></td><td>Parasite profits, host pays</td></tr>
            <tr><td><b>+</b></td><td><b>0</b></td><td><b>Commensalism</b></td><td>One gains, other doesn't care</td></tr>
            <tr><td><b>&minus;</b></td><td><b>0</b></td><td><b>Amensalism</b></td><td>One is harmed, other doesn't care</td></tr>
          </tbody>
        </table>

        <div class="callout"><b>HIGH-YIELD:</b> <b>Predation, parasitism and commensalism share a common characteristic</b> — the interacting species <b>live closely together</b>. (Mutualism, competition and amensalism are not defined by close physical association in NCERT's framing.)</div>

        <div class="callout"><b>Amensalism note:</b> NCERT lists amensalism in Table 11.1 (&minus;, 0) but gives <b>no example</b>. The classic textbook example is <i>Penicillium</i> secreting penicillin that kills bacteria, while <i>Penicillium</i> itself is unaffected.</div>
      `
    },

    {
      id: "n7_predation",
      heading: "7. Predation ( + , − )",
      html: `
        <p>Think of predation as <b>nature's way of transferring the energy fixed by plants to higher trophic levels</b>. It is not just tiger-and-deer: <b>a sparrow eating a seed is no less a predator</b>. <b>Herbivores</b>, though categorised separately, are <b>in a broad ecological context not very different from predators</b> — for plants, herbivores ARE the predators.</p>

        <h4>Four ecological roles of predators</h4>
        <ol>
          <li><b>Conduits for energy transfer</b> across trophic levels.</li>
          <li><b>Keep prey populations under control.</b> Without predators, prey could reach very high densities and cause <b>ecosystem instability</b>.</li>
          <li><b>Basis of biological control</b> in agricultural pest management.</li>
          <li><b>Maintain species diversity</b> in a community by <b>reducing the intensity of competition among competing prey species</b>.</li>
        </ol>

        <h4>Case 1 — Prickly pear cactus in Australia (invasive species)</h4>
        <div class="flow">
          <span class="node">Prickly pear introduced into Australia, early 1920s</span><span class="arr">→</span>
          <span class="node">No natural predator in invaded land</span><span class="arr">→</span>
          <span class="node">Spreads over millions of hectares of rangeland</span><span class="arr">→</span>
          <span class="node">Cactus-feeding MOTH introduced from its natural habitat</span><span class="arr">→</span>
          <span class="node">Cactus brought under control</span>
        </div>
        <p><b>Lesson:</b> Exotic species become <b>invasive</b> precisely because <b>the invaded land lacks their natural predators</b>.</p>

        <h4>Case 2 — Pisaster starfish (predator maintains diversity)</h4>
        <ul>
          <li>Habitat: <b>rocky intertidal communities of the American Pacific Coast</b>.</li>
          <li>Predator: the starfish <b><i>Pisaster</i></b>.</li>
          <li>Experiment: all starfish were <b>removed</b> from an enclosed intertidal area.</li>
          <li>Result: <b>more than 10 species of invertebrates became extinct within a year</b>.</li>
          <li>Cause of extinction: <b>interspecific competition</b> — with the predator gone, superior competitors wiped out the rest.</li>
        </ul>

        <h4>Why predators are 'prudent'</h4>
        <div class="callout">If a predator is <b>too efficient and overexploits its prey</b>, the prey may go extinct — and the predator follows, <b>for lack of food</b>. Natural selection therefore favours <b>prudent</b> predators.</div>

        <h4>Prey defences (animals)</h4>
        <ul>
          <li><b>Cryptic colouration / camouflage</b> — some insects and frogs, to avoid detection.</li>
          <li><b>Being poisonous</b> — and therefore avoided.</li>
          <li><b>Monarch butterfly</b> — highly <b>distasteful</b> to its bird predator because of a <b>special chemical</b> in its body. <b>It acquires this chemical during its CATERPILLAR stage by feeding on a poisonous weed.</b> (It does not make the chemical itself.)</li>
        </ul>

        <h4>Plant defences against herbivory</h4>
        <p>Plants have it worse than animals — <b>they cannot run away</b>. Nearly <b>25 per cent of all insects are phytophagous</b> (feeding on plant sap and other plant parts).</p>
        <table class="cmp">
          <thead><tr><th>Type of defence</th><th>Mechanism</th><th>Examples</th></tr></thead>
          <tbody>
            <tr><td><b>Morphological</b></td><td>Physical deterrent</td><td><b>Thorns</b> — <i>Acacia</i>, <i>Cactus</i> (most common morphological means)</td></tr>
            <tr><td><b>Chemical</b></td><td>Make the herbivore sick, inhibit feeding or digestion, disrupt reproduction, or kill</td><td><b><i>Calotropis</i></b> produces highly poisonous <b>cardiac glycosides</b> — which is why cattle and goats never browse it</td></tr>
            <tr><td><b>Chemical (commercial)</b></td><td>Extracted by humans at commercial scale, but evolved as <b>anti-herbivore defences</b></td><td><b>Nicotine, Caffeine, Quinine, Strychnine, Opium</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Mnemonic:</b> "<b>N</b>ice <b>C</b>ats <b>Q</b>uietly <b>S</b>teal <b>O</b>pium" → Nicotine, Caffeine, Quinine, Strychnine, Opium.</div>
      `
    },

    {
      id: "n8_competition",
      heading: "8. Competition ( − , − )",
      html: `
        <p>Darwin was convinced that <b>interspecific competition is a potent force in organic evolution</b> ("struggle for existence", "survival of the fittest").</p>

        <h4>Two myths NCERT explicitly busts</h4>
        <table class="cmp">
          <thead><tr><th>Common belief</th><th>Reality</th><th>Evidence</th></tr></thead>
          <tbody>
            <tr>
              <td>Only <b>closely related</b> species compete</td>
              <td><b>False.</b> <b>Totally unrelated</b> species can compete</td>
              <td>In some <b>shallow South American lakes</b>, visiting <b>flamingoes</b> and resident <b>fishes</b> compete for their common food, <b>zooplankton</b></td>
            </tr>
            <tr>
              <td>Resources must be <b>limiting</b> for competition</td>
              <td><b>False.</b> Competition can occur even with abundant resources</td>
              <td><b>Interference competition</b> — the feeding efficiency of one species is reduced by the <b>interfering and inhibitory presence</b> of another</td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>Best definition of competition:</b> a process in which the <b>fitness of one species (measured as its 'r', the intrinsic rate of increase) is significantly LOWER in the presence of another species</b>.</div>

        <h4>Gause's Competitive Exclusion Principle</h4>
        <p><b>Two closely related species competing for the same resources cannot co-exist indefinitely; the competitively inferior one is eliminated eventually.</b></p>
        <p>This holds <b>if resources are limiting</b>, but <b>not otherwise</b>. More recent studies do not support such gross generalisations — species facing competition may <b>evolve mechanisms that promote co-existence rather than exclusion</b>.</p>

        <h4>Field evidence — the three named cases</h4>
        <table class="cmp">
          <thead><tr><th>Case</th><th>Location</th><th>What happened</th><th>Concept</th></tr></thead>
          <tbody>
            <tr>
              <td><b>Abingdon tortoise</b></td>
              <td><b>Galapagos Islands</b></td>
              <td>Became <b>extinct within a decade</b> after <b>goats</b> were introduced, apparently due to the <b>greater browsing efficiency of the goats</b></td>
              <td>Competitive exclusion in nature</td>
            </tr>
            <tr>
              <td><b>Connell's barnacles</b></td>
              <td><b>Rocky sea coasts of Scotland</b></td>
              <td>The larger, competitively superior barnacle <b><i>Balanus</i></b> dominates the intertidal area and <b>excludes the smaller <i>Chthamalus</i></b> from that zone</td>
              <td>Competitive exclusion</td>
            </tr>
            <tr>
              <td><b>MacArthur's warblers</b></td>
              <td>Same tree</td>
              <td><b>Five closely related species of warblers</b> co-existed by <b>behavioural differences in their foraging activities</b></td>
              <td><b>Resource partitioning</b></td>
            </tr>
          </tbody>
        </table>

        <h4>Competitive release</h4>
        <div class="callout">A species whose distribution is <b>restricted to a small geographical area</b> because of a <b>competitively superior species</b> <b>expands its range dramatically</b> when the competitor is <b>experimentally removed</b>. This is evidence that competition was operating in nature.</div>

        <h4>Resource partitioning</h4>
        <p>If two species compete for the same resource, they can <b>avoid competition</b> by choosing <b>different times for feeding</b> or <b>different foraging patterns</b>. This promotes co-existence instead of exclusion.</p>

        <div class="callout"><b>HIGH-YIELD:</b> In general, <b>herbivores and plants appear to be MORE adversely affected by competition than carnivores</b>.</div>
      `
    },

    {
      id: "n9_parasitism",
      heading: "9. Parasitism ( + , − )",
      html: `
        <p>The parasitic mode of life ensures <b>free lodging and free meals</b> — no surprise it has evolved in so many taxonomic groups, from plants to higher vertebrates.</p>

        <h4>Host specificity and co-evolution</h4>
        <p>Many parasites are <b>host-specific</b> (can parasitise only a single host species), so <b>host and parasite co-evolve</b>: if the host evolves a way to reject or resist the parasite, the parasite must evolve a counter-mechanism to stay successful with the same host.</p>

        <h4>Parasitic adaptations — LOSE 2, GAIN 2</h4>
        <table class="cmp">
          <thead><tr><th>LOST (no longer needed)</th><th>GAINED (needed for parasitic life)</th></tr></thead>
          <tbody>
            <tr><td><b>Unnecessary sense organs</b></td><td><b>Adhesive organs or suckers</b> to cling to the host</td></tr>
            <tr><td><b>Digestive system</b></td><td><b>High reproductive capacity</b></td></tr>
          </tbody>
        </table>

        <h4>Complex life cycles</h4>
        <table class="cmp">
          <thead><tr><th>Parasite</th><th>Intermediate host / vector</th><th>Note</th></tr></thead>
          <tbody>
            <tr><td><b>Human liver fluke</b> (a trematode)</td><td><b>TWO intermediate hosts: a snail and a fish</b></td><td>Needed to complete its life cycle</td></tr>
            <tr><td><b>Malarial parasite</b></td><td><b>Vector: mosquito</b></td><td>Needed to spread to other hosts</td></tr>
          </tbody>
        </table>

        <h4>Effect on the host</h4>
        <p>The majority of parasites <b>harm</b> the host — they may <b>reduce survival, growth and reproduction</b>, <b>reduce the host's population density</b>, and <b>render the host more vulnerable to predation by making it physically weak</b>.</p>

        <h4>Ectoparasites vs Endoparasites</h4>
        <table class="cmp">
          <thead><tr><th>Feature</th><th>Ectoparasite</th><th>Endoparasite</th></tr></thead>
          <tbody>
            <tr><td>Site</td><td>On the <b>external surface</b> of the host</td><td><b>Inside the host body</b> (liver, kidney, lungs, RBCs…)</td></tr>
            <tr><td>Life cycle</td><td>Simpler</td><td><b>More complex</b>, due to extreme specialisation</td></tr>
            <tr><td>Morphology / anatomy</td><td>Less reduced</td><td><b>Greatly simplified</b></td></tr>
            <tr><td>Reproductive potential</td><td>High</td><td><b>Strongly emphasised / very high</b></td></tr>
            <tr><td>Examples</td><td><b>Lice on humans</b>; <b>ticks on dogs</b>; <b>copepods on marine fish</b>; <b><i>Cuscuta</i></b> on hedge plants</td><td>Malarial parasite, liver fluke, tapeworm</td></tr>
          </tbody>
        </table>

        <div class="callout"><b><i>Cuscuta</i> (dodder):</b> A <b>parasitic plant</b> commonly found on hedge plants. In the course of evolution it has <b>LOST its chlorophyll AND its leaves</b>, and derives its nutrition from the host plant.</div>

        <div class="callout"><b>NCERT's classic question:</b> Why is the <b>female mosquito NOT considered a parasite</b>, even though it needs our blood?<br>
        <b>Because it does not live in or on the host.</b> It takes a brief blood meal and leaves — it neither derives lodging from the host nor establishes a lasting association. Ecologically it is a <b>micro-predator</b>, not a parasite.</div>

        <h4>Brood parasitism</h4>
        <div class="flow">
          <span class="node">Parasitic bird (cuckoo / koel)</span><span class="arr">→</span>
          <span class="node">Lays eggs in HOST's nest (crow)</span><span class="arr">→</span>
          <span class="node">Eggs evolved to RESEMBLE host's eggs in SIZE and COLOUR</span><span class="arr">→</span>
          <span class="node">Host cannot detect and eject them</span><span class="arr">→</span>
          <span class="node">Host incubates and rears the parasite's chicks</span>
        </div>
        <p>Best observed in your neighbourhood park in the <b>breeding season (spring to summer)</b> — watch the <b>cuckoo (koel)</b> and the <b>crow</b>.</p>
      `
    },

    {
      id: "n10_comm_mut",
      heading: "10. Commensalism ( + , 0 ) and Mutualism ( + , + )",
      html: `
        <h4>Commensalism — one benefits, the other is neither harmed nor benefited</h4>
        <table class="cmp">
          <thead><tr><th>Pair</th><th>Who benefits</th><th>How</th></tr></thead>
          <tbody>
            <tr><td><b>Orchid on a mango branch</b></td><td>Orchid (an <b>epiphyte</b>)</td><td>Gets support/position; the mango tree derives no apparent benefit and no harm</td></tr>
            <tr><td><b>Barnacles on a whale's back</b></td><td>Barnacles</td><td>Get transport and feeding opportunities; the whale is unaffected</td></tr>
            <tr><td><b>Cattle egret &amp; grazing cattle</b></td><td>Egret</td><td>As the cattle move, they <b>stir up and flush out insects</b> from the vegetation that the egret would otherwise struggle to find and catch</td></tr>
            <tr><td><b>Clown fish &amp; sea anemone</b></td><td>Clown fish</td><td>Lives among the <b>stinging tentacles</b> and gets <b>protection from predators</b>; the anemone gets no apparent benefit</td></tr>
          </tbody>
        </table>

        <h4>Mutualism — both species benefit</h4>
        <table class="cmp">
          <thead><tr><th>Partnership</th><th>Partners</th><th>Exchange</th></tr></thead>
          <tbody>
            <tr><td><b>Lichen</b></td><td>A <b>fungus</b> + <b>photosynthesising algae or cyanobacteria</b></td><td>An intimate mutualistic relationship</td></tr>
            <tr><td><b>Mycorrhiza</b></td><td><b>Fungi</b> + <b>roots of higher plants</b></td><td>Fungus helps the plant <b>absorb essential nutrients from soil</b>; plant gives the fungus <b>energy-yielding carbohydrates</b></td></tr>
            <tr><td><b>Plant–pollinator</b></td><td>Plants + animals</td><td>Plants pay a "fee": <b>pollen and nectar</b> for pollinators, <b>juicy nutritious fruits</b> for seed dispersers</td></tr>
          </tbody>
        </table>

        <div class="callout"><b>The "cheater" problem:</b> A mutually beneficial system must be <b>safeguarded against cheaters</b> — e.g., animals that <b>steal nectar without aiding pollination</b>.</div>

        <h4>Fig &amp; wasp — the one-to-one masterpiece (Figure 11.4)</h4>
        <div class="flow">
          <span class="node">Female wasp searches for an egg-laying site</span><span class="arr">→</span>
          <span class="node">Enters the fig inflorescence</span><span class="arr">→</span>
          <span class="node">POLLINATES the fig while searching</span><span class="arr">→</span>
          <span class="node">Uses the fruit as OVIPOSITION site</span><span class="arr">→</span>
          <span class="node">Fig offers some developing SEEDS as food for wasp larvae</span><span class="arr">→</span>
          <span class="node">New wasps emerge, carry pollen to the next fig</span>
        </div>
        <ul>
          <li>In many fig species there is a <b>tight one-to-one relationship</b> with the pollinator wasp species — <b>a given fig species can be pollinated ONLY by its 'partner' wasp species and no other</b>.</li>
          <li>The female wasp uses the fruit <b>both</b> as an oviposition (egg-laying) site <b>and</b> as a nursery: developing seeds within the fruit <b>nourish its larvae</b>.</li>
          <li>This is <b>co-evolution</b> — the evolution of the flower and its pollinator are <b>tightly linked</b>.</li>
        </ul>

        <h4>Orchids &amp; the Mediterranean <i>Ophrys</i> — 'sexual deceit' (Figure 11.5)</h4>
        <p>Orchids show a bewildering diversity of floral patterns, many evolved to attract the right pollinator insect (<b>bees and bumblebees</b>). <b>Not all orchids offer rewards.</b></p>
        <div class="flow">
          <span class="node">One petal of Ophrys mimics the FEMALE BEE in size, colour and markings</span><span class="arr">→</span>
          <span class="node">Male bee is attracted</span><span class="arr">→</span>
          <span class="node">'PSEUDOCOPULATES' with the flower</span><span class="arr">→</span>
          <span class="node">Gets dusted with pollen</span><span class="arr">→</span>
          <span class="node">Pseudocopulates with ANOTHER flower</span><span class="arr">→</span>
          <span class="node">Pollen transferred — pollination achieved</span>
        </div>
        <div class="callout"><b>Co-evolution proof:</b> If the <b>female bee's colour patterns change even slightly</b> during evolution, <b>pollination success will drop</b> — <b>unless the orchid flower co-evolves</b> to maintain the resemblance of its petal to the female bee.</div>
      `
    },

    {
      id: "n11_cheatsheet",
      heading: "11. Cheat Sheet — Every Formula, Name & Number",
      html: `
        <h4>Formula bank</h4>
        <table class="cmp">
          <thead><tr><th>Concept</th><th>Formula</th></tr></thead>
          <tbody>
            <tr><td>Density change</td><td><b>N<sub>t+1</sub> = N<sub>t</sub> + [(B + I) &minus; (D + E)]</b></td></tr>
            <tr><td>Intrinsic rate of natural increase</td><td><b>r = b &minus; d</b></td></tr>
            <tr><td>Exponential growth (differential)</td><td><b>dN/dt = (b &minus; d)N = rN</b></td></tr>
            <tr><td>Exponential growth (integral)</td><td><b>N<sub>t</sub> = N<sub>0</sub> e<sup>rt</sup></b>, e = 2.71828</td></tr>
            <tr><td>Logistic growth</td><td><b>dN/dt = rN [(K &minus; N)/K]</b></td></tr>
            <tr><td>Doubling time (exponential)</td><td>t = ln 2 / r = <b>0.693 / r</b></td></tr>
            <tr><td>Fastest logistic growth</td><td>at <b>N = K/2</b></td></tr>
          </tbody>
        </table>

        <h4>Named-organism bank (learn these cold — NEET loves them)</h4>
        <table class="cmp">
          <thead><tr><th>Name</th><th>What it is</th><th>Concept it proves</th></tr></thead>
          <tbody>
            <tr><td><i>Parthenium hysterophorus</i></td><td>Carrot grass</td><td>Number vs per cent cover (density measure)</td></tr>
            <tr><td><i>Chlamydomonas</i></td><td>Alga in a pond</td><td>Population size in millions</td></tr>
            <tr><td>Siberian crane (Bharatpur)</td><td>Migratory bird</td><td>Population size &lt; 10</td></tr>
            <tr><td><i>Paramecium</i></td><td>Ciliate, binary fission</td><td>Exponential growth in 64 days</td></tr>
            <tr><td>Pacific salmon, Bamboo</td><td>Breed once in lifetime</td><td>Life-history variation</td></tr>
            <tr><td>Oysters, pelagic fishes</td><td>Many small offspring</td><td>Life-history variation</td></tr>
            <tr><td>Prickly pear cactus + moth</td><td>Australia, early <b>1920s</b></td><td>Invasive species &amp; biological control</td></tr>
            <tr><td><i>Pisaster</i></td><td>Starfish, American Pacific Coast</td><td>Predator maintains species diversity (&gt;10 invertebrates lost)</td></tr>
            <tr><td>Monarch butterfly</td><td>Distasteful to birds</td><td>Chemical acquired as a <b>caterpillar</b> from a poisonous weed</td></tr>
            <tr><td><i>Acacia</i>, <i>Cactus</i></td><td>Thorns</td><td>Morphological anti-herbivore defence</td></tr>
            <tr><td><i>Calotropis</i></td><td>Cardiac glycosides</td><td>Chemical anti-herbivore defence</td></tr>
            <tr><td>Flamingoes + fishes</td><td>Shallow South American lakes, eat zooplankton</td><td><b>Unrelated</b> species compete</td></tr>
            <tr><td>Abingdon tortoise + goats</td><td>Galapagos Islands</td><td>Competitive exclusion (extinct in a decade)</td></tr>
            <tr><td><i>Balanus</i> vs <i>Chthamalus</i></td><td>Barnacles, rocky coasts of <b>Scotland</b> (Connell)</td><td>Competitive exclusion</td></tr>
            <tr><td>5 warbler species (MacArthur)</td><td>Same tree</td><td><b>Resource partitioning</b></td></tr>
            <tr><td>Human liver fluke</td><td>Trematode; snail + fish</td><td>Two intermediate hosts</td></tr>
            <tr><td><i>Cuscuta</i></td><td>Parasitic plant on hedge plants</td><td>Lost chlorophyll and leaves</td></tr>
            <tr><td>Cuckoo (koel) &amp; crow</td><td>Egg mimicry</td><td>Brood parasitism</td></tr>
            <tr><td>Cattle egret &amp; cattle; clown fish &amp; anemone; orchid on mango; barnacle on whale</td><td>Four commensal pairs</td><td>Commensalism</td></tr>
            <tr><td>Lichen; mycorrhiza; fig–wasp; <i>Ophrys</i>–bee</td><td>Four mutualistic/co-evolved pairs</td><td>Mutualism &amp; co-evolution</td></tr>
          </tbody>
        </table>

        <h4>Number bank</h4>
        <ul>
          <li>Ecology deals with <b>4</b> levels of biological organisation</li>
          <li>Lotus birth rate: <b>8/20 = 0.4</b> offspring per lotus per year</li>
          <li>Fruitfly death rate: <b>4/40 = 0.1</b> individuals per fruitfly per week</li>
          <li><b>200</b> carrot grass plants vs <b>1</b> banyan</li>
          <li>r: Norway rat <b>0.015</b> | India 1981 <b>0.0205</b> | Flour beetle <b>0.12</b></li>
          <li>e = <b>2.71828</b></li>
          <li>Chessboard = <b>64</b> squares; <i>Paramecium</i> = <b>64</b> days</li>
          <li>Prickly pear into Australia: <b>early 1920s</b></li>
          <li><i>Pisaster</i> removal: <b>&gt;10</b> invertebrate species extinct <b>within a year</b></li>
          <li><b>~25%</b> of all insects are phytophagous</li>
          <li>Abingdon tortoise: extinct <b>within a decade</b> of goat introduction</li>
          <li>MacArthur: <b>5</b> warbler species on the <b>same tree</b></li>
          <li>Human liver fluke: <b>2</b> intermediate hosts</li>
          <li>Ramdeo Misra: born <b>1908</b>, PhD <b>1937</b>, NCEPC <b>1972</b>, MoEF <b>1984</b>, <b>50+</b> PhD scholars</li>
        </ul>
      `
    }
  ],

  /* ---------- 3. MNEMONICS (14) ---------- */
  mnemonics: [
    {
      title: "The Four Growth Processes — 'NI up, ME down'",
      device: `<b>N</b>atality + <b>I</b>mmigration go <b>UP</b> ▲ &nbsp;|&nbsp; <b>M</b>ortality + <b>E</b>migration go <b>DOWN</b> ▼`,
      expand: [
        { L: "N", t: "Natality — births ADDED. Increases density." },
        { L: "I", t: "Immigration — same-species individuals coming IN. Increases density." },
        { L: "M", t: "Mortality — deaths. Decreases density." },
        { L: "E", t: "Emigration — individuals leaving (think: 'ME, I'm leaving'). Decreases density." },
        { L: "★", t: "Equation: N(t+1) = N(t) + [(B + I) − (D + E)]" }
      ]
    },
    {
      title: "Interaction Signs — 'My Cat Prefers Pretty Cute Animals'",
      device: `<b>M</b>utualism · <b>C</b>ompetition · <b>P</b>redation · <b>P</b>arasitism · <b>C</b>ommensalism · <b>A</b>mensalism (exact NCERT Table 11.1 order)`,
      expand: [
        { L: "M", t: "Mutualism (+ +) — Mutual gain. Both win." },
        { L: "C", t: "Competition (− −) — Crash together. Both lose." },
        { L: "P", t: "Predation (+ −) — Predator Profits, prey Pays." },
        { L: "P", t: "Parasitism (+ −) — Parasite Profits, host Pays." },
        { L: "C", t: "Commensalism (+ 0) — one gains, other is Carefree." },
        { L: "A", t: "Amensalism (− 0) — one is Attacked, other is Apathetic." },
        { L: "0", t: "A ZERO always means 'unaffected'. Commensalism has a happy +0; amensalism has a sad −0." }
      ]
    },
    {
      title: "Logistic Phases — 'LADA' (the car that parks at K)",
      device: `<b>L</b>ag → <b>A</b>cceleration → <b>D</b>eceleration → <b>A</b>symptote`,
      expand: [
        { L: "L", t: "Lag — slow start, few individuals." },
        { L: "A", t: "Acceleration — resources still ample, growth speeds up." },
        { L: "D", t: "Deceleration — resources becoming limiting, growth slows." },
        { L: "A", t: "Asymptote — N = K (carrying capacity), dN/dt = 0. The car parks." },
        { L: "★", t: "Named the Verhulst–Pearl Logistic Growth. Curve = sigmoid / S-shaped." }
      ]
    },
    {
      title: "Parasite Adaptations — 'Lose 2 S's, Gain 2 S's'",
      device: `<b>LOSE:</b> Sense organs + Stomach (digestive system) &nbsp;|&nbsp; <b>GAIN:</b> Suckers + Spawn (high reproductive capacity)`,
      expand: [
        { L: "−", t: "LOST: unnecessary sense organs (no need to hunt or navigate)." },
        { L: "−", t: "LOST: digestive system (host's digested food is absorbed directly)." },
        { L: "+", t: "GAINED: adhesive organs / suckers to cling to the host." },
        { L: "+", t: "GAINED: high reproductive capacity (chances of finding a new host are low)." }
      ]
    },
    {
      title: "Commercial Plant Chemicals — 'Nice Cats Quietly Steal Opium'",
      device: `<b>N</b>icotine · <b>C</b>affeine · <b>Q</b>uinine · <b>S</b>trychnine · <b>O</b>pium`,
      expand: [
        { L: "N", t: "Nicotine" },
        { L: "C", t: "Caffeine" },
        { L: "Q", t: "Quinine" },
        { L: "S", t: "Strychnine" },
        { L: "O", t: "Opium" },
        { L: "★", t: "All are extracted commercially by humans, BUT plants evolved them as chemical defences against grazers and browsers." }
      ]
    },
    {
      title: "The Ecologists — 'Gause Cuts, Connell Crowds, MacArthur Manages, Verhulst-Pearl Plateaus'",
      device: `<b>G</b>ause · <b>C</b>onnell · <b>M</b>acArthur · <b>V</b>erhulst–<b>P</b>earl`,
      expand: [
        { L: "G", t: "Gause — Competitive Exclusion Principle. The inferior competitor is CUT out." },
        { L: "C", t: "Connell — Scotland's rocky coasts; Balanus CROWDS OUT Chthamalus from the intertidal zone." },
        { L: "M", t: "MacArthur — 5 warbler species on one tree MANAGE to co-exist via resource partitioning." },
        { L: "V-P", t: "Verhulst–Pearl — Logistic growth; the curve PLATEAUS at K." },
        { L: "★", t: "Bonus: Ramdeo Misra = Father of Ecology in India. Darwin = 'struggle for existence'." }
      ]
    },
    {
      title: "Age Pyramids — 'Triangle Grows, Bell Holds, Urn Goes'",
      device: `<b>T</b>riangle = growing &nbsp;|&nbsp; <b>B</b>ell = stable &nbsp;|&nbsp; <b>U</b>rn = declining`,
      expand: [
        { L: "T", t: "TRIANGLE (broad base, tapering top) → GROWING / expanding population. Lots of young." },
        { L: "B", t: "BELL (base ≈ middle) → STABLE population. Births balance deaths." },
        { L: "U", t: "URN (narrow base, bulging top) → DECLINING population. Few young, many old." }
      ]
    },
    {
      title: "Density Measures — 'NBC Radio counts the crowd'",
      device: `<b>N</b>umber · <b>B</b>iomass · <b>C</b>over (per cent) · <b>R</b>elative density`,
      expand: [
        { L: "N", t: "Total Number — the usual, most appropriate measure." },
        { L: "B", t: "Biomass — for a huge banyan vs 200 carrot grass plants; or a dense bacterial culture." },
        { L: "C", t: "Per cent Cover — same banyan/carrot grass logic." },
        { L: "R", t: "Relative density — e.g., number of fish caught per trap. No need for absolute numbers." },
        { L: "★", t: "Plus INDIRECT estimation: tiger census from pug marks and faecal pellets." }
      ]
    },
    {
      title: "Life History — 'Salmon and Bamboo die after their big day'",
      device: `Breed <b>ONCE</b>: Pacific <b>Salmon</b>, <b>Bamboo</b> &nbsp;|&nbsp; Breed <b>MANY</b> times: most birds &amp; mammals`,
      expand: [
        { L: "1", t: "Breed once in a lifetime → Pacific salmon fish, Bamboo." },
        { L: "∞", t: "Breed many times → most birds and mammals." },
        { L: "Many-small", t: "Large number of SMALL offspring → Oysters, pelagic fishes. ('Small fry come in shoals.')" },
        { L: "Few-large", t: "Small number of LARGE offspring → birds, mammals. ('Big babies come in singles.')" },
        { L: "★", t: "Reproductive fitness = DARWINIAN fitness = high r value." }
      ]
    },
    {
      title: "r Values — 'R-I-B goes up'",
      device: `<b>R</b>at (0.015) &lt; <b>I</b>ndia 1981 (0.0205) &lt; <b>B</b>eetle (0.12)`,
      expand: [
        { L: "R", t: "Norway rat — r = 0.015" },
        { L: "I", t: "Human population of India in 1981 — r = 0.0205" },
        { L: "B", t: "Flour beetle — r = 0.12 (the largest of the three)" },
        { L: "★", t: "r = intrinsic rate of natural increase = b − d." }
      ]
    },
    {
      title: "Curve Shapes — 'J before S'",
      device: `<b>J</b> = <b>J</b>ackpot resources (unlimited, exponential) &nbsp;|&nbsp; <b>S</b> = <b>S</b>queezed by K (limited, logistic)`,
      expand: [
        { L: "J", t: "J-shaped = exponential = unlimited resources = dN/dt = rN. Unrealistic long-term." },
        { L: "S", t: "S-shaped (sigmoid) = logistic = limited resources = dN/dt = rN[(K−N)/K]. MORE REALISTIC." },
        { L: "★", t: "In the exam, 'more realistic model' ALWAYS means logistic." }
      ]
    },
    {
      title: "The Close-Contact Trio — 'PPC live together'",
      device: `<b>P</b>redation · <b>P</b>arasitism · <b>C</b>ommensalism — these three share the characteristic that the interacting species <b>live closely together</b>`,
      expand: [
        { L: "P", t: "Predation" },
        { L: "P", t: "Parasitism" },
        { L: "C", t: "Commensalism" },
        { L: "★", t: "NCERT states this explicitly. Mutualism, competition and amensalism are NOT in this trio." }
      ]
    },
    {
      title: "Commensalism Pairs — 'OBEC: Only Benefits, Everyone Chill'",
      device: `<b>O</b>rchid on mango · <b>B</b>arnacle on whale · <b>E</b>gret with cattle · <b>C</b>lownfish with anemone`,
      expand: [
        { L: "O", t: "Orchid (epiphyte) on a mango branch — orchid benefits, mango unaffected." },
        { L: "B", t: "Barnacles on a whale's back — barnacles benefit, whale unaffected." },
        { L: "E", t: "Cattle Egret with grazing cattle — cattle stir up insects; egret feeds. Cattle unaffected." },
        { L: "C", t: "Clown fish among the stinging tentacles of a sea anemone — fish gets protection; anemone unaffected." }
      ]
    },
    {
      title: "Mutualism Pairs — 'LMF: Love Means Forever'",
      device: `<b>L</b>ichen · <b>M</b>ycorrhiza · <b>F</b>ig–wasp (+ the <i>Ophrys</i> orchid twist)`,
      expand: [
        { L: "L", t: "Lichen = fungus + photosynthesising alga OR cyanobacteria." },
        { L: "M", t: "Mycorrhiza = fungi + roots of higher plants. Fungus gives nutrients; plant gives carbohydrates." },
        { L: "F", t: "Fig + wasp = one-to-one obligate mutualism. Wasp pollinates; fig feeds the larvae with developing seeds." },
        { L: "!", t: "Ophrys + bee = NOT true mutualism — it is 'SEXUAL DECEIT'. The orchid offers NO reward; the male bee gets cheated." }
      ]
    }
  ],


  /* ---------- 4. FLASHCARDS (113) ---------- */
  flashcards: [
    { front: "Define Ecology.", back: "The study of the interactions among organisms and between an organism and its physical (abiotic) environment." },
    { front: "Ecology is concerned with which FOUR levels of biological organisation?", back: "Organisms, Populations, Communities and Biomes. (NOTE: 'Ecosystem' is NOT in NCERT's list of four — classic trap.)" },
    { front: "Who is called the Father of Ecology in India?", back: "Ramdeo Misra (1908–1998)." },
    { front: "Ramdeo Misra obtained his PhD in Ecology in which year, under whom, and where?", back: "1937, under Prof. W. H. Pearsall FRS, at Leeds University, UK." },
    { front: "Where did Ramdeo Misra establish ecology teaching and research?", back: "Department of Botany, Banaras Hindu University (BHU), Varanasi." },
    { front: "Which committee (1972) resulted from Ramdeo Misra's efforts, and what did it lead to?", back: "The National Committee for Environmental Planning and Coordination (1972), which paved the way for the Ministry of Environment and Forests (1984)." },
    { front: "'How does the bird sing?' — what type of question is this?", back: "A 'how-type' question — it seeks the MECHANISM behind the process." },
    { front: "'Why does the bird sing?' — what type of question is this?", back: "A 'why-type' question — it seeks the SIGNIFICANCE of the process (e.g., communicating with a mate in the breeding season)." },
    { front: "Define a population.", back: "A group of individuals of a species living in a well-defined geographical area, sharing or competing for similar resources, and potentially interbreeding." },
    { front: "Can a group formed by ASEXUAL reproduction be called a population?", back: "Yes. Although 'interbreeding' implies sexual reproduction, an asexually produced group is still considered a population for ecological studies." },
    { front: "Give NCERT's five examples of a population.", back: "Cormorants in a wetland; rats in an abandoned dwelling; teakwood trees in a forest tract; bacteria in a culture plate; lotus plants in a pond." },
    { front: "At which level does natural selection operate to evolve desired traits?", back: "The POPULATION level (even though the individual is what copes with a changed environment)." },
    { front: "Why is population ecology important?", back: "It links ecology to population genetics and evolution." },
    { front: "Name four attributes a POPULATION has that an INDIVIDUAL does not.", back: "Birth rate, Death rate, Sex ratio, Age distribution (age pyramid). Also: population density." },
    { front: "20 lotus plants produced 8 new plants in a year. What is the birth rate?", back: "8/20 = 0.4 offspring per lotus per year. (Denominator is the ORIGINAL 20, not the new 28.)" },
    { front: "4 out of 40 lab fruitflies died in a week. What is the death rate?", back: "4/40 = 0.1 individuals per fruitfly per week." },
    { front: "What is sex ratio?", back: "A population attribute expressing the proportion of males to females (e.g., 60% females and 40% males). An individual is simply male OR female." },
    { front: "What is an age pyramid?", back: "A plot of the age distribution (per cent individuals of a given age group, males and females) of a population. Its SHAPE reveals whether the population is growing, stable or declining." },
    { front: "A triangular age pyramid with a broad base indicates…", back: "A GROWING (expanding) population." },
    { front: "A bell-shaped age pyramid indicates…", back: "A STABLE population." },
    { front: "An age pyramid with a narrow base and bulging top indicates…", back: "A DECLINING population." },
    { front: "What is population density, and what symbol denotes it?", back: "Population size, technically called population density, denoted by N. It need not be measured in numbers only." },
    { front: "Why is 'total number' a poor density measure for a single huge banyan tree vs 200 carrot grass plants?", back: "It underestimates the enormous role of the banyan in the community. Per cent COVER or BIOMASS is a more meaningful measure." },
    { front: "What is the scientific name of carrot grass?", back: "Parthenium hysterophorus." },
    { front: "How is the tiger census in national parks and tiger reserves usually carried out?", back: "Indirectly — from PUG MARKS and FAECAL PELLETS." },
    { front: "'Number of fish caught per trap' in a lake is a measure of…", back: "RELATIVE density (absolute density is not needed for many ecological investigations)." },
    { front: "Which population may have fewer than 10 individuals in a given year at Bharatpur wetlands?", back: "Siberian cranes." },
    { front: "Which population in a pond may run into millions?", back: "Chlamydomonas." },
    { front: "Name the four basic processes that change population density.", back: "Natality (B), Immigration (I) — both INCREASE density; Mortality (D), Emigration (E) — both DECREASE density." },
    { front: "Write the population density equation.", back: "N(t+1) = N(t) + [(B + I) − (D + E)]" },
    { front: "Define natality.", back: "The number of BIRTHS during a given period in the population that are ADDED to the initial density." },
    { front: "Define immigration.", back: "The number of individuals OF THE SAME SPECIES that have come INTO the habitat from elsewhere during the time period considered." },
    { front: "Define emigration.", back: "The number of individuals of the population who LEFT the habitat and gone elsewhere during the time period considered." },
    { front: "Under normal conditions, which two factors most influence population density?", back: "Births and deaths. Immigration and emigration matter only under special conditions." },
    { front: "When can immigration contribute MORE to population growth than birth rate?", back: "When a new habitat is just being colonised." },
    { front: "Write the differential equation for exponential growth.", back: "dN/dt = (b − d) × N = rN, where r = b − d." },
    { front: "What is 'r'?", back: "The INTRINSIC RATE OF NATURAL INCREASE — a very important parameter for assessing the impact of any biotic or abiotic factor on population growth." },
    { front: "Write the INTEGRAL form of the exponential growth equation.", back: "Nt = N0 e^(rt), where Nt = density after time t, N0 = density at time zero, r = intrinsic rate of natural increase, e = 2.71828." },
    { front: "What is the value of 'e' (base of natural logarithms)?", back: "2.71828" },
    { front: "What shape is the exponential growth curve?", back: "J-shaped (also called geometric growth)." },
    { front: "What is the r value for the Norway rat?", back: "0.015" },
    { front: "What is the r value for the flour beetle?", back: "0.12" },
    { front: "What was the r value for the human population of India in 1981?", back: "0.0205" },
    { front: "Rank these r values low to high: flour beetle, Norway rat, India (1981).", back: "Norway rat (0.015) < India 1981 (0.0205) < Flour beetle (0.12). Mnemonic: R-I-B goes up." },
    { front: "What does the king–minister–chessboard wheat anecdote illustrate?", back: "Exponential growth. Doubling grains across 64 squares exceeds the entire kingdom's wheat by the halfway mark." },
    { front: "Which protist is used to illustrate exponential growth by binary fission over 64 days?", back: "Paramecium (doubling in numbers every day, given unlimited food and space)." },
    { front: "Which slow-growing animal did Darwin use to show enormous population build-up without checks?", back: "The elephant." },
    { front: "Define carrying capacity (K).", back: "Nature's limit — the maximum possible number of individuals of a species that a given habitat can support, beyond which no further growth is possible." },
    { front: "Write the logistic growth equation.", back: "dN/dt = rN [ (K − N) / K ], where N = density at time t, r = intrinsic rate of natural increase, K = carrying capacity." },
    { front: "What is logistic growth also called?", back: "Verhulst–Pearl Logistic Growth." },
    { front: "List the four phases of logistic growth in order.", back: "Lag phase → Acceleration → Deceleration → Asymptote (when N reaches K). Mnemonic: LADA." },
    { front: "What shape is the logistic growth curve?", back: "Sigmoid (S-shaped)." },
    { front: "Which growth model is considered MORE REALISTIC and why?", back: "The LOGISTIC model — because resources for growth for most animal populations are finite and become limiting sooner or later." },
    { front: "In the logistic equation, what is dN/dt when N = K?", back: "Zero. (K − N)/K = 0, so growth stops — the asymptote." },
    { front: "At what population size is logistic growth rate MAXIMUM?", back: "At N = K/2 (the inflection point of the S-curve)." },
    { front: "Reproductive fitness is also known as…", back: "DARWINIAN FITNESS (a high r value)." },
    { front: "Name two organisms that breed only ONCE in their lifetime.", back: "Pacific salmon fish and Bamboo." },
    { front: "Which organisms breed MANY times during their lifetime?", back: "Most birds and mammals." },
    { front: "Which organisms produce a LARGE number of SMALL-sized offspring?", back: "Oysters and pelagic fishes." },
    { front: "Which organisms produce a SMALL number of LARGE-sized offspring?", back: "Birds and mammals." },
    { front: "Life-history traits have evolved in relation to constraints imposed by what?", back: "The ABIOTIC and BIOTIC components of the habitat in which the organism lives." },
    { front: "Give the signs and names for all six population interactions (Table 11.1).", back: "Mutualism (+ +); Competition (− −); Predation (+ −); Parasitism (+ −); Commensalism (+ 0); Amensalism (− 0)." },
    { front: "Which THREE interactions share the characteristic that the interacting species live closely together?", back: "Predation, Parasitism and Commensalism." },
    { front: "Which interaction has the signs (− , 0)?", back: "Amensalism — one species is harmed, the other is unaffected. (NCERT gives no example; the classic one is Penicillium killing bacteria.)" },
    { front: "How does NCERT describe predation in terms of energy?", back: "As nature's way of transferring to higher trophic levels the energy fixed by plants — predators act as 'conduits' for energy transfer." },
    { front: "Is a sparrow eating a seed a predator?", back: "Yes — 'a sparrow eating any seed is no less a predator.' Herbivores, in a broad ecological context, are not very different from predators." },
    { front: "Why do exotic species become INVASIVE when introduced to a new geographical area?", back: "Because the invaded land does not have their natural predators." },
    { front: "When was the prickly pear cactus introduced into Australia, and how was it finally controlled?", back: "Early 1920s. It spread over millions of hectares of rangeland and was controlled only after a CACTUS-FEEDING MOTH (a predator from its natural habitat) was introduced." },
    { front: "What is biological control of agricultural pests based on?", back: "The ability of the PREDATOR to regulate the prey population." },
    { front: "What is Pisaster, and what did its removal demonstrate?", back: "A starfish predator in the rocky intertidal communities of the American Pacific Coast. When all starfish were removed from an enclosed intertidal area, MORE THAN 10 SPECIES of invertebrates became extinct WITHIN A YEAR — due to interspecific competition." },
    { front: "How do predators maintain species diversity in a community?", back: "By reducing the intensity of competition among competing prey species." },
    { front: "Why are predators in nature said to be 'prudent'?", back: "Because if a predator overexploits its prey, the prey may become extinct — and the predator will follow, for lack of food." },
    { front: "Name three prey defences against predation.", back: "Cryptic colouration (camouflage) in some insects and frogs; being poisonous; being distasteful (Monarch butterfly)." },
    { front: "Why is the Monarch butterfly distasteful to birds, and where does the chemical come from?", back: "It contains a special chemical. It ACQUIRES this chemical during its CATERPILLAR stage by feeding on a poisonous weed — it does not synthesise it." },
    { front: "What per cent of all insects are phytophagous?", back: "Nearly 25 per cent (feeding on plant sap and other plant parts)." },
    { front: "What is the most common MORPHOLOGICAL plant defence against herbivores, with examples?", back: "Thorns — as in Acacia and Cactus." },
    { front: "Which chemical does Calotropis produce, and what is its effect?", back: "Highly poisonous CARDIAC GLYCOSIDES — which is why cattle and goats never browse on it." },
    { front: "Name five commercially extracted plant chemicals that actually evolved as anti-herbivore defences.", back: "Nicotine, Caffeine, Quinine, Strychnine, Opium. Mnemonic: 'Nice Cats Quietly Steal Opium'." },
    { front: "Which UNRELATED species compete for zooplankton in shallow South American lakes?", back: "Visiting flamingoes and resident fishes — proving that totally unrelated species can compete for the same resource." },
    { front: "What is interference competition?", back: "Competition in which the feeding efficiency of one species is REDUCED due to the interfering and inhibitory presence of another species, EVEN IF resources (food and space) are abundant." },
    { front: "What is the BEST definition of competition?", back: "A process in which the FITNESS of one species (measured as its 'r', the intrinsic rate of increase) is significantly LOWER in the presence of another species." },
    { front: "State Gause's Competitive Exclusion Principle.", back: "Two closely related species competing for the same resources cannot co-exist indefinitely, and the competitively inferior one will be eliminated eventually. (True if resources are limiting — but not otherwise.)" },
    { front: "What happened to the Abingdon tortoise, and why?", back: "It became extinct in the Galapagos Islands WITHIN A DECADE after GOATS were introduced — apparently due to the greater BROWSING EFFICIENCY of the goats." },
    { front: "What is 'competitive release'?", back: "A species restricted to a small geographical area by a competitively superior species expands its distributional range dramatically when the competitor is experimentally removed." },
    { front: "Describe Connell's barnacle experiment.", back: "On the rocky sea coasts of SCOTLAND, the larger and competitively superior barnacle BALANUS dominates the intertidal area and EXCLUDES the smaller barnacle CHTHAMALUS from that zone." },
    { front: "What did MacArthur show with five warbler species?", back: "Five closely related warbler species living on the SAME TREE avoided competition and co-existed due to BEHAVIOURAL DIFFERENCES IN THEIR FORAGING ACTIVITIES — an example of RESOURCE PARTITIONING." },
    { front: "What is resource partitioning?", back: "A mechanism promoting co-existence: two competing species avoid competition by choosing different times for feeding or different foraging patterns." },
    { front: "Which group is generally MORE adversely affected by competition — herbivores/plants, or carnivores?", back: "Herbivores and plants appear to be more adversely affected by competition than carnivores." },
    { front: "Name four parasitic adaptations.", back: "LOSS of unnecessary sense organs; PRESENCE of adhesive organs or suckers; LOSS of the digestive system; HIGH reproductive capacity." },
    { front: "How many intermediate hosts does the human liver fluke need, and which?", back: "TWO — a SNAIL and a FISH. (The liver fluke is a trematode parasite.)" },
    { front: "Which vector does the malarial parasite need?", back: "The mosquito." },
    { front: "How does a parasite harm its host?", back: "Reduces the host's survival, growth and reproduction; reduces its population density; and may render it more vulnerable to predation by making it physically weak." },
    { front: "Define ectoparasite and give four examples.", back: "A parasite feeding on the EXTERNAL surface of the host. Examples: lice on humans; ticks on dogs; ectoparasitic copepods on marine fish; Cuscuta on hedge plants." },
    { front: "What has Cuscuta lost during evolution, and how does it feed?", back: "It has lost its CHLOROPHYLL and its LEAVES. It derives nutrition from the host plant it parasitises." },
    { front: "Why is the female mosquito NOT considered a parasite, even though it needs our blood?", back: "Because it does not LIVE in or on the host — it takes a brief blood meal and leaves. It gains no lodging and forms no lasting association (ecologically, a micro-predator)." },
    { front: "How do endoparasites differ from ectoparasites in life cycle and morphology?", back: "Endoparasite life cycles are MORE COMPLEX (extreme specialisation); their morphological and anatomical features are GREATLY SIMPLIFIED, while their REPRODUCTIVE POTENTIAL is emphasised." },
    { front: "Where do endoparasites live?", back: "Inside the host body at different sites — liver, kidney, lungs, red blood cells, etc." },
    { front: "What is brood parasitism? Give the classic example.", back: "The parasitic bird lays its eggs in the nest of its host and lets the host incubate them. Classic example: the cuckoo (koel) and the crow." },
    { front: "How have the eggs of brood-parasitic birds evolved?", back: "To RESEMBLE the host's eggs in SIZE and COLOUR — reducing the chance that the host detects the foreign eggs and ejects them." },
    { front: "Define commensalism and give four NCERT examples.", back: "One species benefits, the other is neither harmed nor benefited (+, 0). Examples: orchid as an epiphyte on a mango branch; barnacles on a whale's back; cattle egret with grazing cattle; clown fish with sea anemone." },
    { front: "Why does the cattle egret forage close to grazing cattle?", back: "Because the cattle, as they move, STIR UP AND FLUSH OUT INSECTS from the vegetation that would otherwise be hard for the egret to find and catch. The cattle gain nothing." },
    { front: "What does the clown fish get from the sea anemone?", back: "PROTECTION from predators, which stay away from the anemone's stinging tentacles. The anemone derives no apparent benefit." },
    { front: "What is a lichen?", back: "An intimate MUTUALISTIC relationship between a FUNGUS and PHOTOSYNTHESISING ALGAE or CYANOBACTERIA." },
    { front: "What is mycorrhiza, and what is exchanged?", back: "An association between FUNGI and the ROOTS OF HIGHER PLANTS. The fungus helps the plant absorb essential nutrients from the soil; the plant provides the fungus with energy-yielding carbohydrates." },
    { front: "What 'fees' do plants pay animals in plant–animal mutualisms?", back: "POLLEN and NECTAR for pollinators; JUICY, NUTRITIOUS FRUITS for seed dispersers." },
    { front: "What are 'cheaters' in a mutualism?", back: "Animals that try to STEAL NECTAR WITHOUT AIDING IN POLLINATION. Mutualistic systems must be safeguarded against them." },
    { front: "Describe the fig–wasp relationship.", back: "A TIGHT ONE-TO-ONE mutualism: a given fig species can be pollinated ONLY by its 'partner' wasp species. The female wasp pollinates the fig inflorescence while searching for egg-laying sites; in return, the fig offers some of its developing seeds as food for the wasp's larvae." },
    { front: "How does the female fig wasp use the fig fruit?", back: "As an OVIPOSITION (egg-laying) SITE, and it uses the developing seeds within the fruit to NOURISH ITS LARVAE." },
    { front: "Which insects have orchids evolved to attract?", back: "Bees and bumblebees." },
    { front: "How does the Mediterranean orchid Ophrys achieve pollination?", back: "By 'SEXUAL DECEIT'. One petal bears an uncanny resemblance to the FEMALE BEE in size, colour and markings. The male bee 'PSEUDOCOPULATES' with the flower, gets dusted with pollen, and transfers it when it pseudocopulates with another flower." },
    { front: "How does Ophrys demonstrate co-evolution?", back: "If the female bee's colour patterns change even slightly during evolution, pollination success drops — UNLESS the orchid flower co-evolves to maintain the resemblance of its petal to the female bee." },
    { front: "Do all orchids offer rewards to pollinators?", back: "No. Ophrys offers NO reward — it uses deception instead." },
    { front: "Fill in: In competition BOTH species ____; in mutualism BOTH species ____.", back: "In competition both species LOSE (− −); in mutualism both species BENEFIT (+ +)." }
  ],

  /* ---------- 5. ACTIVE RECALL (52) ---------- */
  recall: [
    { q: "Define ecology and list the four levels of biological organisation it is concerned with.", hint: "Interactions + abiotic. Four levels — and one very tempting wrong answer.", a: "<b>Ecology</b> is the study of the interactions <b>among organisms</b> and between <b>an organism and its physical (abiotic) environment</b>.<br><br>It is concerned with four levels: <b>organisms → populations → communities → biomes</b>.<br><br><b>Trap:</b> 'Ecosystem' is NOT one of NCERT's four levels." },
    { q: "Distinguish between 'how-type' and 'why-type' questions in biology, using the singing bulbul.", hint: "Mechanism vs significance.", a: "<b>How-type:</b> seeks the <b>mechanism</b>. E.g., how the bird's <b>voice box and vibrating bone</b> operate.<br><br><b>Why-type:</b> seeks the <b>significance</b>. E.g., the bird's <b>need to communicate with its mate during the breeding season</b>." },
    { q: "Write everything you know about Ramdeo Misra.", hint: "Dates, degree, institution, committee.", a: "<b>Father of Ecology in India</b> (1908–1998). Born <b>26 Aug 1908</b>. PhD in Ecology (<b>1937</b>) under <b>Prof. W. H. Pearsall, FRS</b>, <b>Leeds University, UK</b>. Established ecology teaching and research at the <b>Dept of Botany, BHU, Varanasi</b>. Formulated the <b>first PG course in ecology in India</b>; <b>50+</b> PhD scholars. Fellow of <b>INSA</b> and the <b>World Academy of Arts and Science</b>; <b>Sanjay Gandhi Award</b>. His efforts led to the <b>National Committee for Environmental Planning and Coordination (1972)</b> → <b>Ministry of Environment and Forests (1984)</b>." },
    { q: "Define 'population' precisely, and explain whether an asexually reproducing group qualifies.", hint: "Three conditions + the asexual caveat.", a: "A <b>population</b> = individuals of a species that (1) live in a <b>well-defined geographical area</b>, (2) <b>share or compete for similar resources</b>, and (3) can <b>potentially interbreed</b>.<br><br><b>Yes</b> — although 'interbreeding' implies sexual reproduction, a group resulting from <b>asexual reproduction is also generally considered a population</b> for ecological studies (e.g., bacteria in a culture plate)." },
    { q: "List the attributes that populations possess but individuals do not. (NCERT Exercise Q1)", hint: "Four. Careful — 'birth' is not one of them.", a: "<b>1. Birth rate</b> (per capita births)<br><b>2. Death rate</b> (per capita deaths)<br><b>3. Sex ratio</b><br><b>4. Age distribution / age pyramid</b><br><br>Plus <b>population density (N)</b>.<br><br>An individual has <b>births and deaths</b> — but a population has <b>birth RATES and death RATES</b>." },
    { q: "A pond had 20 lotus plants; 8 new plants were added by reproduction, making 28. Calculate the birth rate. Then: 4 of 40 fruitflies died in one week — calculate the death rate.", hint: "Watch the denominator carefully in the first one.", a: "<b>Birth rate</b> = 8 / <b>20</b> = <b>0.4 offspring per lotus per year</b>.<br>(Divide by the ORIGINAL 20, not by 28.)<br><br><b>Death rate</b> = 4 / 40 = <b>0.1 individuals per fruitfly per week</b>." },
    { q: "Explain age pyramids and what the three shapes tell you.", hint: "Triangle, Bell, Urn.", a: "An <b>age pyramid</b> plots the per cent of individuals in each age group (males and females). Its <b>shape</b> reflects growth status:<br><br><b>Triangle (broad base, tapering top)</b> → <b>GROWING / expanding</b> population.<br><b>Bell-shaped</b> → <b>STABLE</b> population.<br><b>Urn-shaped (narrow base)</b> → <b>DECLINING</b> population.<br><br>Mnemonic: <b>Triangle grows, Bell holds, Urn goes.</b>" },
    { q: "Population density can be measured in several ways. Name them and give the situation where each is preferred.", hint: "Number, cover/biomass, relative, indirect.", a: "<b>1. Total number</b> — the default, most appropriate measure.<br><b>2. Per cent cover / biomass</b> — when number is <b>meaningless</b>: 200 <i>Parthenium hysterophorus</i> (carrot grass) plants vs <b>1 huge banyan</b> with a large canopy.<br><b>3. Biomass / density estimate</b> — when counting is <b>impossible</b>: a dense bacterial culture in a petri dish.<br><b>4. Relative density</b> — when absolute numbers aren't needed: <b>number of fish caught per trap</b>.<br><b>5. Indirect estimation</b> — <b>tiger census from pug marks and faecal pellets</b>." },
    { q: "Give NCERT's two examples of extreme population sizes.", hint: "One bird, one alga.", a: "<b>Very low:</b> Siberian cranes at <b>Bharatpur wetlands</b> — as few as <b>&lt;10</b> in any year.<br><b>Very high:</b> <i>Chlamydomonas</i> in a pond — into the <b>millions</b>." },
    { q: "Name and define the four basic processes that change population density, and write the equation.", hint: "NIME.", a: "<b>Natality (B)</b> — number of <b>births</b> added to the initial density. ▲<br><b>Immigration (I)</b> — individuals <b>of the same species</b> that come <b>INTO</b> the habitat from elsewhere. ▲<br><b>Mortality (D)</b> — number of <b>deaths</b>. ▼<br><b>Emigration (E)</b> — individuals who <b>LEFT</b> the habitat and gone elsewhere. ▼<br><br><b>N<sub>t+1</sub> = N<sub>t</sub> + [(B + I) − (D + E)]</b>" },
    { q: "Under what conditions does immigration matter more than birth rate?", hint: "New territory.", a: "Under <b>normal conditions, births and deaths dominate</b>. Immigration and emigration matter only under <b>special conditions</b> — for example, when a <b>new habitat is just being colonised</b>, immigration may contribute more significantly to population growth than birth rate." },
    { q: "Derive and explain the exponential growth equation, including its integral form.", hint: "b, d, r, N — then integrate.", a: "With <b>unlimited resources</b>, a species realises its innate potential to grow (Darwin's observation).<br><br><b>dN/dt = (b − d) × N</b><br>Let <b>(b − d) = r</b> ⇒ <b>dN/dt = rN</b><br><br><b>Integral form: N<sub>t</sub> = N<sub>0</sub> e<sup>rt</sup></b><br>N<sub>t</sub> = density after time t; N<sub>0</sub> = density at time zero; r = intrinsic rate of natural increase; e = <b>2.71828</b>.<br><br>Curve: <b>J-shaped</b> (exponential / geometric)." },
    { q: "What is 'r' and why is it important? Give the three NCERT r values.", hint: "Rat, India, Beetle.", a: "<b>r = intrinsic rate of natural increase = b − d.</b> It is 'a very important parameter chosen for <b>assessing the impacts of any biotic or abiotic factor on population growth</b>'.<br><br><b>Norway rat: 0.015</b><br><b>Human population of India, 1981: 0.0205</b><br><b>Flour beetle: 0.12</b><br><br>Ascending order: <b>R-I-B</b>." },
    { q: "Narrate the chessboard anecdote and explain what it demonstrates.", hint: "King, minister, wheat, 64 squares.", a: "The minister asked for wheat grains: <b>1 on square 1, 2 on square 2, 4 on square 3, 8 on square 4</b> — doubling across all <b>64 squares</b>. By the time the king had covered <b>HALF the chessboard</b>, all the wheat produced in his entire kingdom pooled together would still be <b>inadequate</b>.<br><br>It demonstrates how fast a population grows <b>exponentially</b> — like a single <i>Paramecium</i> doubling daily by binary fission for <b>64 days</b> (given unlimited food and space)." },
    { q: "Explain logistic growth: why it happens, its equation, its phases, and its curve.", hint: "K, Verhulst-Pearl, LADA.", a: "<b>No population has unlimited resources.</b> Limited resources → <b>competition</b> → the 'fittest' survive and reproduce. The habitat supports a maximum number = <b>carrying capacity (K)</b>.<br><br><b>dN/dt = rN [(K − N)/K]</b> — <b>Verhulst–Pearl Logistic Growth</b>.<br><br>Phases: <b>Lag → Acceleration → Deceleration → Asymptote</b> (N = K).<br>Curve: <b>sigmoid / S-shaped</b>.<br><br>It is the <b>more realistic</b> model because resources for most animal populations are <b>finite</b> and become limiting sooner or later." },
    { q: "Analyse the logistic equation for four cases: N ≪ K, N = K/2, N = K, N > K.", hint: "Look at the bracket term.", a: "<b>N ≪ K:</b> (K − N)/K ≈ 1 ⇒ dN/dt ≈ rN → behaves almost <b>exponentially</b>.<br><b>N = K/2:</b> growth rate is <b>MAXIMUM</b> (inflection point of the S-curve).<br><b>N = K:</b> (K − N)/K = 0 ⇒ <b>dN/dt = 0</b> → the <b>asymptote</b>; growth stops.<br><b>N &gt; K:</b> the bracket is <b>negative</b> ⇒ <b>dN/dt &lt; 0</b> → the population <b>declines back toward K</b>." },
    { q: "Compare exponential and logistic growth across at least six features.", hint: "Resources, equation, curve, K, competition, realism.", a: "<b>Resources:</b> unlimited vs limited<br><b>Equation:</b> dN/dt = rN vs dN/dt = rN[(K−N)/K]<br><b>Curve:</b> J-shaped vs S-shaped (sigmoid)<br><b>Carrying capacity:</b> ignored vs central<br><b>Competition:</b> absent vs present<br><b>Phases:</b> continuous acceleration vs Lag/Acceleration/Deceleration/Asymptote<br><b>Also called:</b> geometric vs Verhulst–Pearl<br><b>Realism:</b> unrealistic long-term vs <b>more realistic</b>" },
    { q: "Explain life history variation: what are populations trying to maximise, and what are the two main trade-offs?", hint: "Darwinian fitness + two axes.", a: "Populations evolve to maximise their <b>reproductive fitness</b>, also called <b>Darwinian fitness</b> (a <b>high r value</b>).<br><br><b>Trade-off 1 — how often to breed:</b><br>• Breed only <b>ONCE</b>: <b>Pacific salmon fish, Bamboo</b><br>• Breed <b>MANY times</b>: <b>most birds and mammals</b><br><br><b>Trade-off 2 — offspring size vs number:</b><br>• <b>Many small</b> offspring: <b>Oysters, pelagic fishes</b><br>• <b>Few large</b> offspring: <b>birds, mammals</b><br><br>Ecologists suggest life-history traits evolved in relation to the constraints imposed by the <b>abiotic and biotic components</b> of the habitat." },
    { q: "Reproduce Table 11.1 completely — all six interactions with their signs.", hint: "My Cat Prefers Pretty Cute Animals.", a: "<b>Mutualism</b> — (+ , +) — both benefit<br><b>Competition</b> — (− , −) — both lose<br><b>Predation</b> — (+ , −) — predator benefits, prey harmed<br><b>Parasitism</b> — (+ , −) — parasite benefits, host harmed<br><b>Commensalism</b> — (+ , 0) — one benefits, other unaffected<br><b>Amensalism</b> — (− , 0) — one harmed, other unaffected" },
    { q: "Which three interactions share a common characteristic, and what is it?", hint: "Physical closeness.", a: "<b>Predation, Parasitism and Commensalism</b> — the interacting species <b>live closely together</b>." },
    { q: "Why can no species live in isolation? Use NCERT's plant example.", hint: "Soil microbes and pollinators.", a: "There is no habitat on earth inhabited by a single species — it is <b>inconceivable</b>. For any species, the <b>minimal requirement is one more species on which it can feed</b>.<br><br>Even a <b>plant</b>, which makes its own food, cannot survive alone: it needs <b>soil microbes</b> to break down organic matter and <b>return inorganic nutrients</b> for absorption; and it needs an <b>animal agent</b> to manage <b>pollination</b>." },
    { q: "Explain the four ecological roles of predators.", hint: "Energy, control, biocontrol, diversity.", a: "<b>1. Energy conduits</b> — they transfer to higher trophic levels the energy fixed by plants.<br><b>2. Control prey populations</b> — without predators, prey could reach very high densities and cause <b>ecosystem instability</b>.<br><b>3. Basis of biological control</b> in agricultural pest management.<br><b>4. Maintain species diversity</b> — by <b>reducing the intensity of competition among competing prey species</b>." },
    { q: "Narrate the prickly pear cactus story in Australia.", hint: "1920s, rangeland, moth.", a: "The <b>prickly pear cactus</b> was introduced into <b>Australia in the early 1920s</b>. Because the <b>invaded land lacked its natural predators</b>, it became <b>invasive</b> and spread rapidly into <b>millions of hectares of rangeland</b>. It was finally brought under control only after a <b>cactus-feeding predator (a MOTH)</b> from its <b>natural habitat</b> was introduced into the country.<br><br><b>Principle:</b> this is the ecological basis of <b>biological control</b>." },
    { q: "Describe the Pisaster starfish experiment and what it proves.", hint: "Remove predator → what happens?", a: "In the <b>rocky intertidal communities of the American Pacific Coast</b>, the starfish <b><i>Pisaster</i></b> is an important predator.<br><br>In a field experiment, <b>all the starfish were removed</b> from an enclosed intertidal area. Result: <b>more than 10 species of invertebrates became extinct within a year</b>, because of <b>interspecific competition</b>.<br><br><b>Proves:</b> predators <b>maintain species diversity</b> by reducing the intensity of competition among prey species." },
    { q: "Why are predators in nature described as 'prudent'?", hint: "Think two steps ahead.", a: "If a predator is <b>too efficient and overexploits its prey</b>, the <b>prey might become extinct</b> — and following it, <b>the predator will also become extinct for lack of food</b>. Natural selection therefore favours predators that do not over-harvest their prey." },
    { q: "Name and explain the prey defences against predation described in NCERT.", hint: "Hide, poison, taste bad.", a: "<b>1. Cryptic colouration (camouflage)</b> — some species of <b>insects and frogs</b> are camouflaged to avoid being detected easily by the predator.<br><b>2. Being poisonous</b> — and therefore avoided by predators.<br><b>3. Being distasteful</b> — the <b>Monarch butterfly</b> is highly distasteful to its bird predator because of a <b>special chemical</b> in its body, which it <b>acquires during its CATERPILLAR stage by feeding on a poisonous weed</b>." },
    { q: "Name the important defence mechanisms in plants against herbivory. (NCERT Exercise Q3)", hint: "Morphological + chemical + the commercial five.", a: "Plants cannot run away, so they evolved:<br><br><b>Morphological:</b> <b>Thorns</b> — <i>Acacia</i>, <i>Cactus</i> (the most common morphological means of defence).<br><br><b>Chemical:</b> chemicals that <b>make the herbivore sick, inhibit feeding or digestion, disrupt reproduction, or even kill</b> it.<br>• <b><i>Calotropis</i></b> produces highly poisonous <b>cardiac glycosides</b> — that is why cattle and goats never browse it.<br>• Commercially extracted defence chemicals: <b>nicotine, caffeine, quinine, strychnine, opium</b>.<br><br><b>Context:</b> nearly <b>25% of all insects are phytophagous</b>." },
    { q: "Bust the two common myths about competition, with NCERT's evidence.", hint: "Related species? Limiting resources?", a: "<b>Myth 1: only closely related species compete.</b> FALSE — <b>totally unrelated species can compete</b>. In some <b>shallow South American lakes</b>, visiting <b>flamingoes</b> and resident <b>fishes</b> compete for their common food, <b>zooplankton</b>.<br><br><b>Myth 2: resources must be limiting for competition.</b> FALSE — in <b>interference competition</b>, the <b>feeding efficiency of one species is reduced by the interfering and inhibitory presence of another</b>, even if food and space are abundant." },
    { q: "Give the best definition of competition (the one NCERT insists on).", hint: "It's phrased in terms of r.", a: "Competition is best defined as a process in which the <b>fitness of one species (measured in terms of its 'r' — the intrinsic rate of increase) is significantly LOWER in the presence of another species</b>." },
    { q: "State Gause's Competitive Exclusion Principle and give its limitation.", hint: "Two closely related species... but?", a: "<b>Principle:</b> Two closely related species competing for the same resources <b>cannot co-exist indefinitely</b>, and the <b>competitively inferior one will be eliminated eventually</b>.<br><br><b>Limitation:</b> This may be true <b>if resources are limiting, but not otherwise</b>. More recent studies <b>do not support such gross generalisations</b> — species facing competition may evolve mechanisms that promote <b>co-existence rather than exclusion</b> (e.g., resource partitioning)." },
    { q: "Describe the Abingdon tortoise case.", hint: "Islands, goats, a decade.", a: "The <b>Abingdon tortoise</b> in the <b>Galapagos Islands</b> became <b>extinct within a decade</b> after <b>goats were introduced</b> on the island — apparently due to the <b>greater browsing efficiency of the goats</b>.<br><br>This is strong circumstantial evidence for <b>competitive exclusion occurring in nature</b>." },
    { q: "Describe Connell's barnacle experiment. Which species wins, and where?", hint: "Scotland. Balanus vs Chthamalus.", a: "On the <b>rocky sea coasts of SCOTLAND</b>, Connell's elegant field experiments showed that the <b>larger and competitively superior barnacle <i>BALANUS</i></b> dominates the intertidal area and <b>EXCLUDES the smaller barnacle <i>CHTHAMALUS</i></b> from that zone." },
    { q: "What is 'competitive release'? Why is it evidence for competition in nature?", hint: "Remove the bully.", a: "A species whose <b>distribution is restricted to a small geographical area</b> because of the presence of a <b>competitively superior species</b> is found to <b>expand its distributional range dramatically</b> when the competing species is <b>experimentally removed</b>.<br><br>It is evidence because the range expansion can only be explained if competition was <b>actively suppressing</b> the species beforehand." },
    { q: "Explain resource partitioning using MacArthur's warblers.", hint: "5 species, 1 tree.", a: "<b>Resource partitioning</b> is a mechanism that promotes <b>co-existence rather than exclusion</b>. If two species compete for the same resource, they can avoid competition by choosing <b>different times for feeding</b> or <b>different foraging patterns</b>.<br><br><b>MacArthur</b> showed that <b>five closely related species of warblers</b> living on the <b>same tree</b> were able to avoid competition and co-exist due to <b>behavioural differences in their foraging activities</b>." },
    { q: "Which is more adversely affected by competition — herbivores and plants, or carnivores?", hint: "Straight from NCERT.", a: "In general, <b>herbivores and plants appear to be MORE adversely affected by competition than carnivores</b>." },
    { q: "Why has parasitism evolved so widely? List the four key parasitic adaptations.", hint: "Free lodging and meals. Lose 2, gain 2.", a: "The parasitic mode of life ensures <b>free lodging and free meals</b> — so it has evolved in many taxonomic groups from plants to higher vertebrates.<br><br><b>LOSE:</b> unnecessary <b>sense organs</b>; the <b>digestive system</b>.<br><b>GAIN:</b> <b>adhesive organs or suckers</b> to cling to the host; <b>high reproductive capacity</b>." },
    { q: "Explain host specificity and co-evolution in parasitism.", hint: "Arms race.", a: "Many parasites are <b>host-specific</b> — they can parasitise <b>only a single species of host</b>. This drives <b>co-evolution</b>: if the <b>host evolves special mechanisms for rejecting or resisting the parasite</b>, the <b>parasite must evolve mechanisms to counteract and neutralise them</b> in order to remain successful with the same host species." },
    { q: "Give NCERT's two examples of complex parasite life cycles.", hint: "One needs two hosts; one needs a vector.", a: "<b>Human liver fluke</b> (a <b>trematode</b>): depends on <b>TWO intermediate hosts — a SNAIL and a FISH</b> — to complete its life cycle.<br><br><b>Malarial parasite</b>: needs a <b>vector (mosquito)</b> to spread to other hosts." },
    { q: "How do parasites affect their hosts?", hint: "Four effects.", a: "The majority of parasites <b>harm the host</b>. They may:<br>• <b>reduce the host's survival, growth and reproduction</b><br>• <b>reduce the host's population density</b><br>• <b>render the host more vulnerable to predation</b> by making it physically weak" },
    { q: "Compare ectoparasites and endoparasites, with examples.", hint: "Site, life cycle, morphology, reproduction.", a: "<b>ECTOPARASITES</b> — feed on the <b>external surface</b> of the host. Examples: <b>lice on humans</b>; <b>ticks on dogs</b>; <b>ectoparasitic copepods on marine fish</b>; <b><i>Cuscuta</i></b>, a parasitic plant on hedge plants that has <b>lost its chlorophyll and leaves</b>.<br><br><b>ENDOPARASITES</b> — live <b>inside the host body</b> (liver, kidney, lungs, RBCs, etc.). Their life cycles are <b>more complex</b> because of extreme specialisation; their <b>morphological and anatomical features are greatly simplified</b>, while <b>reproductive potential is emphasised</b>." },
    { q: "Why is the female mosquito NOT considered a parasite, even though it needs human blood for reproduction?", hint: "Where does it live?", a: "Because it <b>does not live in or on the host</b>. It takes a <b>brief blood meal</b> and departs — it derives <b>no lodging</b> and forms <b>no lasting association</b> with the host, which are the defining features of parasitism ('free lodging and meals').<br><br>Ecologically it acts as a <b>micro-predator</b> rather than a parasite." },
    { q: "Explain brood parasitism, with the mechanism of egg mimicry.", hint: "Koel, crow, spring to summer.", a: "In <b>brood parasitism</b>, the <b>parasitic bird lays its eggs in the nest of its host and lets the host incubate them</b>.<br><br>During evolution, the <b>eggs of the parasitic bird have evolved to RESEMBLE the host's egg in SIZE and COLOUR</b> — this reduces the chance of the host bird <b>detecting the foreign eggs and ejecting them from the nest</b>.<br><br><b>Classic pair:</b> the <b>cuckoo (koel)</b> and the <b>crow</b>, observable in the <b>breeding season (spring to summer)</b>." },
    { q: "Define commensalism and give all four NCERT examples, saying exactly who benefits and how.", hint: "OBEC.", a: "<b>Commensalism (+ , 0):</b> one species benefits, the other is <b>neither harmed nor benefited</b>.<br><br><b>1. Orchid on a mango branch</b> — the orchid, an <b>epiphyte</b>, benefits; the mango derives no apparent benefit.<br><b>2. Barnacles on a whale's back</b> — barnacles benefit; the whale derives no apparent benefit.<br><b>3. Cattle egret &amp; grazing cattle</b> — the egret forages close to the cattle because they <b>stir up and flush out insects</b> from the vegetation that would otherwise be difficult to find and catch.<br><b>4. Clown fish &amp; sea anemone</b> — the fish lives among the <b>stinging tentacles</b> and gets <b>protection from predators</b>; the anemone gains nothing." },
    { q: "An orchid plant is growing on the branch of a mango tree. How do you describe this interaction? (NCERT Exercise Q4)", hint: "One word, plus the reasoning.", a: "This is <b>COMMENSALISM (+, 0)</b>.<br><br>The orchid grows as an <b>epiphyte</b> on the mango branch. The <b>orchid benefits</b> (it gains a position with better access to light and support), while the <b>mango tree is neither harmed nor benefited</b>." },
    { q: "Define mutualism and give NCERT's three main mutualistic partnerships, stating what each partner gives.", hint: "LMF.", a: "<b>Mutualism (+ , +):</b> the interaction confers benefits on <b>both</b> interacting species.<br><br><b>1. Lichen</b> — an intimate mutualism between a <b>fungus</b> and <b>photosynthesising algae or cyanobacteria</b>.<br><b>2. Mycorrhiza</b> — between <b>fungi</b> and the <b>roots of higher plants</b>. The <b>fungus helps the plant absorb essential nutrients from the soil</b>; the <b>plant provides the fungus with energy-yielding carbohydrates</b>.<br><b>3. Plant–pollinator</b> — plants pay a 'fee': <b>pollen and nectar</b> for pollinators, <b>juicy nutritious fruits</b> for seed dispersers." },
    { q: "Explain the fig–wasp mutualism in full, including why it is a case of co-evolution.", hint: "One-to-one, oviposition, larval food.", a: "In many species of fig trees there is a <b>tight ONE-TO-ONE relationship</b> with the pollinator wasp species: <b>a given fig species can be pollinated only by its 'partner' wasp species and no other</b>.<br><br>• The <b>female wasp</b> uses the fruit as an <b>oviposition (egg-laying) site</b>, and uses the <b>developing seeds within the fruit to nourish its larvae</b>.<br>• The wasp <b>pollinates the fig inflorescence while searching for suitable egg-laying sites</b>.<br>• In return for pollination, the <b>fig offers the wasp some of its developing seeds</b> as food for the developing larvae.<br><br>Because the fates of the two are locked together, their evolution is <b>tightly linked</b> — <b>co-evolution</b>." },
    { q: "Explain 'sexual deceit' in the Mediterranean orchid Ophrys, and how it demonstrates co-evolution.", hint: "One petal, one male bee, two flowers.", a: "<b>Not all orchids offer rewards.</b> <i>Ophrys</i> employs <b>'sexual deceit'</b>:<br><br>• <b>One petal</b> of its flower bears an <b>uncanny resemblance to the FEMALE of the bee</b> in <b>size, colour and markings</b>.<br>• The <b>male bee</b> is attracted to what it perceives as a female and <b>'pseudocopulates'</b> with the flower, during which it is <b>dusted with pollen</b>.<br>• When the same bee <b>pseudocopulates with another flower</b>, it <b>transfers the pollen</b> and pollinates it.<br><br><b>Co-evolution:</b> if the <b>female bee's colour patterns change even slightly</b> during evolution, <b>pollination success will be reduced UNLESS the orchid flower co-evolves</b> to maintain the resemblance of its petal to the female bee." },
    { q: "What are 'cheaters' in mutualism, and why must a mutualistic system be safeguarded against them?", hint: "Nectar thieves.", a: "<b>Cheaters</b> are animals that <b>try to steal nectar without aiding in pollination</b>. They take the 'fee' without providing the service.<br><br>A mutually beneficial system must be <b>safeguarded against cheaters</b>, otherwise the plant pays the cost of producing nectar without gaining pollination — which would destabilise the mutualism." },
    { q: "What is the ecological principle behind the biological control method of managing pest insects? (NCERT Exercise Q5)", hint: "It's about predators.", a: "Biological control methods adopted in agricultural pest control are based on the <b>ability of the PREDATOR to regulate the prey population</b>.<br><br>The classic demonstration: the <b>prickly pear cactus</b> invaded <b>Australia (early 1920s)</b> because the land <b>lacked its natural predators</b>; it was controlled only after a <b>cactus-feeding moth</b> was introduced from its natural habitat." },
    { q: "Define population and community. (NCERT Exercise Q6)", hint: "Two definitions.", a: "<b>Population:</b> a group of individuals of a given species sharing or competing for similar resources in a defined geographical area, and potentially interbreeding.<br><br><b>Community:</b> the assemblage of populations of <b>different species</b> that live and interact in a given area — animals, plants and microbes do not live in isolation but interact in various ways to form a <b>biological community</b>." },
    { q: "If a population growing exponentially doubles in size in 3 years, what is the intrinsic rate of increase (r)? (NCERT Exercise Q2)", hint: "Use Nt = N0 e^(rt) with Nt = 2·N0.", a: "N<sub>t</sub> = N<sub>0</sub> e<sup>rt</sup><br>Doubling ⇒ N<sub>t</sub> = 2N<sub>0</sub>, t = 3<br><br>2N<sub>0</sub> = N<sub>0</sub> e<sup>3r</sup><br>⇒ 2 = e<sup>3r</sup><br>⇒ ln 2 = 3r<br>⇒ <b>r = 0.693 / 3 = 0.2310</b><br><br><b>r ≈ 0.231 per year.</b>" },
    { q: "Select the statement which explains best parasitism, and justify. (NCERT Exercise Q9)", hint: "Look at the signs.", a: "<b>Correct: 'One organism is benefited, other is affected.'</b> — i.e., <b>(+ , −)</b>.<br><br>The <b>parasite benefits</b> (free lodging and meals) while the <b>host is harmed</b> — reduced survival, growth, reproduction and population density, and greater vulnerability to predation.<br><br><i>Wrong options and why:</i> 'Both benefited' = mutualism; 'one benefited, other not affected' = commensalism; 'one benefited' alone is incomplete." }
  ],

  /* ---------- 6. QUIZ BATTLE — MCQs (110) ---------- */
  mcqs: [
    { q: "Ecology is concerned with how many levels of biological organisation?", o: ["Four", "Six", "Two", "Three"], c: 0, e: "<b>Four</b> — organisms, populations, communities and biomes." },
    { q: "Which of the following is NOT one of the four levels of biological organisation that ecology is concerned with (as per NCERT)?", o: ["Organisms", "Populations", "Communities", "Ecosystems"], c: 3, e: "NCERT explicitly lists <b>organisms, populations, communities and biomes</b>. 'Ecosystem' is the classic distractor." },
    { q: "Who is revered as the Father of Ecology in India?", o: ["Ramdeo Misra", "Robert MacArthur", "Charles Elton", "G. F. Gause"], c: 0, e: "<b>Ramdeo Misra (1908–1998)</b>, who established ecology at BHU, Varanasi." },
    { q: "Ramdeo Misra obtained his PhD in Ecology (1937) under which professor?", o: ["Prof. J. H. Connell", "Prof. R. H. MacArthur", "Prof. P. F. Verhulst", "Prof. W. H. Pearsall"], c: 3, e: "Under <b>Prof. W. H. Pearsall, FRS</b>, at <b>Leeds University, UK</b>." },
    { q: "The National Committee for Environmental Planning and Coordination was established in which year, due to Ramdeo Misra's efforts?", o: ["1962", "1972", "1984", "1998"], c: 1, e: "<b>1972</b>. It later paved the way for the <b>Ministry of Environment and Forests (1984)</b>." },
    { q: "'Why does the bird sing?' is an example of a question that seeks the:", o: ["Significance of the process", "Anatomy of the voice box", "Rate of the process", "Mechanism behind the process"], c: 0, e: "'Why-type' questions seek <b>significance</b>. 'How-type' questions seek the <b>mechanism</b>." },
    { q: "Natural selection operates to evolve desired traits at the level of the:", o: ["Community", "Biome", "Individual", "Population"], c: 3, e: "The <b>individual</b> copes with the changed environment, but natural selection operates at the <b>population</b> level." },
    { q: "Population ecology is important because it links ecology to:", o: ["Population genetics and evolution", "Taxonomy and systematics", "Biotechnology and genomics", "Biochemistry and physiology"], c: 0, e: "Population ecology <b>links ecology to population genetics and evolution</b>." },
    { q: "Which of the following is NOT an attribute of a population?", o: ["Age distribution", "Birth rate", "Sex ratio", "Birth"], c: 3, e: "An <b>individual</b> has births and deaths; a <b>population</b> has birth RATES and death RATES." },
    { q: "A group of individuals resulting from asexual reproduction is:", o: ["Still generally considered a population for ecological studies", "Called a community", "Never called a population", "Called a clone, not a population"], c: 0, e: "NCERT: even asexually produced groups are <b>generally considered a population</b> for ecological studies." },
    { q: "In a pond there were 20 lotus plants last year; 8 new plants were added by reproduction. The birth rate is:", o: ["2.5 offspring per lotus per year", "0.286 offspring per lotus per year", "0.4 offspring per lotus per year", "0.8 offspring per lotus per year"], c: 2, e: "<b>8/20 = 0.4</b>. Divide by the ORIGINAL 20, not the new total of 28." },
    { q: "4 individuals of a laboratory population of 40 fruitflies died in a week. The death rate is:", o: ["0.4 per fruitfly per week", "10 per fruitfly per week", "0.01 per fruitfly per week", "0.1 per fruitfly per week"], c: 3, e: "<b>4/40 = 0.1</b> individuals per fruitfly per week." },
    { q: "Which of these is a valid example of a population?", o: ["All the cormorants in a wetland", "All the microbes and fungi in the soil", "All the herbivores in a grassland", "All the plants and animals in a pond"], c: 0, e: "A population = individuals of a <b>single species</b>. Cormorants in a wetland qualifies; the others mix species." },
    { q: "An age pyramid with a broad base and tapering top represents a population that is:", o: ["Declining", "Stable", "Growing (expanding)", "Extinct"], c: 2, e: "<b>Broad base = many young = growing/expanding.</b>" },
    { q: "A bell-shaped age pyramid indicates a:", o: ["Declining population", "Randomly fluctuating population", "Growing population", "Stable population"], c: 3, e: "Bell-shaped = <b>stable</b>. Narrow base = declining. Triangle = growing." },
    { q: "Population density is technically designated by the symbol:", o: ["N", "B", "K", "r"], c: 0, e: "<b>N</b> = population density. K = carrying capacity; r = intrinsic rate of natural increase." },
    { q: "In an area with 200 carrot grass plants and one huge banyan tree, the best measure of the banyan's population density is:", o: ["Total number", "Per cent cover or biomass", "Relative density", "Sex ratio"], c: 1, e: "Total number would <b>underestimate the enormous role of the banyan</b>. Use <b>per cent cover or biomass</b>." },
    { q: "Parthenium hysterophorus is the scientific name of:", o: ["Cuscuta", "Prickly pear", "Carrot grass", "Bamboo"], c: 2, e: "<b>Carrot grass</b> — used in NCERT's banyan-vs-carrot-grass density example." },
    { q: "The tiger census in Indian national parks is often based on:", o: ["Radio collars only", "Camera counts of every individual", "Aerial photography", "Pug marks and faecal pellets"], c: 3, e: "Indirect estimation via <b>pug marks and faecal pellets</b>." },
    { q: "'Number of fish caught per trap' in a lake is a measure of:", o: ["Relative density", "Biomass", "Carrying capacity", "Absolute density"], c: 0, e: "<b>Relative density</b> — good enough when absolute density is not needed." },
    { q: "Which population may fall below 10 individuals at Bharatpur wetlands in a given year?", o: ["Chlamydomonas", "Siberian crane", "Cormorant", "Flamingo"], c: 1, e: "<b>Siberian cranes</b> — NCERT's example of an extremely small population." },
    { q: "Which population in a pond may run into millions?", o: ["Lotus", "Cormorant", "Chlamydomonas", "Teakwood"], c: 2, e: "<i>Chlamydomonas</i> — NCERT's example of an extremely large population." },
    { q: "Which pair of processes INCREASES population density?", o: ["Mortality and emigration", "Natality and emigration", "Mortality and immigration", "Natality and immigration"], c: 3, e: "<b>Natality + Immigration</b> increase density. Mortality + Emigration decrease it. Mnemonic: 'NI up, ME down'." },
    { q: "The correct expression for population density at time t+1 is:", o: ["Nt+1 = Nt + [(B + I) − (D + E)]", "Nt+1 = Nt − [(B + I) − (D + E)]", "Nt+1 = Nt × [(B + I) / (D + E)]", "Nt+1 = Nt + [(B + E) − (D + I)]"], c: 0, e: "<b>Nt+1 = Nt + [(B + I) − (D + E)]</b>." },
    { q: "Immigration refers to:", o: ["Individuals of any species entering the habitat", "Individuals of the same species that have come into the habitat from elsewhere", "Individuals leaving the habitat", "Births added to the initial density"], c: 1, e: "Crucially, immigration involves individuals <b>of the SAME species</b>." },
    { q: "Under normal conditions, which factors most influence population density?", o: ["Sex ratio and age distribution", "Immigration and emigration", "Births and deaths", "Predation and weather only"], c: 2, e: "<b>Births and deaths</b> dominate; I and E matter only under special conditions." },
    { q: "In which situation may immigration contribute MORE to population growth than birth rate?", o: ["During a severe drought", "When the population is at carrying capacity", "In a stable climax forest", "When a new habitat is just being colonised"], c: 3, e: "NCERT: 'if a new habitat is just being colonised, <b>immigration may contribute more significantly</b> to population growth than birth rates.'" },
    { q: "Exponential growth of a population produces a curve that is:", o: ["J-shaped", "U-shaped", "Bell-shaped", "S-shaped"], c: 0, e: "Exponential (geometric) growth = <b>J-shaped</b> curve." },
    { q: "In the equation dN/dt = rN, 'r' is called the:", o: ["Rate of reproduction", "Intrinsic rate of natural increase", "Carrying capacity", "Recruitment index"], c: 1, e: "<b>r = intrinsic rate of natural increase = b − d.</b>" },
    { q: "The integral form of the exponential growth equation is:", o: ["Nt = N0 r^t", "Nt = rN[(K−N)/K]", "Nt = N0 e^(rt)", "Nt = N0 + rt"], c: 2, e: "<b>Nt = N0 e^(rt)</b> where e = 2.71828." },
    { q: "The value of 'e', the base of natural logarithms, is:", o: ["3.14159", "2.71828", "1.61803", "0.69315"], c: 1, e: "<b>e = 2.71828</b>." },
    { q: "The r value for the Norway rat is:", o: ["0.12", "0.0205", "0.015", "0.693"], c: 2, e: "Norway rat r = <b>0.015</b>." },
    { q: "The r value for the flour beetle is:", o: ["0.015", "0.0205", "0.12", "0.21"], c: 2, e: "Flour beetle r = <b>0.12</b> — the highest of NCERT's three examples." },
    { q: "In 1981, the r value for the human population in India was:", o: ["0.015", "0.0205", "0.12", "0.205"], c: 1, e: "<b>0.0205</b>." },
    { q: "Which of these has the HIGHEST r value?", o: ["Norway rat", "Flour beetle", "Human population of India (1981)", "All are equal"], c: 1, e: "Flour beetle (0.12) > India 1981 (0.0205) > Norway rat (0.015). Mnemonic: <b>R-I-B goes up</b>." },
    { q: "The chessboard-and-wheat-grains anecdote is used to illustrate:", o: ["Carrying capacity", "Resource partitioning", "Logistic growth", "Exponential growth"], c: 3, e: "Doubling across <b>64 squares</b> demonstrates the explosive nature of <b>exponential growth</b>." },
    { q: "Which organism does NCERT use, doubling daily by binary fission for 64 days, to illustrate exponential growth?", o: ["Paramecium", "Amoeba", "Escherichia coli", "Chlamydomonas"], c: 0, e: "<b>Paramecium</b>, doubling in numbers every day given unlimited food and space." },
    { q: "Darwin used which slow-growing animal to show enormous population build-up in the absence of checks?", o: ["Whale", "Elephant", "Tortoise", "Rhinoceros"], c: 1, e: "The <b>elephant</b>." },
    { q: "Nature's carrying capacity is denoted by:", o: ["r", "N", "K", "b"], c: 2, e: "<b>K</b> = the maximum number a habitat can support, beyond which no further growth is possible." },
    { q: "The logistic growth equation is:", o: ["dN/dt = rN[(N − K)/K]", "dN/dt = rK[(K − N)/N]", "dN/dt = rN", "dN/dt = rN[(K − N)/K]"], c: 3, e: "<b>dN/dt = rN[(K − N)/K]</b> — the Verhulst–Pearl logistic equation." },
    { q: "Logistic growth is also known as:", o: ["Verhulst–Pearl growth", "Malthusian growth", "MacArthur growth", "Gaussian growth"], c: 0, e: "<b>Verhulst–Pearl Logistic Growth</b>." },
    { q: "The correct sequence of phases in logistic growth is:", o: ["Lag → Deceleration → Acceleration → Asymptote", "Lag → Acceleration → Deceleration → Asymptote", "Asymptote → Lag → Acceleration → Deceleration", "Acceleration → Lag → Deceleration → Asymptote"], c: 1, e: "<b>Lag → Acceleration → Deceleration → Asymptote.</b> Mnemonic: LADA." },
    { q: "In the logistic equation, when N = K, the value of dN/dt is:", o: ["Equal to rN", "Maximum", "Zero", "Negative"], c: 2, e: "(K − N)/K becomes <b>0</b>, so <b>dN/dt = 0</b> — the asymptote." },
    { q: "In the logistic model, population growth rate is maximum when:", o: ["N = 2K", "N = K", "N = 0", "N = K/2"], c: 3, e: "The inflection point of the S-curve is at <b>N = K/2</b>." },
    { q: "When N is very small compared to K, the logistic growth curve approximates:", o: ["Exponential growth", "Declining growth", "Oscillatory growth", "Zero growth"], c: 0, e: "(K − N)/K ≈ 1, so <b>dN/dt ≈ rN</b> — essentially exponential." },
    { q: "Which growth model is considered MORE REALISTIC for most animal populations, and why?", o: ["Exponential, because resources are always unlimited", "Logistic, because resources are finite and become limiting", "Exponential, because it is mathematically simpler", "Neither; populations do not follow models"], c: 1, e: "Resources for most animal populations are <b>finite and become limiting sooner or later</b>, so the <b>logistic</b> model is more realistic." },
    { q: "Reproductive fitness is also called:", o: ["Gaussian fitness", "Darwinian fitness", "Ecological fitness", "Malthusian fitness"], c: 1, e: "<b>Darwinian fitness</b> — corresponding to a <b>high r value</b>." },
    { q: "Which of the following breeds only ONCE in its lifetime?", o: ["Most birds", "Most mammals", "Pacific salmon fish", "Norway rat"], c: 2, e: "<b>Pacific salmon fish</b> and <b>bamboo</b> breed only once. Most birds and mammals breed many times." },
    { q: "Which produces a LARGE number of SMALL-sized offspring?", o: ["Elephants", "Birds", "Mammals", "Oysters"], c: 3, e: "<b>Oysters and pelagic fishes</b> produce many small offspring; birds and mammals produce few large ones." },
    { q: "Life-history traits of organisms have evolved in relation to constraints imposed by:", o: ["Only abiotic components of the habitat", "Only biotic components of the habitat", "Both abiotic and biotic components of the habitat", "Neither; they are random"], c: 2, e: "NCERT: constraints imposed by <b>the abiotic AND biotic components</b> of the habitat." },
    { q: "The interaction denoted by (+ , +) is:", o: ["Mutualism", "Predation", "Amensalism", "Commensalism"], c: 0, e: "<b>Mutualism</b> — both species benefit." },
    { q: "The interaction denoted by (− , −) is:", o: ["Predation", "Competition", "Amensalism", "Parasitism"], c: 1, e: "<b>Competition</b> — both species lose." },
    { q: "The interaction denoted by (+ , 0) is:", o: ["Amensalism", "Mutualism", "Commensalism", "Parasitism"], c: 2, e: "<b>Commensalism</b> — one benefits, the other is neither harmed nor benefited." },
    { q: "The interaction denoted by (− , 0) is:", o: ["Competition", "Predation", "Commensalism", "Amensalism"], c: 3, e: "<b>Amensalism</b> — one species is harmed, the other is unaffected." },
    { q: "Which TWO interactions both have the sign pattern (+ , −)?", o: ["Predation and parasitism", "Competition and amensalism", "Parasitism and commensalism", "Mutualism and commensalism"], c: 0, e: "<b>Predation and parasitism</b> — one benefits (predator/parasite), the other is harmed (prey/host)." },
    { q: "Which three interactions share the characteristic that the interacting species LIVE CLOSELY TOGETHER?", o: ["Mutualism, competition, amensalism", "Predation, parasitism, commensalism", "Predation, competition, mutualism", "Parasitism, amensalism, mutualism"], c: 1, e: "NCERT states this explicitly: <b>predation, parasitism and commensalism</b>." },
    { q: "Predation can be described as nature's way of:", o: ["Increasing the carrying capacity", "Reducing biodiversity", "Transferring to higher trophic levels the energy fixed by plants", "Preventing evolution"], c: 2, e: "Predators are <b>'conduits' for energy transfer</b> across trophic levels." },
    { q: "A sparrow eating a seed is ecologically:", o: ["A parasite", "A commensal", "A decomposer", "A predator"], c: 3, e: "NCERT: 'a sparrow eating any seed is <b>no less a predator</b>.'" },
    { q: "Exotic species become invasive in a new area mainly because:", o: ["The invaded land does not have their natural predators", "They reproduce asexually", "They have lower r values", "They have higher carrying capacity"], c: 0, e: "The <b>absence of natural predators</b> in the invaded land allows them to spread unchecked." },
    { q: "The prickly pear cactus was introduced into Australia in:", o: ["The early 1820s", "The early 1920s", "The late 1950s", "The 1970s"], c: 1, e: "<b>Early 1920s</b> — it then spread into millions of hectares of rangeland." },
    { q: "The prickly pear cactus in Australia was finally brought under control by introducing:", o: ["A herbicide-resistant grass", "Goats", "A cactus-feeding moth", "A cactus-feeding beetle"], c: 2, e: "A <b>cactus-feeding predator — a MOTH</b> — from the cactus's natural habitat." },
    { q: "Biological control of agricultural pests is based on:", o: ["The ability of the parasite to kill the host instantly", "Increasing carrying capacity", "Competitive release", "The ability of the predator to regulate prey population"], c: 3, e: "It exploits the predator's capacity to <b>keep prey populations under control</b>." },
    { q: "Pisaster is a:", o: ["Starfish predator", "Parasitic wasp", "Cactus-feeding moth", "Barnacle"], c: 0, e: "<i>Pisaster</i> is an important <b>starfish predator</b> in the rocky intertidal communities of the American Pacific Coast." },
    { q: "When all Pisaster starfish were removed from an enclosed intertidal area, what happened?", o: ["Invertebrate diversity increased", "More than 10 species of invertebrates became extinct within a year", "The area became a barren rock", "Nothing changed"], c: 1, e: "<b>More than 10 invertebrate species went extinct within a year</b> — because of <b>interspecific competition</b>." },
    { q: "The extinction of invertebrates following Pisaster removal was caused by:", o: ["Pollution", "Starvation", "Interspecific competition", "Disease"], c: 2, e: "With the predator gone, superior competitors eliminated the rest — <b>interspecific competition</b>." },
    { q: "Predators help maintain species diversity in a community by:", o: ["Eliminating all prey species equally", "Raising the carrying capacity", "Increasing the birth rate of prey", "Reducing the intensity of competition among competing prey species"], c: 3, e: "They keep dominant competitors in check, allowing weaker competitors to persist." },
    { q: "Predators in nature are said to be 'prudent' because:", o: ["Overexploiting prey would cause the prey — and then the predator — to become extinct", "They hunt only at night", "They have low r values", "They only eat sick prey"], c: 0, e: "If prey go extinct, the <b>predator follows for lack of food</b>." },
    { q: "The Monarch butterfly is distasteful to birds because:", o: ["It synthesises the chemical in its adult stage", "It acquires a special chemical during its caterpillar stage by feeding on a poisonous weed", "It has cryptic colouration", "It has thorns"], c: 1, e: "The chemical is <b>ACQUIRED as a caterpillar</b> from a poisonous weed — it is not synthesised by the butterfly." },
    { q: "Cryptic colouration in some insects and frogs is a means of:", o: ["Warning predators", "Attracting mates", "Camouflage to avoid detection by predators", "Thermoregulation"], c: 2, e: "<b>Camouflage</b> — being cryptically coloured to avoid easy detection." },
    { q: "Approximately what percentage of all insects are known to be phytophagous?", o: ["50%", "75%", "10%", "25%"], c: 3, e: "Nearly <b>25 per cent</b> — feeding on plant sap and other plant parts." },
    { q: "The most common MORPHOLOGICAL means of plant defence against herbivores is:", o: ["Thorns", "Nicotine", "Latex", "Cardiac glycosides"], c: 0, e: "<b>Thorns</b> — as in <i>Acacia</i> and <i>Cactus</i>." },
    { q: "Calotropis is avoided by cattle and goats because it produces:", o: ["Nicotine", "Cardiac glycosides", "Caffeine", "Quinine"], c: 1, e: "Highly poisonous <b>cardiac glycosides</b>." },
    { q: "Which of the following is NOT a plant chemical listed by NCERT as an anti-herbivore defence?", o: ["Quinine", "Strychnine", "Insulin", "Nicotine"], c: 2, e: "The NCERT list is <b>nicotine, caffeine, quinine, strychnine, opium</b>. Insulin is an animal hormone." },
    { q: "In some shallow South American lakes, which two UNRELATED groups compete for zooplankton?", o: ["Barnacles and starfish", "Goats and tortoises", "Warblers and finches", "Flamingoes and resident fishes"], c: 3, e: "<b>Visiting flamingoes and resident fishes</b> — proving unrelated species can compete." },
    { q: "Interference competition occurs when:", o: ["The feeding efficiency of one species is reduced by the inhibitory presence of another, even if resources are abundant", "Two species occupy different niches", "Predators remove one competitor", "Resources are strictly limiting"], c: 0, e: "Interference competition shows that <b>resources need not be limiting</b> for competition to occur." },
    { q: "Competition is BEST defined as a process in which:", o: ["Two species eat the same food", "The fitness (r) of one species is significantly lower in the presence of another species", "Two closely related species live in the same habitat", "One species eats another"], c: 1, e: "NCERT's preferred definition, expressed in terms of <b>r</b>, the intrinsic rate of increase." },
    { q: "Gause's Competitive Exclusion Principle states that:", o: ["Mutualists always co-evolve", "Competition never occurs in nature", "Two closely related species competing for the same resources cannot co-exist indefinitely", "Predators always eliminate their prey"], c: 2, e: "The <b>competitively inferior species will be eliminated eventually</b> — but this holds mainly <b>when resources are limiting</b>." },
    { q: "The Abingdon tortoise became extinct within a decade after the introduction of:", o: ["Cats", "Rabbits", "Rats", "Goats"], c: 3, e: "<b>Goats</b>, on the <b>Galapagos Islands</b> — due to their greater browsing efficiency." },
    { q: "Connell's barnacle experiments were conducted on the rocky sea coasts of:", o: ["Scotland", "Australia", "California", "Galapagos"], c: 0, e: "<b>Scotland</b>." },
    { q: "In Connell's experiment, the competitively superior barnacle is:", o: ["Chthamalus", "Balanus", "Pisaster", "Cuscuta"], c: 1, e: "The larger <b><i>Balanus</i></b> dominates the intertidal area and excludes the smaller <b><i>Chthamalus</i></b>." },
    { q: "'Competitive release' refers to:", o: ["A parasite leaving its host", "A predator releasing its prey", "A species expanding its range when a superior competitor is experimentally removed", "Two species sharing resources by time-partitioning"], c: 2, e: "It is field evidence that competition was actively restricting the species' range." },
    { q: "MacArthur's five warbler species co-existed on the same tree because of:", o: ["Predation by a common enemy", "Brood parasitism", "Mutualism", "Behavioural differences in their foraging activities (resource partitioning)"], c: 3, e: "<b>Resource partitioning</b> — different feeding times or foraging patterns promote co-existence rather than exclusion." },
    { q: "In general, competition adversely affects which group MORE?", o: ["Herbivores and plants", "Decomposers", "All equally", "Carnivores"], c: 0, e: "NCERT: <b>herbivores and plants appear to be more adversely affected by competition than carnivores</b>." },
    { q: "Which of the following is NOT an adaptation of parasites?", o: ["Loss of the digestive system", "Low reproductive capacity", "Loss of unnecessary sense organs", "Presence of adhesive organs or suckers"], c: 1, e: "Parasites have <b>HIGH</b> reproductive capacity — the chance of reaching a new host is low." },
    { q: "The human liver fluke requires how many intermediate hosts?", o: ["None", "One", "Two", "Three"], c: 2, e: "<b>Two</b> — a <b>snail</b> and a <b>fish</b>. The liver fluke is a trematode parasite." },
    { q: "The malarial parasite needs which vector to spread to other hosts?", o: ["Tick", "Snail", "Fish", "Mosquito"], c: 3, e: "The <b>mosquito</b>." },
    { q: "Which of the following is an ECTOPARASITE?", o: ["Ticks on dogs", "Liver fluke in the liver", "Tapeworm in the intestine", "Malarial parasite"], c: 0, e: "Ectoparasites feed on the <b>external surface</b>: lice on humans, ticks on dogs, copepods on marine fish, <i>Cuscuta</i> on hedge plants." },
    { q: "Cuscuta, a parasitic plant found on hedge plants, has lost:", o: ["Only its chlorophyll", "Only its leaves", "Both its chlorophyll and its leaves", "Its roots and stem"], c: 2, e: "It has lost <b>both chlorophyll AND leaves</b>, and derives nutrition from the host plant." },
    { q: "Many marine fish are infested with ectoparasitic:", o: ["Lice", "Copepods", "Barnacles", "Ticks"], c: 1, e: "Ectoparasitic <b>copepods</b>." },
    { q: "The female mosquito is NOT considered a parasite because:", o: ["It reproduces asexually", "It does not feed on blood", "It does not live in or on the host — it takes only a brief blood meal", "It is beneficial to humans"], c: 2, e: "Parasitism means <b>free lodging AND meals</b>. The mosquito gets no lodging and forms no lasting association." },
    { q: "Compared with ectoparasites, endoparasites typically show:", o: ["No reproductive specialisation", "Loss of all reproductive organs", "Simpler life cycles and complex morphology", "More complex life cycles, greatly simplified morphology, and high reproductive potential"], c: 3, e: "Extreme specialisation → <b>complex life cycles, simplified morphology, emphasised reproductive potential</b>." },
    { q: "Brood parasitism is best illustrated by:", o: ["Cuckoo (koel) and crow", "Clown fish and sea anemone", "Cattle egret and cattle", "Fig and wasp"], c: 0, e: "The <b>cuckoo (koel)</b> lays eggs in the <b>crow's</b> nest and lets the host incubate them." },
    { q: "In brood parasitism, the eggs of the parasitic bird have evolved to:", o: ["Be much larger than the host's eggs", "Resemble the host's eggs in size and colour", "Hatch much later than the host's eggs", "Be brightly coloured to deter the host"], c: 1, e: "Mimicry in <b>size and colour</b> reduces the chance of the host detecting and ejecting them." },
    { q: "An orchid growing as an epiphyte on a mango branch is an example of:", o: ["Parasitism", "Mutualism", "Commensalism", "Amensalism"], c: 2, e: "<b>Commensalism (+, 0)</b> — the orchid benefits; the mango is neither harmed nor benefited." },
    { q: "Barnacles growing on the back of a whale represent:", o: ["Parasitism", "Mutualism", "Predation", "Commensalism"], c: 3, e: "<b>Commensalism</b> — barnacles benefit; the whale derives no apparent benefit." },
    { q: "The cattle egret forages close to grazing cattle because the cattle:", o: ["Stir up and flush out insects from the vegetation", "Feed the egret directly", "Warn the egret of danger", "Provide shelter from predators"], c: 0, e: "The moving cattle <b>flush out insects</b> the egret would otherwise struggle to find. The cattle gain nothing → commensalism." },
    { q: "The clown fish benefits from the sea anemone by gaining:", o: ["Food", "Protection from predators (which avoid the stinging tentacles)", "Oxygen", "Camouflage pigments"], c: 1, e: "<b>Protection</b>. The anemone does not appear to derive any benefit → commensalism." },
    { q: "A lichen is a mutualistic association between:", o: ["A fungus and an insect", "A fungus and the roots of a higher plant", "A fungus and photosynthesising algae or cyanobacteria", "An alga and a bacterium"], c: 2, e: "<b>Fungus + photosynthesising algae OR cyanobacteria</b>. (Fungus + plant roots = mycorrhiza.)" },
    { q: "Mycorrhizae are associations between:", o: ["Algae and fungi", "Bacteria and legume roots", "Fungi and insects", "Fungi and roots of higher plants"], c: 3, e: "<b>Fungi + roots of higher plants.</b> Fungus supplies nutrients; plant supplies carbohydrates." },
    { q: "In a mycorrhizal association, the PLANT provides the fungus with:", o: ["Energy-yielding carbohydrates", "Water", "Nitrogen fixation", "Essential mineral nutrients"], c: 0, e: "The plant gives <b>energy-yielding carbohydrates</b>; the fungus helps the plant <b>absorb essential nutrients from the soil</b>." },
    { q: "The 'fees' plants pay to animals in plant–animal mutualisms are:", o: ["Thorns and toxins", "Pollen and nectar for pollinators; juicy nutritious fruits for seed dispersers", "Only nectar", "Only fruits"], c: 1, e: "Pollen and nectar for <b>pollinators</b>; juicy, nutritious fruits for <b>seed dispersers</b>." },
    { q: "'Cheaters' in a plant–pollinator mutualism are animals that:", o: ["Pollinate the wrong species", "Eat the whole flower", "Steal nectar without aiding in pollination", "Lay eggs in the flower"], c: 2, e: "They take the reward without providing the service — mutualisms must be safeguarded against them." },
    { q: "The fig–wasp relationship is best described as:", o: ["Parasitism of the fig by the wasp", "Commensalism", "A loose, non-specific association", "A tight one-to-one mutualism in which a fig species is pollinated only by its partner wasp species"], c: 3, e: "A <b>tight ONE-TO-ONE mutualism</b> — a textbook case of co-evolution." },
    { q: "The female fig wasp uses the fig fruit as:", o: ["An oviposition site, with the developing seeds nourishing its larvae", "A shelter from predators only", "A mating site only", "Only a food source"], c: 0, e: "It is both an <b>egg-laying site</b> and a <b>nursery</b> — the fig offers some developing seeds as larval food in return for pollination." },
    { q: "The Mediterranean orchid Ophrys achieves pollination by:", o: ["Offering abundant nectar", "Sexual deceit — one petal mimics the female bee and the male 'pseudocopulates' with it", "Wind dispersal of pollen", "Producing juicy fruits"], c: 1, e: "<b>Sexual deceit</b>. Not all orchids offer rewards — <i>Ophrys</i> offers none." },
    { q: "In Ophrys, the petal resembles the female bee in:", o: ["Size only", "Shape only", "Size, colour and markings", "Scent only"], c: 2, e: "An 'uncanny resemblance' in <b>size, colour and markings</b>." },
    { q: "Which best demonstrates CO-EVOLUTION?", o: ["Cattle egret and grazing cattle", "Barnacle and whale", "A tiger hunting a deer", "The Ophrys orchid and its male bee pollinator"], c: 3, e: "If the female bee's colour patterns change even slightly, pollination fails <b>unless the orchid co-evolves</b> to maintain the resemblance. Fig–wasp is the other classic case." },
    { q: "Which orchid pollinators does NCERT specifically name?", o: ["Bees and bumblebees", "Beetles and flies", "Birds and bats", "Moths and butterflies"], c: 0, e: "Orchid floral patterns evolved to attract <b>bees and bumblebees</b>." },
    { q: "Which of the following pairs is INCORRECTLY matched?", o: ["Cuscuta on hedge plant — Parasitism", "Clown fish and sea anemone — Mutualism", "Cattle egret and cattle — Commensalism", "Lichen — Mutualism"], c: 1, e: "Clown fish and sea anemone is <b>COMMENSALISM</b> in NCERT — the fish gains protection, the anemone gains nothing." },
    { q: "Amensalism is characterised by:", o: ["Both species benefiting", "One species harmed, the other unaffected", "One species benefiting, the other unaffected", "Both species harmed"], c: 1, e: "<b>(− , 0)</b> — one is harmed, one is unaffected. NCERT lists it in Table 11.1 but gives no example." }
  ],

  /* ---------- 7. MATCH-UP (67 pairs → engine shuffles into 9+ sets of 7) ---------- */
  match: [
    /* SET A — Foundations & people */
    { term: "Ecology", def: "Study of interactions among organisms and with the abiotic environment" },
    { term: "Ramdeo Misra", def: "Father of Ecology in India" },
    { term: "W. H. Pearsall", def: "Supervised Ramdeo Misra's PhD at Leeds (1937)" },
    { term: "'How-type' question", def: "Seeks the MECHANISM behind a process" },
    { term: "'Why-type' question", def: "Seeks the SIGNIFICANCE of a process" },
    { term: "Four levels of ecology", def: "Organisms, populations, communities, biomes" },
    { term: "1972", def: "National Committee for Environmental Planning and Coordination founded" },

    /* SET B — Population attributes */
    { term: "Population", def: "Group of a species in a defined area, sharing resources, potentially interbreeding" },
    { term: "Birth rate", def: "Per capita births — e.g., 8/20 = 0.4 offspring per lotus per year" },
    { term: "Death rate", def: "Per capita deaths — e.g., 4/40 = 0.1 individuals per fruitfly per week" },
    { term: "Sex ratio", def: "Population attribute: e.g., 60% females and 40% males" },
    { term: "Age pyramid", def: "Graphical plot of age distribution revealing growth status" },
    { term: "Triangular pyramid (broad base)", def: "Growing / expanding population" },
    { term: "Urn-shaped pyramid (narrow base)", def: "Declining population" },

    /* SET C — Density measures */
    { term: "Population density", def: "Symbolised by N" },
    { term: "Parthenium hysterophorus", def: "Carrot grass — 200 plants vs 1 banyan" },
    { term: "Per cent cover / biomass", def: "Better density measure for a single huge banyan tree" },
    { term: "Pug marks and faecal pellets", def: "Basis of the tiger census" },
    { term: "Fish caught per trap", def: "A measure of relative density" },
    { term: "Siberian crane at Bharatpur", def: "Population size may be under 10" },
    { term: "Chlamydomonas in a pond", def: "Population size may run into millions" },

    /* SET D — Growth processes & models */
    { term: "Natality", def: "Births added — increases density" },
    { term: "Immigration", def: "Same-species individuals coming IN — increases density" },
    { term: "Mortality", def: "Deaths — decreases density" },
    { term: "Emigration", def: "Individuals leaving the habitat — decreases density" },
    { term: "Nt+1 = Nt + [(B+I) − (D+E)]", def: "The population density equation" },
    { term: "dN/dt = rN", def: "Exponential growth — unlimited resources, J-shaped curve" },
    { term: "Nt = N0 e^(rt)", def: "Integral form of the exponential growth equation" },

    /* SET E — r, K and logistic */
    { term: "r", def: "Intrinsic rate of natural increase (b − d)" },
    { term: "K", def: "Carrying capacity — nature's maximum sustainable number" },
    { term: "e = 2.71828", def: "Base of natural logarithms" },
    { term: "dN/dt = rN[(K−N)/K]", def: "Verhulst–Pearl logistic growth equation" },
    { term: "Sigmoid (S-shaped) curve", def: "Plot of logistic growth" },
    { term: "Lag → Acceleration → Deceleration → Asymptote", def: "The four phases of logistic growth" },
    { term: "Norway rat = 0.015, Flour beetle = 0.12", def: "NCERT's r values" },
    { term: "India, 1981", def: "Human population r value of 0.0205" },
    { term: "Paramecium doubling for 64 days", def: "Illustration of exponential growth" },

    /* SET F — Life history & interaction signs */
    { term: "Darwinian fitness", def: "Reproductive fitness — a high r value" },
    { term: "Pacific salmon and bamboo", def: "Breed only once in a lifetime" },
    { term: "Oysters and pelagic fishes", def: "Produce many small-sized offspring" },
    { term: "Birds and mammals", def: "Produce few large-sized offspring; breed many times" },
    { term: "Mutualism (+ , +)", def: "Both species benefit" },
    { term: "Competition (− , −)", def: "Both species lose" },
    { term: "Commensalism (+ , 0)", def: "One benefits, the other is unaffected" },
    { term: "Amensalism (− , 0)", def: "One is harmed, the other is unaffected" },

    /* SET G — Predation & competition cases */
    { term: "Pisaster", def: "Starfish predator; its removal killed >10 invertebrate species in a year" },
    { term: "Prickly pear + moth", def: "Biological control in Australia, early 1920s" },
    { term: "Monarch butterfly", def: "Distasteful — chemical acquired as a caterpillar from a poisonous weed" },
    { term: "Calotropis", def: "Produces highly poisonous cardiac glycosides" },
    { term: "Acacia and Cactus", def: "Thorns — the commonest morphological anti-herbivore defence" },
    { term: "Nicotine, caffeine, quinine, strychnine, opium", def: "Commercial chemicals that evolved as plant defences" },
    { term: "Flamingoes and resident fishes", def: "Unrelated species competing for zooplankton in South American lakes" },
    { term: "Abingdon tortoise", def: "Extinct in a decade after goats reached the Galapagos" },
    { term: "Balanus excludes Chthamalus", def: "Connell's competition experiment on Scotland's rocky coasts" },
    { term: "MacArthur's five warblers", def: "Resource partitioning on the same tree" },
    { term: "Competitive release", def: "Range expands when a superior competitor is removed" },

    /* SET H — Parasitism, commensalism, mutualism */
    { term: "Human liver fluke", def: "Trematode needing two intermediate hosts — a snail and a fish" },
    { term: "Cuscuta", def: "Parasitic plant that lost chlorophyll and leaves" },
    { term: "Cuckoo (koel) and crow", def: "Brood parasitism with egg mimicry in size and colour" },
    { term: "Lice on humans, ticks on dogs", def: "Ectoparasites" },
    { term: "Female mosquito", def: "NOT a parasite — it does not live in or on the host" },
    { term: "Cattle egret and grazing cattle", def: "Commensalism — cattle flush out insects for the egret" },
    { term: "Clown fish and sea anemone", def: "Commensalism — fish gains protection from stinging tentacles" },
    { term: "Lichen", def: "Mutualism: fungus + photosynthesising alga or cyanobacterium" },
    { term: "Mycorrhiza", def: "Mutualism: fungus + roots of a higher plant" },
    { term: "Fig and wasp", def: "One-to-one obligate mutualism; wasp lays eggs, fig feeds larvae" },
    { term: "Ophrys orchid", def: "Sexual deceit — male bee pseudocopulates with a petal" }
  ],

  /* ---------- 8. BUILD THE PATHWAY (9 sets) ---------- */
  pathways: [
    {
      title: "Levels of Biological Organisation",
      prompt: "Arrange the levels of biological organisation from the smallest to the largest, as listed in NCERT.",
      steps: ["Macromolecules", "Cells", "Tissues", "Organs", "Individual organisms", "Populations", "Communities", "Ecosystems", "Biomes"]
    },
    {
      title: "The Four Phases of Logistic Growth",
      prompt: "Order the phases of Verhulst–Pearl logistic growth, from the start of colonisation to the carrying capacity.",
      steps: ["Lag phase", "Acceleration phase", "Deceleration phase", "Asymptote (N = K)"]
    },
    {
      title: "Building the Population Density Equation",
      prompt: "Assemble the density equation in the correct order: start with the initial density, then apply the four processes and arrive at the new density.",
      steps: ["Start with Nt (density at time t)", "ADD Natality (B)", "ADD Immigration (I)", "SUBTRACT Mortality (D)", "SUBTRACT Emigration (E)", "Arrive at Nt+1"]
    },
    {
      title: "Fig–Wasp Mutualism Cycle",
      prompt: "Sequence the steps of the one-to-one fig and pollinator-wasp mutualism.",
      steps: ["Female wasp searches for a suitable egg-laying site", "Wasp enters the fig inflorescence", "Wasp pollinates the fig while searching", "Wasp uses the fruit as an oviposition site and lays eggs", "Fig offers some developing seeds as food for the wasp larvae", "Larvae mature into new wasps", "New wasps leave carrying pollen to the next fig"]
    },
    {
      title: "Prickly Pear — Invasion and Biological Control",
      prompt: "Order the events of the prickly pear cactus story in Australia.",
      steps: ["Prickly pear cactus introduced into Australia in the early 1920s", "Invaded land has no natural predators of the cactus", "Cactus becomes invasive and spreads rapidly", "Millions of hectares of rangeland are overrun", "A cactus-feeding moth is introduced from the cactus's natural habitat", "The moth (predator) regulates the cactus (prey) population", "The invasive cactus is brought under control"]
    },
    {
      title: "Ophrys — Pollination by Sexual Deceit",
      prompt: "Sequence how the Mediterranean orchid Ophrys gets pollinated without offering any reward.",
      steps: ["One petal evolves to resemble the female bee in size, colour and markings", "A male bee is attracted to what it perceives as a female", "The male bee 'pseudocopulates' with the flower", "The bee is dusted with pollen from the flower", "The same bee pseudocopulates with another Ophrys flower", "Pollen is transferred and the second flower is pollinated"]
    },
    {
      title: "Human Liver Fluke — Life Cycle Hosts",
      prompt: "Order the hosts through which the human liver fluke passes to complete its life cycle.",
      steps: ["Eggs released from the definitive host", "First intermediate host: a snail", "Second intermediate host: a fish", "Primary (definitive) host: human liver"]
    },
    {
      title: "Brood Parasitism — Cuckoo and Crow",
      prompt: "Sequence the events of brood parasitism during the breeding season.",
      steps: ["Cuckoo (koel) locates the nest of its host, the crow", "Cuckoo lays its eggs in the host's nest", "Cuckoo's eggs resemble the host's eggs in size and colour", "The crow fails to detect the foreign eggs", "The crow does not eject them from the nest", "The crow incubates and rears the cuckoo's chicks"]
    },
    {
      title: "Pisaster Removal — Collapse of Diversity",
      prompt: "Sequence the outcome of removing the starfish Pisaster from an enclosed rocky intertidal area.",
      steps: ["Pisaster (starfish) is the key predator in the rocky intertidal community", "All starfish are experimentally removed from the enclosed area", "Prey species are released from predation pressure", "Competitively superior invertebrates dominate the space", "Interspecific competition intensifies sharply", "More than 10 species of invertebrates become extinct within a year"]
    }
  ],

  /* ---------- 9. BOSS BATTLE (27 — hard, integrative, numerical) ---------- */
  boss: [
    { q: "A population growing exponentially doubles in size in 3 years. Its intrinsic rate of increase (r) is approximately:", o: ["0.150", "0.231", "0.333", "0.693"], c: 1, e: "Nt = N0·e^(rt). Doubling ⇒ 2 = e^(3r) ⇒ ln2 = 3r ⇒ r = 0.693/3 = <b>0.231</b>. (NCERT Exercise Q2.)" },
    { q: "In a population, per capita birth rate b = 0.45 and per capita death rate d = 0.15. If N = 200 and resources are unlimited, dN/dt equals:", o: ["30", "60", "90", "120"], c: 1, e: "r = b − d = 0.30. dN/dt = rN = 0.30 × 200 = <b>60</b>." },
    { q: "For a logistic population with r = 0.5, K = 1000 and N = 500, dN/dt equals:", o: ["62.5", "125", "250", "500"], c: 1, e: "dN/dt = rN[(K−N)/K] = 0.5 × 500 × (500/1000) = 0.5 × 500 × 0.5 = <b>125</b>. Note N = K/2, so this is the MAXIMUM growth rate for this population." },
    { q: "For a logistic population with r = 0.2, K = 500 and N = 500, dN/dt equals:", o: ["100", "50", "20", "0"], c: 3, e: "N = K ⇒ (K − N)/K = 0 ⇒ dN/dt = <b>0</b>. The population is at the asymptote." },
    { q: "A logistic population has K = 800 and currently N = 1000. What happens?", o: ["dN/dt is negative; the population declines toward K", "The equation is undefined", "dN/dt is positive; the population grows", "dN/dt is zero; the population is stable"], c: 0, e: "(K − N)/K = (800 − 1000)/800 = −0.25 ⇒ <b>dN/dt is negative</b> and N falls back toward K." },
    { q: "Statement I: In competition, both species suffer. Statement II: In amensalism, one species is harmed while the other is unaffected. Which is correct?", o: ["Only I is correct", "Only II is correct", "Both I and II are correct", "Neither is correct"], c: 2, e: "Competition = (−, −). Amensalism = (−, 0). <b>Both statements are correct.</b>" },
    { q: "Which of the following statements about predation is INCORRECT?", o: ["Predators are 'prudent' in nature", "Predators act as conduits for energy transfer across trophic levels", "Predators keep prey populations under control", "Predators reduce species diversity by killing prey"], c: 3, e: "Predators <b>MAINTAIN</b> species diversity — by reducing the intensity of competition among competing prey species (the Pisaster experiment)." },
    { q: "Assertion: The Monarch butterfly is avoided by birds. Reason: The adult butterfly synthesises a distasteful chemical in its body.", o: ["Both A and R are true, and R is the correct explanation", "Both A and R are true, but R is NOT the correct explanation", "A is true, R is false", "Both A and R are false"], c: 2, e: "The assertion is true, but the reason is FALSE: the butterfly <b>ACQUIRES the chemical during its CATERPILLAR stage</b> by feeding on a poisonous weed — it does not synthesise it as an adult." },
    { q: "Which sequence correctly orders these organisms by increasing r value?", o: ["Norway rat < India 1981 < Flour beetle", "India 1981 < Norway rat < Flour beetle", "Norway rat < Flour beetle < India 1981", "Flour beetle < Norway rat < India 1981"], c: 0, e: "Norway rat <b>0.015</b> < India 1981 <b>0.0205</b> < Flour beetle <b>0.12</b>. Mnemonic: R-I-B goes up." },
    { q: "A population of 100 has 20 births, 10 deaths, 5 immigrants and 15 emigrants in a year. Its size at the end of the year is:", o: ["90", "95", "100", "110"], c: 2, e: "Nt+1 = 100 + [(20 + 5) − (10 + 15)] = 100 + [25 − 25] = <b>100</b>. The population is exactly stationary." },
    { q: "Which of these is the ONLY interaction in which neither species lives in close physical association with the other, as per NCERT's grouping?", o: ["Predation", "Parasitism", "Commensalism", "Competition"], c: 3, e: "NCERT states that <b>predation, parasitism and commensalism</b> share the characteristic that the interacting species <b>live closely together</b>. Competition is not in that trio." },
    { q: "Which of the following pairs of NCERT examples both illustrate CO-EVOLUTION?", o: ["Fig–wasp and Ophrys–bee", "Lichen and mycorrhiza", "Cattle egret–cattle and clown fish–anemone", "Balanus–Chthamalus and Pisaster–invertebrates"], c: 0, e: "Both the <b>fig–wasp one-to-one mutualism</b> and the <b>Ophrys sexual-deceit system</b> are NCERT's explicit illustrations of <b>co-evolution</b> between flower and pollinator." },
    { q: "A student claims: 'Competition only occurs between closely related species when resources are limiting.' How many errors are in this claim?", o: ["None — it is correct", "One error", "Two errors", "Three errors"], c: 2, e: "<b>TWO errors.</b> (1) Totally UNRELATED species can compete — flamingoes vs fishes for zooplankton. (2) Resources need NOT be limiting — see <b>interference competition</b>." },
    { q: "Which experiment demonstrates that a predator can maintain species diversity in a community?", o: ["Gause's Paramecium cultures", "Removal of Pisaster from a rocky intertidal area", "MacArthur's warbler observations", "Connell's barnacle removal"], c: 1, e: "Removing <b>Pisaster</b> caused <b>>10 invertebrate species to go extinct within a year</b> from <b>interspecific competition</b> — proof that the predator was holding diversity together." },
    { q: "Match: (i) Balanus–Chthamalus (ii) MacArthur's warblers (iii) Abingdon tortoise–goats. Which concepts do they illustrate, in order?", o: ["Competitive release, Competitive exclusion, Resource partitioning", "Predation, Competition, Mutualism", "Resource partitioning, Competitive exclusion, Competitive release", "Competitive exclusion, Resource partitioning, Competitive exclusion"], c: 3, e: "Balanus excluding Chthamalus = <b>competitive exclusion</b>. Five warblers co-existing = <b>resource partitioning</b>. Tortoise extinct after goats arrived = <b>competitive exclusion</b> in nature." },
    { q: "Which statement about the logistic growth model is FALSE?", o: ["Growth rate is maximum when N approaches K", "It assumes a finite carrying capacity K", "It produces a sigmoid curve", "It is considered more realistic than exponential growth"], c: 0, e: "Growth rate is maximum at <b>N = K/2</b>, not as N approaches K. As N → K, dN/dt → <b>0</b>." },
    { q: "Which of the following is the correct set of parasitic adaptations?", o: ["Gain of sense organs, gain of digestive system, loss of suckers, low fecundity", "Loss of sense organs, loss of digestive system, gain of suckers, high fecundity", "Loss of suckers, gain of digestive system, high fecundity, loss of sense organs", "Gain of suckers, gain of digestive system, high fecundity, loss of sense organs"], c: 1, e: "<b>Lose 2, gain 2:</b> LOSE unnecessary sense organs and the digestive system; GAIN adhesive organs/suckers and high reproductive capacity." },
    { q: "Which is NOT a valid example of commensalism from NCERT?", o: ["Orchid growing as an epiphyte on a mango branch", "Barnacles growing on the back of a whale", "Clown fish living among sea anemone tentacles", "Fungus and alga living together as a lichen"], c: 3, e: "A <b>lichen is MUTUALISM (+, +)</b>, not commensalism. The other three are NCERT's commensalism examples." },
    { q: "An ecologist finds that species X has a lower 'r' when species Y is present, even though food is abundant. This is:", o: ["Interference competition", "Parasitism", "Commensalism", "Amensalism"], c: 0, e: "Reduced fitness (r) in another species' presence <b>despite abundant resources</b> = <b>interference competition</b> — the inhibitory presence of Y lowers X's feeding efficiency." },
    { q: "The tiger census uses pug marks and faecal pellets. This is an example of:", o: ["Direct counting of absolute density", "Indirect estimation of population size", "Measuring biomass", "Measuring per cent cover"], c: 1, e: "NCERT: 'We are mostly obliged to <b>estimate population sizes indirectly</b>, without actually counting them or seeing them.'" },
    { q: "Which of the following would NOT be a suitable population density measure for a dense laboratory culture of bacteria in a petri dish?", o: ["Biomass", "Optical/turbidity-based estimate", "Total number counted individually", "Relative density"], c: 2, e: "Counting every bacterium individually is <b>impossible or hopelessly time-consuming</b> — this is exactly the case NCERT flags as needing an alternative measure." },
    { q: "Assertion: The female mosquito is a parasite of humans. Reason: It requires human blood for reproduction.", o: ["Both A and R are true, and R explains A", "Both A and R are true, but R does not explain A", "A is false, R is true", "Both A and R are false"], c: 2, e: "<b>A is FALSE, R is TRUE.</b> The mosquito does need blood, but it is NOT a parasite because it does <b>not live in or on the host</b> — parasitism means free lodging AND meals." },
    { q: "Which combination correctly describes the fig–wasp system?", o: ["Fig gains pollination; wasp gains an oviposition site and larval food — mutualism", "Fig gains nothing; wasp gains food — parasitism", "Fig gains nothing; wasp gains shelter — commensalism", "Both lose — competition"], c: 0, e: "Both gain: the <b>fig is pollinated</b>, and the <b>wasp gets an egg-laying site plus developing seeds to feed its larvae</b>. That is <b>mutualism</b> (+, +), and a one-to-one co-evolved one at that." },
    { q: "In an age pyramid, the base narrows sharply and the middle bulges. Ten years on, what should you expect?", o: ["Immigration surge", "Rapid population growth", "A stable population", "Population decline"], c: 3, e: "A <b>narrow base</b> means few young individuals entering the reproductive pool → the population will <b>DECLINE</b>." },
    { q: "Which statement best captures why the logistic model is preferred over the exponential model?", o: ["Resources for most animal populations are finite and become limiting sooner or later", "It always predicts J-shaped curves", "It is mathematically simpler", "It ignores competition, making it cleaner"], c: 0, e: "Exactly NCERT's reasoning: '<b>Since resources for growth for most animal populations are finite and become limiting sooner or later, the logistic growth model is considered a more realistic one.</b>'" },
    { q: "A predator that is TOO efficient is evolutionarily disadvantaged because:", o: ["It cannot reproduce", "It drives its prey extinct, and then goes extinct itself for lack of food", "It attracts more competitors", "It becomes a parasite"], c: 1, e: "This is why predators in nature are described as <b>'prudent'</b> — over-exploitation of prey is self-destructive." },
    { q: "Which of these correctly pairs an NCERT case with the number attached to it?", o: ["Pisaster removal — 5 invertebrate species lost", "Abingdon tortoise — extinct in a century", "MacArthur — 5 warbler species on one tree", "Phytophagous insects — 50% of all insects"], c: 2, e: "<b>MacArthur: five closely related warbler species on the same tree.</b> The others: Pisaster removal killed <b>>10</b> species; the tortoise died out <b>within a decade</b>; <b>~25%</b> of insects are phytophagous." }
  ]
};
