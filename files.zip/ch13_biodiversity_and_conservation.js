/* ============================================================================
   BioArena — CHAPTER 13 : BIODIVERSITY AND CONSERVATION
   NCERT Class XII Biology (Rationalised) — lebo113
   13.1 Biodiversity | 13.1.1 How many species | 13.1.2 Patterns |
   13.1.3 Importance of species diversity | 13.1.4 Loss of biodiversity |
   13.2 Biodiversity Conservation (Why / How — in situ & ex situ)
   ============================================================================ */

DATA.chapters.biodiv = {

  /* ---------- 1. METADATA ---------- */
  id: "biodiv",
  num: 13,
  title: "Biodiversity and Conservation",
  subtitle: "Three levels of diversity · Latitudinal gradients · Species–Area relationship · Rivet Popper · The Evil Quartet · In situ & ex situ conservation",
  color: "#9b59b6",
  colorD: "#6c3483",
  glyph: "🦋",

  /* ---------- 2. STUDY NOTES (10 sections) ---------- */
  notes: [

    {
      id: "b1_levels",
      heading: "1. Biodiversity — Definition & The Three Levels",
      html: `
        <p>Immense diversity (heterogeneity) exists <b>not only at the species level but at ALL levels of biological organisation</b> — ranging from <b>macromolecules within cells</b> to <b>biomes</b>.</p>

        <div class="callout"><b>BIODIVERSITY</b> is the term popularised by the <b>sociobiologist EDWARD WILSON</b> to describe the <b>combined diversity at all the levels of biological organisation</b>.<br><br><b>Learn the name.</b> "Who popularised the term biodiversity?" is asked almost every year.</div>

        <h4>The three important components (levels) of biodiversity</h4>
        <table class="cmp">
          <thead><tr><th>Level</th><th>What it means</th><th>NCERT's examples — memorise these exactly</th></tr></thead>
          <tbody>
            <tr>
              <td><b>1. GENETIC diversity</b></td>
              <td>Diversity shown by a <b>SINGLE species at the genetic level</b>, over its distributional range</td>
              <td>• <b><i>Rauwolfia vomitoria</i></b> — a medicinal plant growing in different <b>Himalayan ranges</b> — shows genetic variation in the <b>potency and concentration of the active chemical RESERPINE</b> that it produces.<br>• India has more than <b>50,000 genetically different strains of RICE</b>.<br>• India has <b>1,000 varieties of MANGO</b>.</td>
            </tr>
            <tr>
              <td><b>2. SPECIES diversity</b></td>
              <td>Diversity <b>at the species level</b> — the number of species in an ecological community</td>
              <td>The <b>WESTERN GHATS have a greater AMPHIBIAN species diversity than the Eastern Ghats</b>.</td>
            </tr>
            <tr>
              <td><b>3. ECOLOGICAL diversity</b></td>
              <td>Diversity <b>at the ecosystem level</b></td>
              <td><b>INDIA</b> — with its <b>deserts, rain forests, mangroves, coral reefs, wetlands, estuaries and alpine meadows</b> — has a <b>greater ecosystem diversity than a Scandinavian country like NORWAY</b>.</td>
            </tr>
          </tbody>
        </table>

        <div class="flow">
          <span class="node">Genes within a species<br>(Rauwolfia, rice, mango)</span><span class="arr">→</span>
          <span class="node">Species within a community<br>(Western Ghats amphibians)</span><span class="arr">→</span>
          <span class="node">Ecosystems within a region<br>(India vs Norway)</span>
        </div>

        <div class="callout"><b>Trap:</b> "Genetic diversity" is <b>within ONE species</b>. If the question says "different species of amphibians", that is <b>SPECIES</b> diversity, not genetic.</div>
      `
    },

    {
      id: "b2_howmany",
      heading: "2. How Many Species Are There? — The Global & Indian Number Bank",
      html: `
        <h4>Global species numbers</h4>
        <table class="cmp">
          <thead><tr><th>Statement</th><th>Number</th></tr></thead>
          <tbody>
            <tr><td><b>IUCN (2004)</b> — total plant + animal species <b>described so far</b></td><td>slightly more than <b>1.5 million</b></td></tr>
            <tr><td><b>Robert May's</b> conservative, scientifically sound estimate of <b>global species diversity</b></td><td>about <b>7 MILLION</b></td></tr>
            <tr><td>Extreme (unreliable) estimates range</td><td><b>20 to 50 million</b></td></tr>
            <tr><td>Of described species, <b>ANIMALS</b></td><td>more than <b>70 per cent</b></td></tr>
            <tr><td>Of described species, <b>PLANTS</b> (algae, fungi, bryophytes, gymnosperms, angiosperms)</td><td><b>no more than 22 per cent</b></td></tr>
            <tr><td>Among animals, <b>INSECTS</b> — the most species-rich taxonomic group</td><td><b>70 per cent</b> of all animals</td></tr>
          </tbody>
        </table>

        <div class="callout"><b>THE KILLER ONE-LINER:</b> Out of every <b>10 animals</b> on this planet, <b>7 are INSECTS</b>.<br><br>
        <b>THE OTHER ONE:</b> The number of <b>FUNGI</b> species in the world is <b>MORE than the COMBINED total</b> of the species of <b>fishes + amphibians + reptiles + mammals</b>.</div>

        <h4>Why prokaryotes are under-counted</h4>
        <ul>
          <li><b>Conventional taxonomic methods are NOT suitable</b> for identifying microbial species.</li>
          <li>Many prokaryotes are <b>NOT CULTURABLE under laboratory conditions</b>.</li>
          <li>If <b>biochemical or molecular criteria</b> were applied, their diversity would rise to <b>"biblical proportions"</b>.</li>
        </ul>

        <h4>India's share</h4>
        <table class="cmp">
          <thead><tr><th>Statement</th><th>Number</th></tr></thead>
          <tbody>
            <tr><td>India's share of the <b>world's LAND area</b></td><td>only <b>2.4 per cent</b></td></tr>
            <tr><td>India's share of <b>global SPECIES diversity</b></td><td>an impressive <b>8.1 per cent</b></td></tr>
            <tr><td>India is one of the world's</td><td><b>12 MEGA-DIVERSITY COUNTRIES</b></td></tr>
            <tr><td>Plant species recorded from India</td><td>nearly <b>45,000</b></td></tr>
            <tr><td>Animal species recorded from India</td><td><b>twice as many</b> — nearly <b>90,000</b></td></tr>
            <tr><td>If only <b>22 per cent</b> of species have been recorded, India still has yet to discover…</td><td>more than <b>1,00,000 plant species</b> and more than <b>3,00,000 animal species</b></td></tr>
          </tbody>
        </table>

        <div class="callout"><b>Mnemonic: "Small land (2.4%), big life (8.1%)."</b></div>

        <h4>How do ecologists ESTIMATE the total number of species? (Exercise Q2)</h4>
        <p>Species inventories are <b>more complete in TEMPERATE than in TROPICAL countries</b>, yet an overwhelmingly large proportion of undiscovered species live in the <b>tropics</b>. So biologists:</p>
        <div class="flow">
          <span class="node">Take an exhaustively studied group of INSECTS</span><span class="arr">→</span>
          <span class="node">Make a STATISTICAL comparison of its temperate vs tropical species richness</span><span class="arr">→</span>
          <span class="node">EXTRAPOLATE that ratio to other groups of animals and plants</span><span class="arr">→</span>
          <span class="node">Arrive at a gross estimate of global species diversity</span>
        </div>
      `
    },

    {
      id: "b3_latitude",
      heading: "3. Pattern 1 — Latitudinal Gradients",
      html: `
        <div class="callout"><b>THE RULE:</b> Species diversity <b>DECREASES as we move AWAY from the equator TOWARDS the poles</b>.<br><br>
        With very few exceptions, <b>TROPICS</b> (latitudinal range of <b>23.5° N to 23.5° S</b>) harbour <b>MORE species</b> than temperate or polar areas.</div>

        <h4>The bird gradient — memorise the four numbers</h4>
        <table class="cmp">
          <thead><tr><th>Place</th><th>Latitude</th><th>Bird species</th></tr></thead>
          <tbody>
            <tr><td><b>Colombia</b></td><td>near the <b>equator</b></td><td>nearly <b>1,400</b></td></tr>
            <tr><td><b>India</b></td><td>much land in tropical latitudes</td><td>more than <b>1,200</b></td></tr>
            <tr><td><b>New York</b></td><td><b>41° N</b></td><td><b>105</b></td></tr>
            <tr><td><b>Greenland</b></td><td><b>71° N</b></td><td>only <b>56</b></td></tr>
          </tbody>
        </table>

        <div class="callout"><b>The plant gradient:</b> a forest in a tropical region like <b>ECUADOR</b> has <b>up to 10 TIMES as many species of VASCULAR PLANTS</b> as a forest of equal area in a temperate region like the <b>MIDWEST of the USA</b>.</div>

        <h4>The Amazonian rain forest — the greatest biodiversity on Earth</h4>
        <table class="cmp">
          <thead><tr><th>Group</th><th>Number of species</th></tr></thead>
          <tbody>
            <tr><td>Plants</td><td>more than <b>40,000</b></td></tr>
            <tr><td>Fishes</td><td><b>3,000</b></td></tr>
            <tr><td>Birds</td><td><b>1,300</b></td></tr>
            <tr><td>Mammals</td><td><b>427</b></td></tr>
            <tr><td>Amphibians</td><td><b>427</b></td></tr>
            <tr><td>Reptiles</td><td><b>378</b></td></tr>
            <tr><td>Invertebrates</td><td>more than <b>1,25,000</b></td></tr>
            <tr><td>Insects <b>waiting to be discovered</b></td><td>at least <b>2 MILLION</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Memory hook:</b> mammals and amphibians are <b>BOTH 427</b>. That coincidence is your anchor — build the rest around it.</div>

        <h4>The THREE hypotheses for tropical richness (Exercise Q3) — "TIME, CONSTANCY, ENERGY"</h4>
        <table class="cmp">
          <thead><tr><th>Hypothesis</th><th>The argument</th></tr></thead>
          <tbody>
            <tr>
              <td><b>(a) TIME</b><br><i>Speciation is a function of time</i></td>
              <td>Unlike temperate regions — which were subjected to <b>frequent GLACIATIONS in the past</b> — <b>tropical latitudes have remained relatively UNDISTURBED for millions of years</b>. They therefore had a <b>long evolutionary time for species diversification</b>.</td>
            </tr>
            <tr>
              <td><b>(b) CONSTANCY</b><br><i>Less seasonal, more predictable</i></td>
              <td>Tropical environments, unlike temperate ones, are <b>LESS SEASONAL, relatively more CONSTANT and PREDICTABLE</b>. Such constant environments <b>promote NICHE SPECIALISATION</b>, which leads to <b>greater species diversity</b>.</td>
            </tr>
            <tr>
              <td><b>(c) ENERGY</b><br><i>More solar energy</i></td>
              <td>There is <b>more SOLAR ENERGY available in the tropics</b>, which contributes to <b>HIGHER PRODUCTIVITY</b> — and this in turn <b>might contribute INDIRECTLY to greater diversity</b>.</td>
            </tr>
          </tbody>
        </table>
        <div class="callout"><b>Note the hedge:</b> the energy hypothesis is stated as contributing <b>INDIRECTLY</b>. Examiners love the word "indirectly" here.</div>
      `
    },

    {
      id: "b4_speciesarea",
      heading: "4. Pattern 2 — The Species–Area Relationship (THE FORMULA)",
      html: `
        <p><span class="kw">Alexander von Humboldt</span> — during his <b>pioneering and extensive explorations in the SOUTH AMERICAN JUNGLES</b> — observed that within a region <b>species richness INCREASED with increasing explored AREA, but only UP TO A LIMIT</b>.</p>

        <div class="flow">
          <span class="node">Plot species richness (S) vs area (A)</span><span class="arr">→</span>
          <span class="node">Curve is a RECTANGULAR HYPERBOLA</span><span class="arr">→</span>
          <span class="node">Convert both axes to a LOGARITHMIC scale</span><span class="arr">→</span>
          <span class="node">The relationship becomes a STRAIGHT LINE</span>
        </div>

        <div class="callout"><b>THE EQUATION — write it exactly:</b><br><br>
          <b>log S = log C + Z log A</b><br><br>
          <b>S</b> = Species richness<br>
          <b>A</b> = Area<br>
          <b>Z</b> = <b>Slope of the line</b> (also called the <b>REGRESSION COEFFICIENT</b>)<br>
          <b>C</b> = <b>Y-intercept</b><br><br>
          <i>(In non-log form: S = C·A<sup>Z</sup>)</i></div>

        <h4>The Z values — three numbers, three contexts</h4>
        <table class="cmp">
          <thead><tr><th>Context</th><th>Z value</th><th>NCERT's examples</th></tr></thead>
          <tbody>
            <tr>
              <td><b>SMALL areas</b> — within a region</td>
              <td><b>0.1 to 0.2</b></td>
              <td>Amazingly similar <b>regardless of the taxonomic group or the region</b> — whether it is <b>plants in Britain, birds in California, or molluscs in New York state</b>.</td>
            </tr>
            <tr>
              <td><b>VERY LARGE areas</b> — entire continents</td>
              <td><b>0.6 to 1.2</b><br>(the slope is <b>much STEEPER</b>)</td>
              <td>—</td>
            </tr>
            <tr>
              <td><b>Frugivorous (fruit-eating) birds and mammals</b> in the tropical forests of different continents</td>
              <td><b>1.15</b></td>
              <td>The single most-tested specific Z value.</td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>Which taxa did Humboldt-style analyses cover?</b> Angiosperm plants, <b>birds, bats, freshwater fishes</b> — a wide variety of taxa, all giving the same rectangular hyperbola.</div>

        <div class="callout"><b>Significance of the slope (Exercise Q4):</b> <b>Z tells you HOW FAST species richness rises with area.</b> A <b>small Z (0.1&ndash;0.2)</b> means richness climbs <b>slowly</b> — you are sampling <b>within one region</b>, so you keep meeting the same species pool. A <b>large Z (0.6&ndash;1.2)</b> means richness climbs <b>steeply</b> — across <b>continents</b>, each new area brings an entirely <b>different</b> species pool. That the small-area Z is so consistent across taxa and continents is what makes the relationship a genuine <b>ecological law</b>, not an accident.</div>
      `
    },

    {
      id: "b5_importance",
      heading: "5. The Importance of Species Diversity — Tilman & the Rivet Popper",
      html: `
        <p><b>Does the number of species in a community really matter to the functioning of an ecosystem?</b> Ecologists have <b>not been able to give a definitive answer</b> — but the evidence points one way.</p>

        <div class="callout"><b>The core belief:</b> Communities with <b>MORE species</b> tend to be <b>MORE STABLE</b> than those with fewer species.</div>

        <h4>What does STABILITY actually mean? (three conditions)</h4>
        <table class="cmp">
          <thead><tr><th>#</th><th>A stable community…</th></tr></thead>
          <tbody>
            <tr><td><b>1</b></td><td>does <b>NOT show much variation in PRODUCTIVITY from year to year</b></td></tr>
            <tr><td><b>2</b></td><td>is either <b>RESISTANT or RESILIENT to occasional DISTURBANCES</b> (natural or man-made)</td></tr>
            <tr><td><b>3</b></td><td>is <b>RESISTANT to INVASIONS by ALIEN species</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Mnemonic: "Steady, Sturdy, Sealed."</b> Steady productivity · Sturdy against disturbance · Sealed against aliens.</div>

        <h4>David Tilman's outdoor-plot experiments</h4>
        <p>Tilman ran <b>long-term ecosystem experiments using OUTDOOR PLOTS</b>. His findings:</p>
        <ul>
          <li>Plots with <b>MORE SPECIES</b> showed <b>LESS year-to-year VARIATION in total BIOMASS</b>.</li>
          <li><b>Increased diversity contributed to HIGHER PRODUCTIVITY.</b></li>
        </ul>
        <div class="callout"><b>Two results, two different variables:</b> more species → <b>less variation</b> AND <b>more productivity</b>. Questions often swap them. Learn both.</div>

        <h4>Paul Ehrlich's RIVET POPPER HYPOTHESIS</h4>
        <table class="cmp">
          <thead><tr><th>In the analogy</th><th>In reality</th></tr></thead>
          <tbody>
            <tr><td>The <b>AIRPLANE</b></td><td>The <b>ECOSYSTEM</b></td></tr>
            <tr><td>The thousands of <b>RIVETS</b> holding it together</td><td>The <b>SPECIES</b></td></tr>
            <tr><td>A <b>PASSENGER popping a rivet</b> to take home</td><td>A <b>species driven to EXTINCTION</b> by humans</td></tr>
            <tr><td>Rivets on the <b>WINGS</b></td><td><b>KEY species</b> — losing them is a serious threat</td></tr>
            <tr><td>Rivets on the <b>SEATS or WINDOWS</b></td><td><b>Less critical species</b> — losing a few is survivable</td></tr>
          </tbody>
        </table>
        <div class="flow">
          <span class="node">Passengers start popping rivets</span><span class="arr">→</span>
          <span class="node">Initially flight safety is NOT affected</span><span class="arr">→</span>
          <span class="node">As more rivets are removed, the plane becomes DANGEROUSLY WEAK</span><span class="arr">→</span>
          <span class="node">WHICH rivet is popped is critical — WING rivets matter far more than SEAT rivets</span>
        </div>
        <div class="callout"><b>NCERT's conclusion:</b> Rich biodiversity is <b>not only essential for ecosystem health but IMPERATIVE for the very SURVIVAL OF THE HUMAN RACE on this planet</b>.</div>
      `
    },

    {
      id: "b6_loss",
      heading: "6. Loss of Biodiversity — The Sixth Extinction",
      html: `
        <p>It is doubtful whether any new species are being <b>added</b> (through speciation) to the Earth's treasury — but there is <b>no doubt about the continuing losses</b>. The accusing finger points clearly at <b>human activities</b>.</p>

        <h4>The extinction number bank</h4>
        <table class="cmp">
          <thead><tr><th>Statement</th><th>Number</th></tr></thead>
          <tbody>
            <tr><td>Native bird species lost to the <b>colonisation of tropical Pacific Islands</b> by humans</td><td>more than <b>2,000</b></td></tr>
            <tr><td><b>IUCN Red List (2004)</b> — species extinct in the <b>last 500 years</b></td><td><b>784</b></td></tr>
            <tr><td>&nbsp;&nbsp;→ of which <b>vertebrates</b></td><td><b>338</b></td></tr>
            <tr><td>&nbsp;&nbsp;→ of which <b>invertebrates</b></td><td><b>359</b></td></tr>
            <tr><td>&nbsp;&nbsp;→ of which <b>plants</b></td><td><b>87</b></td></tr>
            <tr><td>Species that disappeared in the <b>last 20 years alone</b></td><td><b>27</b></td></tr>
            <tr><td>Species <b>currently facing the threat of extinction</b> worldwide</td><td><b>15,500</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Check the arithmetic:</b> 338 + 359 + 87 = <b>784</b>. Note that <b>invertebrates (359) OUTNUMBER vertebrates (338)</b> — a favourite trick option.</div>

        <h4>Recent extinctions — species and their homes</h4>
        <table class="cmp">
          <thead><tr><th>Species</th><th>Region</th></tr></thead>
          <tbody>
            <tr><td><b>Dodo</b></td><td><b>Mauritius</b></td></tr>
            <tr><td><b>Quagga</b></td><td><b>Africa</b></td></tr>
            <tr><td><b>Thylacine</b></td><td><b>Australia</b></td></tr>
            <tr><td><b>Steller's Sea Cow</b></td><td><b>Russia</b></td></tr>
            <tr><td><b>Three subspecies of TIGER</b></td><td><b>Bali, Javan, Caspian</b></td></tr>
          </tbody>
        </table>

        <h4>Extinctions are NOT random</h4>
        <p>Careful analysis shows that <b>extinctions across taxa are not random</b> — some groups are <b>more vulnerable</b>. NCERT singles out <b>AMPHIBIANS</b>.</p>
        <table class="cmp">
          <thead><tr><th>Group</th><th>% of all species facing the threat of extinction</th></tr></thead>
          <tbody>
            <tr><td><b>Amphibians</b></td><td><b>32%</b> &nbsp;← highest</td></tr>
            <tr><td><b>Gymnosperms</b></td><td><b>31%</b></td></tr>
            <tr><td><b>Mammals</b></td><td><b>23%</b></td></tr>
            <tr><td><b>Birds</b></td><td><b>12%</b> &nbsp;← lowest</td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Mnemonic — descending order: A &gt; G &gt; M &gt; B</b> → <b>32, 31, 23, 12</b>. ("Amphibians Get Massacred Badly.")</div>

        <h4>THE SIXTH EXTINCTION</h4>
        <div class="callout">
          Current species extinction rates are estimated to be <b>100 to 1,000 TIMES FASTER</b> than in pre-human times — and <b>our activities are responsible</b>.<br><br>
          Ecologists warn that if the present trends continue, <b>NEARLY HALF OF ALL THE SPECIES ON EARTH might be wiped out within the next 100 YEARS</b>.
        </div>

        <h4>Consequences of biodiversity loss in a region (three)</h4>
        <ol>
          <li><b>Decline in plant PRODUCTION</b></li>
          <li><b>Lowered RESISTANCE to environmental perturbations</b> such as drought</li>
          <li><b>Increased VARIABILITY in certain ecosystem processes</b> — plant productivity, water use, and pest and disease cycles</li>
        </ol>
      `
    },

    {
      id: "b7_evilquartet",
      heading: "7. Causes of Biodiversity Loss — THE EVIL QUARTET",
      html: `
        <div class="callout"><b>Mnemonic: "Humans Over-Ate Creation" → H-O-A-C</b><br>
          <b>H</b>abitat loss and fragmentation · <b>O</b>ver-exploitation · <b>A</b>lien species invasions · <b>C</b>o-extinctions</div>

        <h4>1. HABITAT LOSS AND FRAGMENTATION — the MOST IMPORTANT cause</h4>
        <ul>
          <li>This is the <b>most important cause</b> driving animals and plants to extinction.</li>
          <li>Most dramatic example: the <b>TROPICAL RAIN FORESTS</b> — once covering more than <b>14 per cent</b> of the earth's land surface, they now cover <b>no more than 6 per cent</b>.</li>
          <li>The <b>Amazon rain forest</b> — so huge it is called the <b>'LUNGS OF THE PLANET'</b> — harbours probably millions of species and is being <b>cut and cleared for cultivating SOYA BEANS</b> or for <b>conversion to grasslands for raising BEEF CATTLE</b>.</li>
          <li>Besides total loss, the <b>DEGRADATION of many habitats by POLLUTION</b> also threatens the survival of many species.</li>
          <li>When large habitats are <b>broken up into small FRAGMENTS</b>, <b>mammals and birds requiring LARGE TERRITORIES</b>, and certain <b>animals with MIGRATORY habits</b>, are <b>badly affected</b> — leading to <b>population declines</b>.</li>
        </ul>
        <div class="flow">
          <span class="node">14% of land surface</span><span class="arr">→ tropical rain forests →</span>
          <span class="node">now no more than 6%</span>
        </div>

        <h4>2. OVER-EXPLOITATION</h4>
        <ul>
          <li>Humans have always depended on nature, but <b>when 'NEED' turns to 'GREED'</b>, it leads to <b>over-exploitation</b>.</li>
          <li>Many species extinctions in the last 500 years — the <b>STELLER'S SEA COW</b> and the <b>PASSENGER PIGEON</b> — were due to <b>over-exploitation by humans</b>.</li>
          <li>Presently many <b>MARINE FISH populations</b> around the world are <b>over-harvested</b>, endangering the continued existence of some <b>commercially important species</b>.</li>
        </ul>

        <h4>3. ALIEN SPECIES INVASIONS</h4>
        <table class="cmp">
          <thead><tr><th>Invader</th><th>Where</th><th>Damage</th></tr></thead>
          <tbody>
            <tr>
              <td><b>Nile perch</b></td>
              <td>Introduced into <b>LAKE VICTORIA</b>, east Africa</td>
              <td>Led eventually to the <b>extinction of an ecologically unique assemblage of MORE THAN 200 SPECIES of CICHLID FISH</b> in the lake</td>
            </tr>
            <tr>
              <td><b>Carrot grass (<i>Parthenium</i>), Lantana, Water hyacinth (<i>Eichhornia</i>)</b></td>
              <td>India</td>
              <td>Invasive <b>WEED species</b> causing environmental damage and posing a threat to native species</td>
            </tr>
            <tr>
              <td><b>African catfish (<i>Clarias gariepinus</i>)</b></td>
              <td>Illegally introduced into Indian rivers for <b>AQUACULTURE</b></td>
              <td>Posing a threat to the <b>indigenous catfishes</b> in our rivers</td>
            </tr>
          </tbody>
        </table>
        <div class="callout"><b>Definition:</b> alien species may be introduced <b>unintentionally OR deliberately</b>. Some turn <b>invasive</b> and cause <b>decline or extinction of indigenous species</b>.</div>

        <h4>4. CO-EXTINCTIONS</h4>
        <ul>
          <li>When a species becomes extinct, the plant and animal species <b>associated with it in an OBLIGATORY way</b> also become extinct.</li>
          <li><b>Example 1:</b> when a <b>HOST FISH species becomes extinct, its unique assemblage of PARASITES also meets the same fate</b>.</li>
          <li><b>Example 2:</b> a <b>CO-EVOLVED PLANT&ndash;POLLINATOR MUTUALISM</b> — the extinction of one <b>invariably leads to the extinction of the other</b>.</li>
        </ul>
        <div class="callout"><b>Cross-link to Ch 11:</b> the fig–wasp one-to-one mutualism and the <i>Ophrys</i>–bee system are exactly the kind of relationships that would produce co-extinction.</div>
      `
    },

    {
      id: "b8_whyconserve",
      heading: "8. Why Should We Conserve Biodiversity? — Three Categories",
      html: `
        <div class="callout"><b>Mnemonic: "Nature's Bounty and Ethics" → N-B-E</b><br>
          <b>N</b>arrowly utilitarian · <b>B</b>roadly utilitarian · <b>E</b>thical</div>

        <h4>1. NARROWLY UTILITARIAN — direct economic benefits</h4>
        <table class="cmp">
          <thead><tr><th>Benefit</th><th>Examples</th></tr></thead>
          <tbody>
            <tr><td><b>Food</b></td><td>cereals, pulses, fruits</td></tr>
            <tr><td><b>Materials</b></td><td>firewood, fibre, construction material</td></tr>
            <tr><td><b>Industrial products</b></td><td>tannins, lubricants, dyes, resins, perfumes</td></tr>
            <tr><td><b>Medicines</b></td><td>products of medicinal importance</td></tr>
          </tbody>
        </table>
        <ul>
          <li>More than <b>25 per cent of the drugs currently sold in the market worldwide are derived from PLANTS</b>.</li>
          <li><b>25,000 species of plants</b> contribute to the <b>traditional medicines</b> used by native peoples around the world.</li>
          <li><span class="kw">BIOPROSPECTING</span> = <b>exploring molecular, genetic and species-level diversity for products of economic importance</b>. Nations endowed with rich biodiversity can expect to <b>reap enormous benefits</b> from it.</li>
        </ul>

        <h4>2. BROADLY UTILITARIAN — ecosystem services</h4>
        <table class="cmp">
          <thead><tr><th>Service</th><th>Detail</th></tr></thead>
          <tbody>
            <tr><td><b>Oxygen</b></td><td>The fast-dwindling <b>AMAZON forest</b> is estimated to produce, through photosynthesis, <b>20 PER CENT of the total oxygen in the earth's atmosphere</b></td></tr>
            <tr><td><b>Pollination</b></td><td>Without it, plants cannot give us fruits or seeds. Provided by <b>BEES, BUMBLEBEES, BIRDS and BATS</b></td></tr>
            <tr><td><b>Intangible / aesthetic</b></td><td>The <b>aesthetic pleasures</b> — walking through thick woods, watching spring flowers in full bloom, waking up to a <b>bulbul's song</b>. <b>Can we put a price tag on them?</b></td></tr>
          </tbody>
        </table>

        <h4>3. ETHICAL</h4>
        <div class="callout"><b>Every species has an INTRINSIC VALUE</b>, even if it may not be of current or any economic value to us. We have a <b>MORAL DUTY to care for their well-being</b> and to <b>pass on our biological legacy in good order to future generations</b>.</div>

        <h4>Flood & soil-erosion control by biotic components (Exercise Q8)</h4>
        <ul>
          <li><b>Roots BIND soil particles</b> together, preventing erosion by wind and water.</li>
          <li>The <b>canopy INTERCEPTS rainfall</b>, reducing the force with which drops strike the soil.</li>
          <li><b>Litter and humus INCREASE INFILTRATION</b> and the soil's water-holding capacity.</li>
          <li><b>Vegetation SLOWS surface run-off</b>, so water percolates instead of rushing off as flood.</li>
          <li>Deforestation therefore directly increases <b>flooding, siltation and soil erosion</b>.</li>
        </ul>
      `
    },

    {
      id: "b9_howconserve",
      heading: "9. How Do We Conserve Biodiversity? — In Situ vs Ex Situ",
      html: `
        <table class="cmp">
          <thead><tr><th>Feature</th><th>IN SITU (on site)</th><th>EX SITU (off site)</th></tr></thead>
          <tbody>
            <tr><td>Where</td><td><b>In the natural habitat</b></td><td><b>Outside the natural habitat</b></td></tr>
            <tr><td>What is protected</td><td>The <b>WHOLE ECOSYSTEM</b> — so biodiversity at <b>all levels</b> is protected</td><td><b>Individual threatened species</b>, given special care</td></tr>
            <tr><td>Slogan</td><td>"<b>Save the entire FOREST to save the TIGER</b>"</td><td>"Take it out and protect it"</td></tr>
            <tr><td>Examples</td><td><b>Biodiversity hotspots, biosphere reserves, national parks, wildlife sanctuaries, sacred groves</b></td><td><b>Zoological parks, botanical gardens, wildlife safari parks, cryopreservation, in vitro fertilisation, tissue culture, seed banks</b></td></tr>
          </tbody>
        </table>

        <h4>IN SITU — Biodiversity Hotspots</h4>
        <p>Conservationists identified regions with <b>(a) very high levels of SPECIES RICHNESS</b> and <b>(b) a high degree of ENDEMISM</b> — species <b>confined to that region and not found anywhere else</b> — for <b>maximum protection</b>. These are <span class="kw">biodiversity hotspots</span>.</p>

        <table class="cmp">
          <thead><tr><th>Fact</th><th>Number</th></tr></thead>
          <tbody>
            <tr><td>Hotspots identified <b>initially</b></td><td><b>25</b></td></tr>
            <tr><td><b>Subsequently added</b></td><td><b>9 more</b></td></tr>
            <tr><td><b>TOTAL hotspots in the world</b></td><td><b>34</b></td></tr>
            <tr><td>Land area they cover, all put together</td><td><b>LESS THAN 2 per cent</b> of the earth's land area</td></tr>
            <tr><td>Reduction in ongoing mass extinctions from strict protection of hotspots</td><td>by almost <b>30 PER CENT</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Hotspots are also regions of ACCELERATED HABITAT LOSS.</b> That is precisely why they are urgent.<br><br>
          <b>THE THREE INDIAN HOTSPOTS</b> — mnemonic <b>"We Indians Have"</b>:<br>
          (i) <b>W</b>estern Ghats and Sri Lanka<br>
          (ii) <b>I</b>ndo-Burma<br>
          (iii) <b>H</b>imalaya</div>

        <h4>IN SITU — India's legally protected areas</h4>
        <div class="flow">
          <span class="node">14 Biosphere Reserves</span><span class="arr">|</span>
          <span class="node">90 National Parks</span><span class="arr">|</span>
          <span class="node">448 Wildlife Sanctuaries</span>
        </div>

        <h4>IN SITU — SACRED GROVES (Exercise Q7)</h4>
        <p>India has a history of <b>religious and cultural traditions that emphasised protection of nature</b>. In many cultures, <b>tracts of forest were set aside</b>, and <b>all the trees and wildlife within were VENERATED and given TOTAL PROTECTION</b>.</p>
        <table class="cmp">
          <thead><tr><th>Where sacred groves are found</th><th>Region</th></tr></thead>
          <tbody>
            <tr><td><b>Khasi and Jaintia Hills</b></td><td>Meghalaya</td></tr>
            <tr><td><b>Aravalli Hills</b></td><td>Rajasthan</td></tr>
            <tr><td><b>Western Ghat regions</b></td><td>Karnataka and Maharashtra</td></tr>
            <tr><td><b>Sarguja, Chanda and Bastar areas</b></td><td>Madhya Pradesh</td></tr>
          </tbody>
        </table>
        <div class="callout"><b>In MEGHALAYA, the sacred groves are the LAST REFUGES for a large number of RARE and THREATENED PLANTS.</b><br><br>
        <b>Their role:</b> community-driven, culturally enforced <b>IN SITU</b> conservation — the whole habitat is protected, not just a species.</div>

        <h4>EX SITU — the modern toolkit</h4>
        <table class="cmp">
          <thead><tr><th>Method</th><th>What it does</th></tr></thead>
          <tbody>
            <tr><td><b>Zoological parks, botanical gardens, wildlife safari parks</b></td><td>Threatened plants and animals are <b>taken out of their natural habitat</b> and placed in a <b>special setting</b> with protection and special care. <b>Many animals extinct in the wild continue to be maintained in zoological parks.</b></td></tr>
            <tr><td><b>CRYOPRESERVATION</b></td><td><b>Gametes</b> of threatened species preserved in <b>viable and fertile condition for long periods</b></td></tr>
            <tr><td><b>IN VITRO fertilisation</b></td><td><b>Eggs can be fertilised in vitro</b></td></tr>
            <tr><td><b>TISSUE CULTURE</b></td><td><b>Plants can be propagated</b> using tissue culture methods</td></tr>
            <tr><td><b>SEED BANKS</b></td><td><b>Seeds of different genetic strains</b> of commercially important plants kept for long periods</td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Mnemonic for the modern ex situ toolkit: "C-I-T-S"</b> — <b>C</b>ryopreservation · <b>I</b>n vitro fertilisation · <b>T</b>issue culture · <b>S</b>eed banks.</div>

        <h4>International conservation efforts</h4>
        <p><b>Biodiversity knows no political boundaries</b> — its conservation is therefore a <b>collective responsibility of all nations</b>.</p>
        <table class="cmp">
          <thead><tr><th>Year</th><th>Event</th><th>Outcome</th></tr></thead>
          <tbody>
            <tr>
              <td><b>1992</b></td>
              <td>The <b>EARTH SUMMIT</b>, held in <b>RIO DE JANEIRO</b></td>
              <td>Called upon all nations to take appropriate measures for the <b>conservation of biodiversity</b> and the <b>sustainable utilisation of its benefits</b></td>
            </tr>
            <tr>
              <td><b>2002</b></td>
              <td>The <b>WORLD SUMMIT ON SUSTAINABLE DEVELOPMENT</b>, held in <b>JOHANNESBURG, SOUTH AFRICA</b></td>
              <td><b>190 COUNTRIES</b> pledged their commitment to achieve, by <b>2010</b>, a <b>significant reduction in the current rate of biodiversity loss</b> at <b>global, regional and local levels</b></td>
            </tr>
          </tbody>
        </table>
        <div class="callout"><b>Do not mix these up:</b> <b>Rio = 1992</b>. <b>Johannesburg = 2002, 190 countries, 2010 target.</b></div>
      `
    },

    {
      id: "b10_cheatsheet",
      heading: "10. Cheat Sheet — Every Number, Name & Exercise Answer",
      html: `
        <h4>THE FORMULA</h4>
        <div class="callout"><b>log S = log C + Z log A</b><br>
        S = species richness · A = area · <b>Z = slope of the line = regression coefficient</b> · <b>C = Y-intercept</b><br>
        Small areas: <b>Z = 0.1&ndash;0.2</b> · Continents: <b>Z = 0.6&ndash;1.2</b> · Frugivorous birds &amp; mammals: <b>Z = 1.15</b></div>

        <h4>THE PEOPLE</h4>
        <table class="cmp">
          <thead><tr><th>Name</th><th>What they did</th></tr></thead>
          <tbody>
            <tr><td><b>Edward Wilson</b></td><td><b>Sociobiologist</b> who <b>popularised the term BIODIVERSITY</b></td></tr>
            <tr><td><b>Alexander von Humboldt</b></td><td>Observed the <b>species&ndash;area relationship</b> during explorations of the <b>South American jungles</b></td></tr>
            <tr><td><b>Robert May</b></td><td>Conservative global species estimate: <b>about 7 million</b></td></tr>
            <tr><td><b>David Tilman</b></td><td><b>Outdoor-plot experiments</b>: more species → <b>less year-to-year variation in biomass</b> AND <b>higher productivity</b></td></tr>
            <tr><td><b>Paul Ehrlich</b></td><td>The <b>RIVET POPPER hypothesis</b></td></tr>
          </tbody>
        </table>

        <h4>THE FULL NUMBER BANK</h4>
        <table class="cmp">
          <thead><tr><th>Category</th><th>Numbers</th></tr></thead>
          <tbody>
            <tr><td><b>Global species</b></td><td>Described (IUCN 2004): <b>&gt;1.5 million</b> · Robert May's estimate: <b>7 million</b> · Extreme estimates: <b>20&ndash;50 million</b></td></tr>
            <tr><td><b>Composition</b></td><td>Animals <b>&gt;70%</b> · Plants <b>≤22%</b> · Insects = <b>70% of animals</b> (7 of every 10 animals) · Fungi &gt; fishes + amphibians + reptiles + mammals combined</td></tr>
            <tr><td><b>India</b></td><td>Land area <b>2.4%</b> · Species share <b>8.1%</b> · One of <b>12</b> mega-diversity countries · <b>45,000</b> plants · <b>90,000</b> animals · yet to find: <b>&gt;1,00,000</b> plants, <b>&gt;3,00,000</b> animals</td></tr>
            <tr><td><b>Latitude</b></td><td>Tropics = <b>23.5° N to 23.5° S</b> · Colombia <b>1,400</b> birds · India <b>&gt;1,200</b> · New York (41° N) <b>105</b> · Greenland (71° N) <b>56</b> · Ecuador forest = <b>10&times;</b> the vascular plants of a Midwest-USA forest</td></tr>
            <tr><td><b>Amazon</b></td><td>Plants <b>&gt;40,000</b> · Fishes <b>3,000</b> · Birds <b>1,300</b> · Mammals <b>427</b> · Amphibians <b>427</b> · Reptiles <b>378</b> · Invertebrates <b>&gt;1,25,000</b> · Undiscovered insects <b>≥2 million</b> · Produces <b>20%</b> of atmospheric oxygen · Called the <b>'lungs of the planet'</b></td></tr>
            <tr><td><b>Extinction</b></td><td>Pacific Island birds lost: <b>&gt;2,000</b> · IUCN 2004: <b>784</b> = <b>338</b> vertebrates + <b>359</b> invertebrates + <b>87</b> plants (in <b>500</b> years) · Last 20 years: <b>27</b> species · Currently threatened: <b>15,500</b> · Rate: <b>100&ndash;1,000&times;</b> faster than pre-human · <b>Half</b> of all species could go in <b>100</b> years</td></tr>
            <tr><td><b>% facing extinction</b></td><td>Amphibians <b>32%</b> &gt; Gymnosperms <b>31%</b> &gt; Mammals <b>23%</b> &gt; Birds <b>12%</b></td></tr>
            <tr><td><b>Habitat loss</b></td><td>Tropical rain forests: once <b>&gt;14%</b> of land surface → now <b>≤6%</b></td></tr>
            <tr><td><b>Alien invasion</b></td><td>Nile perch in Lake Victoria wiped out <b>&gt;200</b> species of cichlid fish</td></tr>
            <tr><td><b>Medicine</b></td><td><b>&gt;25%</b> of drugs sold worldwide come from plants · <b>25,000</b> plant species used in traditional medicine</td></tr>
            <tr><td><b>Hotspots</b></td><td><b>25 + 9 = 34</b> · cover <b>&lt;2%</b> of land · strict protection could cut mass extinctions by <b>~30%</b> · <b>3</b> in India</td></tr>
            <tr><td><b>India's protected areas</b></td><td><b>14</b> biosphere reserves · <b>90</b> national parks · <b>448</b> wildlife sanctuaries</td></tr>
            <tr><td><b>Summits</b></td><td>Rio de Janeiro <b>1992</b> (Earth Summit) · Johannesburg <b>2002</b> (World Summit on Sustainable Development, <b>190</b> countries, <b>2010</b> target)</td></tr>
          </tbody>
        </table>

        <h4>EXERCISE ANSWER KEY</h4>
        <table class="cmp">
          <thead><tr><th>Q</th><th>Answer in one line</th></tr></thead>
          <tbody>
            <tr><td><b>1.</b> Three components of biodiversity</td><td><b>Genetic, Species and Ecological diversity</b></td></tr>
            <tr><td><b>2.</b> How ecologists estimate total species</td><td><b>Statistical comparison</b> of temperate vs tropical species richness of an <b>exhaustively studied insect group</b>, then <b>extrapolate</b> the ratio to other taxa</td></tr>
            <tr><td><b>3.</b> Three hypotheses for tropical richness</td><td><b>TIME</b> (undisturbed by glaciations, long evolutionary time) · <b>CONSTANCY</b> (less seasonal, predictable → niche specialisation) · <b>ENERGY</b> (more solar energy → higher productivity → indirectly more diversity)</td></tr>
            <tr><td><b>4.</b> Significance of the slope of regression</td><td><b>Z</b> shows how fast richness rises with area. It is <b>0.1&ndash;0.2 within a region regardless of taxon</b>, but <b>0.6&ndash;1.2 across continents</b>. The consistency of the small-area Z is what makes it a real ecological law.</td></tr>
            <tr><td><b>5.</b> Major causes of species loss</td><td><b>The EVIL QUARTET</b> — habitat loss and fragmentation, over-exploitation, alien species invasions, co-extinctions</td></tr>
            <tr><td><b>6.</b> Importance of biodiversity for ecosystem functioning</td><td><b>Stability</b> (steady productivity, resistance/resilience to disturbance, resistance to invasion) · <b>Tilman</b> (more species → less biomass variation and higher productivity) · <b>Rivet Popper</b> (loss of key species threatens the whole system)</td></tr>
            <tr><td><b>7.</b> Sacred groves and their role</td><td><b>Tracts of forest set aside</b>, with all trees and wildlife <b>venerated and given TOTAL protection</b>. Found in <b>Khasi &amp; Jaintia Hills (Meghalaya)</b>, <b>Aravalli Hills (Rajasthan)</b>, <b>Western Ghats (Karnataka &amp; Maharashtra)</b>, <b>Sarguja, Chanda &amp; Bastar (MP)</b>. In Meghalaya they are the <b>last refuges of many rare and threatened plants</b>. They are <b>community-driven IN SITU conservation</b>.</td></tr>
            <tr><td><b>8.</b> Flood and soil-erosion control</td><td><b>Roots bind soil</b> · <b>canopy intercepts rain</b> · <b>litter increases infiltration</b> · <b>vegetation slows run-off</b> so water percolates instead of flooding</td></tr>
            <tr><td><b>9.</b> Why animals (72%) diversified more than plants (22%)</td><td><b>Greater MOTILITY</b> — animals can escape adverse conditions and colonise new habitats · <b>Complex, sensitive NERVOUS SYSTEMS</b> to perceive and respond to the environment · <b>Rigid EXOSKELETON in arthropods</b>, giving protection and support · better overall adaptability</td></tr>
            <tr><td><b>10.</b> A species we deliberately want extinct</td><td><b>YES</b> — disease-causing pathogens. The <b>SMALLPOX VIRUS</b> was deliberately eradicated worldwide through vaccination. <b>Justification:</b> human welfare — it caused enormous suffering and death, and its removal harms no ecosystem service.</td></tr>
          </tbody>
        </table>
      `
    }
  ],

  /* ---------- 3. MNEMONICS (16) ---------- */
  mnemonics: [
    {
      title: "The Three Levels — 'Genes → Species → Ecosystems'",
      device: `<b>G</b>enetic · <b>S</b>pecies · <b>E</b>cological — with one NCERT example locked to each`,
      expand: [
        { L: "G", t: "GENETIC diversity — WITHIN one species. Rauwolfia vomitoria (reserpine potency varies across Himalayan ranges); 50,000 rice strains; 1,000 mango varieties." },
        { L: "S", t: "SPECIES diversity — Western Ghats have MORE amphibian species than the Eastern Ghats." },
        { L: "E", t: "ECOLOGICAL diversity — India (deserts, rain forests, mangroves, coral reefs, wetlands, estuaries, alpine meadows) beats Norway." },
        { L: "⚠", t: "TRAP: 'different amphibian species' = SPECIES diversity, NOT genetic. Genetic diversity is always WITHIN a single species." },
        { L: "★", t: "The term BIODIVERSITY was popularised by the sociobiologist EDWARD WILSON." }
      ]
    },
    {
      title: "The Evil Quartet — 'Humans Over-Ate Creation'",
      device: `<b>H</b>abitat loss &amp; fragmentation · <b>O</b>ver-exploitation · <b>A</b>lien species invasions · <b>C</b>o-extinctions`,
      expand: [
        { L: "H", t: "HABITAT LOSS AND FRAGMENTATION — the MOST IMPORTANT cause. Tropical rain forests: 14% of land surface → now no more than 6%. Amazon cleared for SOYA BEANS and BEEF CATTLE." },
        { L: "O", t: "OVER-EXPLOITATION — when 'NEED' turns to 'GREED'. Steller's sea cow and the passenger pigeon. Marine fish are over-harvested today." },
        { L: "A", t: "ALIEN SPECIES INVASIONS — Nile perch in Lake Victoria wiped out >200 cichlid species. Parthenium, Lantana, Eichhornia. African catfish Clarias gariepinus." },
        { L: "C", t: "CO-EXTINCTIONS — host fish dies, its parasites die. A co-evolved plant–pollinator mutualism: one goes, the other follows." },
        { L: "★", t: "If asked 'the MOST important cause', the answer is ALWAYS habitat loss and fragmentation." }
      ]
    },
    {
      title: "The Species–Area Formula",
      device: `<b>log S = log C + Z log A</b> &nbsp;|&nbsp; In plain form: <b>S = C · A<sup>Z</sup></b>`,
      expand: [
        { L: "S", t: "S = SPECIES RICHNESS (what you are predicting)." },
        { L: "A", t: "A = AREA explored." },
        { L: "Z", t: "Z = SLOPE of the line = REGRESSION COEFFICIENT. This is the one they ask about." },
        { L: "C", t: "C = Y-INTERCEPT." },
        { L: "0.1–0.2", t: "Z for SMALL areas within a region — amazingly similar regardless of taxon or region (plants in Britain, birds in California, molluscs in New York state)." },
        { L: "0.6–1.2", t: "Z for VERY LARGE areas like entire CONTINENTS — the slope is much STEEPER." },
        { L: "1.15", t: "Z for FRUGIVOROUS (fruit-eating) birds and mammals in the tropical forests of different continents." },
        { L: "★", t: "Alexander von HUMBOLDT discovered it in the SOUTH AMERICAN JUNGLES. Untransformed, the curve is a RECTANGULAR HYPERBOLA." }
      ]
    },
    {
      title: "Why the Tropics Win — 'Time, Constancy, Energy'",
      device: `Tropics had <b>TIME</b> · Tropics are <b>CONSTANT</b> · Tropics get more <b>ENERGY</b>`,
      expand: [
        { L: "TIME", t: "Speciation is a function of TIME. Temperate regions faced frequent GLACIATIONS; tropical latitudes remained relatively UNDISTURBED for MILLIONS of years — long evolutionary time to diversify." },
        { L: "CONSTANCY", t: "Tropical environments are LESS SEASONAL, more CONSTANT and PREDICTABLE. Constant environments promote NICHE SPECIALISATION → greater species diversity." },
        { L: "ENERGY", t: "More SOLAR ENERGY in the tropics → HIGHER PRODUCTIVITY → this might contribute INDIRECTLY to greater diversity." },
        { L: "⚠", t: "Note the word 'INDIRECTLY' in the energy hypothesis. NCERT hedges it, and examiners test that hedge." }
      ]
    },
    {
      title: "Stability of a Community — 'Steady, Sturdy, Sealed'",
      device: `A stable community: <b>steady</b> productivity · <b>sturdy</b> against disturbance · <b>sealed</b> against alien invasion`,
      expand: [
        { L: "STEADY", t: "Does NOT show much variation in PRODUCTIVITY from year to year." },
        { L: "STURDY", t: "Is either RESISTANT or RESILIENT to occasional DISTURBANCES (natural or man-made)." },
        { L: "SEALED", t: "Is RESISTANT to INVASIONS by ALIEN species." },
        { L: "★", t: "DAVID TILMAN's outdoor-plot experiments: plots with MORE species showed LESS year-to-year variation in total biomass, AND increased diversity contributed to HIGHER PRODUCTIVITY. Two separate findings — learn both." }
      ]
    },
    {
      title: "The Rivet Popper Hypothesis (Paul Ehrlich)",
      device: `Airplane = <b>ECOSYSTEM</b> · Rivets = <b>SPECIES</b> · Passengers popping rivets = <b>humans causing extinctions</b>`,
      expand: [
        { L: "✈", t: "The airplane is the ECOSYSTEM." },
        { L: "🔩", t: "The thousands of rivets holding it together are the SPECIES." },
        { L: "🧍", t: "Every passenger popping a rivet to take home = a species driven to extinction." },
        { L: "1", t: "At first, flight safety is NOT affected." },
        { L: "2", t: "But as MORE and MORE rivets are removed, the plane becomes DANGEROUSLY WEAK over time." },
        { L: "3", t: "WHICH rivet is removed is CRITICAL: losing rivets on the WINGS (key species) is far more serious than losing a few on the SEATS or WINDOWS." },
        { L: "★", t: "Proposed by the Stanford ecologist PAUL EHRLICH. Do not confuse him with Tilman." }
      ]
    },
    {
      title: "Extinction Threat % — 'Amphibians Get Massacred Badly'",
      device: `<b>A</b>mphibians 32% &gt; <b>G</b>ymnosperms 31% &gt; <b>M</b>ammals 23% &gt; <b>B</b>irds 12%`,
      expand: [
        { L: "A", t: "AMPHIBIANS — 32% face the threat of extinction. HIGHEST. They are also the group NCERT names as 'more vulnerable' — extinctions across taxa are NOT random." },
        { L: "G", t: "GYMNOSPERMS — 31%." },
        { L: "M", t: "MAMMALS — 23%." },
        { L: "B", t: "BIRDS — 12%. LOWEST." },
        { L: "★", t: "Just remember the descending run: 32, 31, 23, 12." }
      ]
    },
    {
      title: "The Extinction Ledger — 784 = 338 + 359 + 87",
      device: `<b>IUCN Red List (2004):</b> 784 species extinct in the last <b>500 years</b>`,
      expand: [
        { L: "784", t: "Total species documented extinct in the last 500 years." },
        { L: "338", t: "Vertebrates." },
        { L: "359", t: "Invertebrates — NOTE: invertebrates OUTNUMBER vertebrates. A favourite trick option." },
        { L: "87", t: "Plants." },
        { L: "27", t: "Species that disappeared in the last TWENTY YEARS alone." },
        { L: "15,500", t: "Species currently facing the threat of extinction worldwide." },
        { L: "2,000+", t: "Native bird species lost to the colonisation of tropical Pacific Islands by humans." }
      ]
    },
    {
      title: "The Dead — 'Dead Quartet Travelled South'",
      device: `<b>D</b>odo–Mauritius · <b>Q</b>uagga–Africa · <b>T</b>hylacine–Australia · <b>S</b>teller's Sea Cow–Russia`,
      expand: [
        { L: "D", t: "DODO — Mauritius." },
        { L: "Q", t: "QUAGGA — Africa." },
        { L: "T", t: "THYLACINE — Australia." },
        { L: "S", t: "STELLER'S SEA COW — Russia. (Also an OVER-EXPLOITATION example, along with the PASSENGER PIGEON.)" },
        { L: "🐅", t: "Plus THREE subspecies of TIGER: BALI, JAVAN and CASPIAN." }
      ]
    },
    {
      title: "The Sixth Extinction",
      device: `Current rate = <b>100 to 1,000 times FASTER</b> than pre-human · <b>HALF</b> of all species could go in <b>100 years</b>`,
      expand: [
        { L: "100–1000×", t: "Current species extinction rates are estimated to be 100 to 1,000 times faster than in pre-human times — and OUR activities are responsible." },
        { L: "50%", t: "If present trends continue, nearly HALF of all the species on earth might be wiped out within the next 100 YEARS." },
        { L: "3", t: "Consequences of loss in a region: (1) DECLINE in plant production, (2) LOWERED RESISTANCE to environmental perturbations such as drought, (3) INCREASED VARIABILITY in ecosystem processes (plant productivity, water use, pest and disease cycles)." }
      ]
    },
    {
      title: "Why Conserve — 'Nature's Bounty and Ethics'",
      device: `<b>N</b>arrowly utilitarian · <b>B</b>roadly utilitarian · <b>E</b>thical`,
      expand: [
        { L: "N", t: "NARROWLY UTILITARIAN — direct economic goods: food (cereals, pulses, fruits), firewood, fibre, construction material, industrial products (tannins, lubricants, dyes, resins, perfumes), medicines. >25% of drugs sold worldwide come from PLANTS; 25,000 plant species are used in traditional medicine. BIOPROSPECTING = exploring molecular, genetic and species diversity for products of economic importance." },
        { L: "B", t: "BROADLY UTILITARIAN — ecosystem services: the AMAZON produces ~20% of the earth's atmospheric OXYGEN; POLLINATION by bees, bumblebees, birds and bats; plus intangible AESTHETIC pleasures (the bulbul's song). 'Can we put a price tag on them?'" },
        { L: "E", t: "ETHICAL — every species has INTRINSIC VALUE, even with no economic value to us. We have a MORAL DUTY to care for their well-being and pass on our biological legacy in good order to future generations." }
      ]
    },
    {
      title: "The Three Indian Hotspots — 'We Indians Have'",
      device: `<b>W</b>estern Ghats &amp; Sri Lanka · <b>I</b>ndo-Burma · <b>H</b>imalaya`,
      expand: [
        { L: "W", t: "Western Ghats and Sri Lanka." },
        { L: "I", t: "Indo-Burma." },
        { L: "H", t: "Himalaya." },
        { L: "25+9", t: "Initially 25 hotspots were identified; 9 more were added → TOTAL 34 in the world." },
        { L: "<2%", t: "All hotspots together cover LESS THAN 2 PER CENT of the earth's land area." },
        { L: "30%", t: "Strict protection of hotspots could reduce ongoing mass extinctions by almost 30 PER CENT." },
        { L: "⚠", t: "Hotspots are defined by TWO criteria: very high SPECIES RICHNESS + high degree of ENDEMISM. They are also regions of ACCELERATED HABITAT LOSS." }
      ]
    },
    {
      title: "India's Protected Areas — '14 · 90 · 448'",
      device: `<b>14</b> Biosphere Reserves · <b>90</b> National Parks · <b>448</b> Wildlife Sanctuaries`,
      expand: [
        { L: "14", t: "Biosphere Reserves." },
        { L: "90", t: "National Parks." },
        { L: "448", t: "Wildlife Sanctuaries." },
        { L: "🌳", t: "Plus SACRED GROVES — Khasi & Jaintia Hills (Meghalaya), Aravalli Hills (Rajasthan), Western Ghats (Karnataka & Maharashtra), Sarguja/Chanda/Bastar (Madhya Pradesh)." },
        { L: "★", t: "All of these are IN SITU conservation. In MEGHALAYA, sacred groves are the LAST REFUGES for many rare and threatened plants." }
      ]
    },
    {
      title: "Ex Situ Toolkit — 'C-I-T-S'",
      device: `<b>C</b>ryopreservation · <b>I</b>n vitro fertilisation · <b>T</b>issue culture · <b>S</b>eed banks`,
      expand: [
        { L: "C", t: "CRYOPRESERVATION — gametes of threatened species preserved in VIABLE and FERTILE condition for long periods." },
        { L: "I", t: "IN VITRO fertilisation — eggs can be fertilised outside the body." },
        { L: "T", t: "TISSUE CULTURE — plants can be propagated." },
        { L: "S", t: "SEED BANKS — seeds of different GENETIC STRAINS of commercially important plants kept for long periods." },
        { L: "🏛", t: "The classic ex situ sites: ZOOLOGICAL PARKS, BOTANICAL GARDENS and WILDLIFE SAFARI PARKS. Many animals extinct in the wild survive only in zoological parks." }
      ]
    },
    {
      title: "The Two Summits — 'Rio 92, Joburg 02'",
      device: `<b>1992</b> Earth Summit, Rio de Janeiro &nbsp;|&nbsp; <b>2002</b> World Summit on Sustainable Development, Johannesburg`,
      expand: [
        { L: "1992", t: "The EARTH SUMMIT, RIO DE JANEIRO — called upon all nations to conserve biodiversity and use its benefits SUSTAINABLY." },
        { L: "2002", t: "The WORLD SUMMIT ON SUSTAINABLE DEVELOPMENT, JOHANNESBURG, SOUTH AFRICA." },
        { L: "190", t: "Number of COUNTRIES that pledged their commitment at Johannesburg." },
        { L: "2010", t: "The TARGET YEAR — a significant reduction in the current rate of biodiversity loss at GLOBAL, REGIONAL and LOCAL levels." },
        { L: "★", t: "'Biodiversity knows no political boundaries' — its conservation is a COLLECTIVE responsibility of all nations." }
      ]
    },
    {
      title: "The Global Species Split — '7 of every 10 animals is an insect'",
      device: `Animals <b>&gt;70%</b> · Plants <b>≤22%</b> · Insects = <b>70% of all animals</b>`,
      expand: [
        { L: ">70%", t: "of all DESCRIBED species are ANIMALS." },
        { L: "≤22%", t: "are PLANTS (including algae, fungi, bryophytes, gymnosperms and angiosperms)." },
        { L: "70%", t: "of all ANIMALS are INSECTS — the most species-rich taxonomic group. Out of every 10 animals, 7 are insects." },
        { L: "🍄", t: "The number of FUNGI species is MORE than the COMBINED total of fishes + amphibians + reptiles + mammals." },
        { L: "🦠", t: "PROKARYOTES are hugely under-counted: conventional taxonomy does not suit them, and many are NOT CULTURABLE in the lab. Molecular criteria would raise their diversity to 'biblical proportions'." },
        { L: "2.4 / 8.1", t: "INDIA: only 2.4% of the world's land area, but 8.1% of global species diversity. One of the 12 MEGA-DIVERSITY countries." }
      ]
    }
  ],

  /* ---------- 4. FLASHCARDS (107) ---------- */
  flashcards: [
    { front: "Who popularised the term 'biodiversity', and what was his profession?", back: "EDWARD WILSON — a SOCIOBIOLOGIST." },
    { front: "Define biodiversity.", back: "The combined diversity at ALL the levels of biological organisation — from macromolecules within cells to biomes." },
    { front: "Name the three important components (levels) of biodiversity.", back: "1. GENETIC diversity, 2. SPECIES diversity, 3. ECOLOGICAL diversity." },
    { front: "Give NCERT's example of GENETIC diversity.", back: "Rauwolfia vomitoria, a medicinal plant growing in different HIMALAYAN ranges, shows genetic variation in the POTENCY and CONCENTRATION of the active chemical RESERPINE it produces." },
    { front: "Which two Indian crop statistics illustrate genetic diversity?", back: "India has more than 50,000 genetically different STRAINS OF RICE, and 1,000 varieties of MANGO." },
    { front: "Give NCERT's example of SPECIES diversity.", back: "The WESTERN GHATS have a greater AMPHIBIAN species diversity than the EASTERN GHATS." },
    { front: "Give NCERT's example of ECOLOGICAL diversity.", back: "INDIA — with its deserts, rain forests, mangroves, coral reefs, wetlands, estuaries and alpine meadows — has greater ECOSYSTEM diversity than a Scandinavian country like NORWAY." },
    { front: "According to IUCN (2004), how many plant and animal species have been described so far?", back: "Slightly more than 1.5 MILLION." },
    { front: "What is Robert May's estimate of global species diversity?", back: "About 7 MILLION. (Extreme, less reliable estimates range from 20 to 50 million.)" },
    { front: "What percentage of described species are animals, and what percentage are plants?", back: "ANIMALS: more than 70 PER CENT. PLANTS (including algae, fungi, bryophytes, gymnosperms, angiosperms): no more than 22 PER CENT." },
    { front: "Which is the most species-rich taxonomic group among animals, and what share do they hold?", back: "INSECTS — 70 PER CENT of all animals. Out of every 10 animals on this planet, 7 are insects." },
    { front: "How does the number of fungi species compare with vertebrate groups?", back: "The number of FUNGI species in the world is MORE than the COMBINED total of the species of FISHES + AMPHIBIANS + REPTILES + MAMMALS." },
    { front: "Why are prokaryotes not adequately represented in species counts?", back: "1. Conventional TAXONOMIC METHODS are not suitable for identifying microbial species. 2. Many prokaryotes are NOT CULTURABLE under laboratory conditions. If biochemical/molecular criteria were used, their diversity would rise to 'biblical proportions'." },
    { front: "What percentage of the world's land area does India occupy, and what is its share of global species diversity?", back: "Land area: only 2.4 PER CENT. Species diversity: an impressive 8.1 PER CENT. India is one of the 12 MEGA-DIVERSITY countries." },
    { front: "How many plant and animal species have been recorded from India?", back: "Nearly 45,000 species of PLANTS and TWICE as many ANIMALS (about 90,000)." },
    { front: "How many species does India still have left to discover, applying May's estimate?", back: "More than 1,00,000 PLANT species and more than 3,00,000 ANIMAL species — because only about 22 per cent of the total species have been recorded so far." },
    { front: "How do ecologists estimate the total number of species in the world?", back: "They make a STATISTICAL COMPARISON of the temperate vs tropical species richness of an EXHAUSTIVELY STUDIED GROUP OF INSECTS, then EXTRAPOLATE that ratio to other groups of animals and plants." },
    { front: "State the latitudinal gradient rule.", back: "Species diversity DECREASES as we move AWAY from the equator TOWARDS the poles. With very few exceptions, the TROPICS harbour MORE species than temperate or polar areas." },
    { front: "What is the latitudinal range of the tropics?", back: "23.5° N to 23.5° S." },
    { front: "How many bird species does Colombia have, and why is that significant?", back: "Nearly 1,400 — because Colombia is located NEAR THE EQUATOR." },
    { front: "How many bird species do New York and Greenland have, and at what latitudes?", back: "NEW YORK at 41° N: 105 species. GREENLAND at 71° N: only 56 species." },
    { front: "How many bird species does India have?", back: "More than 1,200 — because much of its land area lies in tropical latitudes." },
    { front: "How does a tropical forest in Ecuador compare with a temperate forest in the Midwest USA?", back: "The Ecuadorian forest has up to 10 TIMES as many species of VASCULAR PLANTS as a forest of equal area in the Midwest of the USA." },
    { front: "Which region has the greatest biodiversity on Earth?", back: "The AMAZONIAN RAIN FOREST in South America." },
    { front: "List the Amazon's species numbers for plants, fishes and birds.", back: "PLANTS: more than 40,000. FISHES: 3,000. BIRDS: 1,300." },
    { front: "List the Amazon's species numbers for mammals, amphibians and reptiles.", back: "MAMMALS: 427. AMPHIBIANS: 427 (the same!). REPTILES: 378." },
    { front: "How many invertebrates does the Amazon have, and how many insects remain undiscovered there?", back: "More than 1,25,000 INVERTEBRATES. Scientists estimate at least 2 MILLION insect species remain to be discovered and named." },
    { front: "State the TIME hypothesis for greater tropical species richness.", back: "Speciation is generally a FUNCTION OF TIME. Unlike temperate regions, which were subjected to frequent GLACIATIONS in the past, TROPICAL latitudes have remained relatively UNDISTURBED for MILLIONS OF YEARS — giving a long evolutionary time for species diversification." },
    { front: "State the CONSTANCY hypothesis for greater tropical species richness.", back: "Tropical environments, unlike temperate ones, are LESS SEASONAL, relatively more CONSTANT and PREDICTABLE. Such constant environments promote NICHE SPECIALISATION, leading to greater species diversity." },
    { front: "State the ENERGY hypothesis for greater tropical species richness.", back: "There is MORE SOLAR ENERGY available in the tropics, which contributes to HIGHER PRODUCTIVITY — this in turn might contribute INDIRECTLY to greater diversity." },
    { front: "Who discovered the species–area relationship, and where?", back: "ALEXANDER VON HUMBOLDT, during his pioneering and extensive explorations in the SOUTH AMERICAN JUNGLES." },
    { front: "What did Humboldt observe?", back: "That within a region, SPECIES RICHNESS INCREASED with increasing EXPLORED AREA — but only UP TO A LIMIT." },
    { front: "What shape is the species–area curve on a normal scale?", back: "A RECTANGULAR HYPERBOLA." },
    { front: "What shape does the species–area relationship take on a LOGARITHMIC scale?", back: "A STRAIGHT LINE." },
    { front: "Write the species–area equation and define every term.", back: "log S = log C + Z log A. S = species richness; A = area; Z = SLOPE of the line (regression coefficient); C = Y-INTERCEPT." },
    { front: "What is the value of Z for small areas within a region?", back: "0.1 to 0.2 — and it is amazingly similar REGARDLESS of the taxonomic group or the region (plants in Britain, birds in California, molluscs in New York state)." },
    { front: "What is the value of Z for very large areas like entire continents?", back: "0.6 to 1.2 — the slope of the line is MUCH STEEPER." },
    { front: "What is the Z value for frugivorous birds and mammals in tropical forests of different continents?", back: "1.15." },
    { front: "What does 'frugivorous' mean?", back: "FRUIT-EATING." },
    { front: "What is the significance of the slope (Z) of the regression line?", back: "Z tells you HOW FAST species richness rises with area. A small Z (0.1–0.2) means richness climbs SLOWLY — you keep sampling the same regional species pool. A large Z (0.6–1.2) means richness climbs STEEPLY — each continent brings an entirely DIFFERENT species pool." },
    { front: "For which taxa was the species–area relationship found to hold?", back: "A wide variety — angiosperm plants, BIRDS, BATS and FRESHWATER FISHES." },
    { front: "What do ecologists believe about species number and community stability?", back: "Communities with MORE SPECIES tend to be MORE STABLE than those with fewer species." },
    { front: "What are the three conditions for a community to be called STABLE?", back: "1. It does NOT show much variation in PRODUCTIVITY from year to year. 2. It is RESISTANT or RESILIENT to occasional DISTURBANCES (natural or man-made). 3. It is RESISTANT to INVASIONS by ALIEN SPECIES." },
    { front: "What kind of experiments did David Tilman run, and what were his TWO findings?", back: "Long-term ecosystem experiments using OUTDOOR PLOTS. (1) Plots with MORE species showed LESS year-to-year VARIATION in total BIOMASS. (2) Increased diversity contributed to HIGHER PRODUCTIVITY." },
    { front: "Who proposed the 'rivet popper hypothesis'?", back: "PAUL EHRLICH (the Stanford ecologist)." },
    { front: "In the rivet popper hypothesis, what do the airplane and the rivets represent?", back: "The AIRPLANE = the ECOSYSTEM. The RIVETS = the SPECIES." },
    { front: "In the rivet popper analogy, why does WHICH rivet is popped matter?", back: "Because loss of rivets on the WINGS is a far more serious threat to flight safety than loss of a few rivets on the SEATS or WINDOWS. Similarly, losing a KEY species threatens the whole ecosystem far more than losing a peripheral one." },
    { front: "What does NCERT conclude about the importance of rich biodiversity?", back: "Rich biodiversity is NOT ONLY essential for ecosystem health BUT IMPERATIVE FOR THE VERY SURVIVAL OF THE HUMAN RACE on this planet." },
    { front: "How many native bird species were lost to the colonisation of tropical Pacific Islands by humans?", back: "More than 2,000." },
    { front: "According to the IUCN Red List (2004), how many species went extinct in the last 500 years, and how do they break down?", back: "784 species: 338 VERTEBRATES + 359 INVERTEBRATES + 87 PLANTS. (Note: invertebrates OUTNUMBER vertebrates.)" },
    { front: "Name four species that went extinct recently, with their regions.", back: "DODO — Mauritius. QUAGGA — Africa. THYLACINE — Australia. STELLER'S SEA COW — Russia." },
    { front: "Which three subspecies of tiger have gone extinct?", back: "BALI, JAVAN and CASPIAN." },
    { front: "How many species disappeared in the last twenty years alone?", back: "27." },
    { front: "How many species worldwide are presently facing the threat of extinction?", back: "15,500." },
    { front: "Which taxonomic group does NCERT single out as being MORE VULNERABLE to extinction?", back: "AMPHIBIANS. Extinctions across taxa are NOT RANDOM." },
    { front: "What percentages of birds, mammals, amphibians and gymnosperms face the threat of extinction?", back: "BIRDS 12%, MAMMALS 23%, AMPHIBIANS 32%, GYMNOSPERMS 31%. Descending order: Amphibians (32) > Gymnosperms (31) > Mammals (23) > Birds (12)." },
    { front: "How much faster are current extinction rates than in pre-human times?", back: "100 to 1,000 TIMES faster — and our activities are responsible." },
    { front: "What is the 'Sixth Extinction' warning?", back: "If present trends continue, NEARLY HALF of all the species on Earth might be WIPED OUT within the next 100 YEARS." },
    { front: "List the three consequences of biodiversity loss in a region.", back: "1. DECLINE in plant production. 2. LOWERED RESISTANCE to environmental perturbations such as drought. 3. INCREASED VARIABILITY in certain ecosystem processes — plant productivity, water use, and pest and disease cycles." },
    { front: "Name the four causes of biodiversity loss (the Evil Quartet).", back: "1. HABITAT LOSS AND FRAGMENTATION. 2. OVER-EXPLOITATION. 3. ALIEN SPECIES INVASIONS. 4. CO-EXTINCTIONS." },
    { front: "Which is the MOST IMPORTANT cause driving animals and plants to extinction?", back: "HABITAT LOSS AND FRAGMENTATION." },
    { front: "What has happened to the world's tropical rain forests?", back: "They once covered more than 14 PER CENT of the earth's land surface; they now cover NO MORE THAN 6 PER CENT." },
    { front: "Why is the Amazon rain forest called the 'lungs of the planet', and what is it being cleared for?", back: "It is so huge that it earns the name. It is being cut and cleared for cultivating SOYA BEANS or for conversion to grasslands for raising BEEF CATTLE." },
    { front: "Besides total loss, what else threatens habitats?", back: "The DEGRADATION of many habitats by POLLUTION." },
    { front: "Which animals are worst affected by habitat FRAGMENTATION?", back: "MAMMALS AND BIRDS REQUIRING LARGE TERRITORIES, and certain animals with MIGRATORY HABITS — leading to population declines." },
    { front: "When does exploitation become over-exploitation?", back: "When 'NEED' turns to 'GREED'." },
    { front: "Give two species driven extinct by over-exploitation.", back: "STELLER'S SEA COW and the PASSENGER PIGEON." },
    { front: "Which populations are being over-harvested today?", back: "Many MARINE FISH populations around the world — endangering the continued existence of some commercially important species." },
    { front: "What happened when the Nile perch was introduced into Lake Victoria?", back: "It led eventually to the EXTINCTION of an ecologically unique assemblage of MORE THAN 200 SPECIES of CICHLID FISH in the lake." },
    { front: "Where is Lake Victoria?", back: "In EAST AFRICA." },
    { front: "Name three invasive weed species that threaten India's native species.", back: "CARROT GRASS (Parthenium), LANTANA, and WATER HYACINTH (Eichhornia)." },
    { front: "Which fish was illegally introduced into Indian rivers for aquaculture, and what is the threat?", back: "The AFRICAN CATFISH, Clarias gariepinus — it is posing a threat to the INDIGENOUS CATFISHES in our rivers." },
    { front: "Define co-extinction and give NCERT's two examples.", back: "When a species becomes extinct, the plant and animal species associated with it in an OBLIGATORY way also become extinct. Examples: (1) when a HOST FISH species becomes extinct, its unique assemblage of PARASITES meets the same fate; (2) in a CO-EVOLVED PLANT–POLLINATOR MUTUALISM, extinction of one invariably leads to the extinction of the other." },
    { front: "Name the three categories of reasons for conserving biodiversity.", back: "1. NARROWLY UTILITARIAN. 2. BROADLY UTILITARIAN. 3. ETHICAL." },
    { front: "What are the NARROWLY UTILITARIAN reasons for conservation?", back: "Direct economic benefits: FOOD (cereals, pulses, fruits), FIREWOOD, FIBRE, CONSTRUCTION MATERIAL, INDUSTRIAL PRODUCTS (tannins, lubricants, dyes, resins, perfumes) and PRODUCTS OF MEDICINAL IMPORTANCE." },
    { front: "What percentage of drugs sold worldwide are derived from plants?", back: "More than 25 PER CENT." },
    { front: "How many plant species contribute to traditional medicines used by native peoples?", back: "25,000 species." },
    { front: "Define bioprospecting.", back: "Exploring MOLECULAR, GENETIC and SPECIES-LEVEL diversity for PRODUCTS OF ECONOMIC IMPORTANCE. Nations rich in biodiversity can reap enormous benefits from it." },
    { front: "What are the BROADLY UTILITARIAN reasons for conservation?", back: "Ecosystem services: the AMAZON produces ~20% of the total OXYGEN in the earth's atmosphere; POLLINATION by bees, bumblebees, birds and bats; and intangible AESTHETIC pleasures." },
    { front: "What proportion of the Earth's atmospheric oxygen does the Amazon forest produce?", back: "An estimated 20 PER CENT, through photosynthesis." },
    { front: "Which pollinators does NCERT name?", back: "BEES, BUMBLEBEES, BIRDS and BATS." },
    { front: "State the ETHICAL argument for conserving biodiversity.", back: "Every species has an INTRINSIC VALUE, even if it has no current or any economic value to us. We have a MORAL DUTY to care for their well-being and to pass on our BIOLOGICAL LEGACY in good order to future generations." },
    { front: "Define in situ conservation.", back: "Conserving and protecting the WHOLE ECOSYSTEM in its NATURAL HABITAT, so that biodiversity at ALL levels is protected. 'We save the entire forest to save the tiger.'" },
    { front: "Define ex situ conservation.", back: "Threatened animals and plants are TAKEN OUT of their natural habitat and placed in a SPECIAL SETTING where they can be protected and given SPECIAL CARE." },
    { front: "What TWO criteria define a biodiversity hotspot?", back: "1. Very high levels of SPECIES RICHNESS. 2. A high degree of ENDEMISM — species confined to that region and found nowhere else." },
    { front: "Define endemism.", back: "The condition of species being CONFINED TO A PARTICULAR REGION and NOT FOUND ANYWHERE ELSE." },
    { front: "How many biodiversity hotspots are there in the world, and how did the number arise?", back: "34. Initially 25 were identified; subsequently 9 MORE were added." },
    { front: "Name the three biodiversity hotspots covering India.", back: "1. WESTERN GHATS AND SRI LANKA. 2. INDO-BURMA. 3. HIMALAYA." },
    { front: "What land area do all the world's biodiversity hotspots cover, and what could their strict protection achieve?", back: "LESS THAN 2 PER CENT of the earth's land area. Strict protection could REDUCE THE ONGOING MASS EXTINCTIONS BY ALMOST 30 PER CENT." },
    { front: "Besides being species-rich, what else characterises biodiversity hotspots?", back: "They are also regions of ACCELERATED HABITAT LOSS — which is exactly why they are urgent." },
    { front: "How many biosphere reserves, national parks and wildlife sanctuaries does India have?", back: "14 BIOSPHERE RESERVES, 90 NATIONAL PARKS and 448 WILDLIFE SANCTUARIES." },
    { front: "What are sacred groves?", back: "Tracts of forest SET ASIDE by cultural and religious tradition, where ALL the TREES and WILDLIFE within were VENERATED and given TOTAL PROTECTION." },
    { front: "Where in India are sacred groves found?", back: "KHASI and JAINTIA HILLS (Meghalaya), ARAVALLI HILLS (Rajasthan), WESTERN GHAT regions of KARNATAKA and MAHARASHTRA, and SARGUJA, CHANDA and BASTAR areas of MADHYA PRADESH." },
    { front: "What is the special significance of sacred groves in Meghalaya?", back: "They are the LAST REFUGES for a large number of RARE and THREATENED PLANTS." },
    { front: "Are sacred groves in situ or ex situ conservation?", back: "IN SITU — the whole habitat is protected in place, by community and cultural tradition." },
    { front: "Name the classic ex situ conservation sites.", back: "ZOOLOGICAL PARKS, BOTANICAL GARDENS and WILDLIFE SAFARI PARKS." },
    { front: "How has ex situ conservation advanced beyond keeping species in enclosures?", back: "1. GAMETES of threatened species preserved in viable and fertile condition by CRYOPRESERVATION. 2. Eggs fertilised IN VITRO. 3. Plants propagated using TISSUE CULTURE. 4. SEEDS of different genetic strains kept in SEED BANKS." },
    { front: "What is cryopreservation used for in conservation?", back: "Preserving the GAMETES of threatened species in VIABLE AND FERTILE CONDITION for long periods." },
    { front: "What was the Earth Summit, and when and where was it held?", back: "The EARTH SUMMIT, held in RIO DE JANEIRO in 1992. It called upon all nations to take appropriate measures for the conservation of biodiversity and the SUSTAINABLE UTILISATION of its benefits." },
    { front: "What was the World Summit on Sustainable Development, and what was pledged?", back: "Held in 2002 in JOHANNESBURG, SOUTH AFRICA. 190 COUNTRIES pledged to achieve, by 2010, a SIGNIFICANT REDUCTION in the current rate of biodiversity loss at GLOBAL, REGIONAL and LOCAL levels." },
    { front: "Why is biodiversity conservation a collective responsibility of all nations?", back: "Because BIODIVERSITY KNOWS NO POLITICAL BOUNDARIES." },
    { front: "How do the biotic components of an ecosystem control floods and soil erosion?", back: "ROOTS BIND soil particles; the CANOPY INTERCEPTS rainfall, softening its impact; LITTER and HUMUS INCREASE INFILTRATION and water-holding capacity; and VEGETATION SLOWS surface run-off so water percolates rather than flooding." },
    { front: "Why did animals (72%) achieve greater diversification than plants (22%)?", back: "1. Greater MOTILITY — animals can escape adverse conditions and colonise new habitats. 2. Complex and sensitive NERVOUS SYSTEMS to perceive and respond to environmental stimuli. 3. The RIGID EXOSKELETON in arthropods, providing protection and support." },
    { front: "Can you think of a species we would deliberately want to make extinct? Justify it.", back: "YES — disease-causing pathogens. The SMALLPOX VIRUS was deliberately eradicated worldwide through vaccination. Justification: HUMAN WELFARE — it caused enormous suffering and death, and its removal deprives no ecosystem of a service." },
    { front: "Which is the biggest reservoir of undiscovered species — temperate or tropical regions?", back: "TROPICAL regions. Species inventories are MORE COMPLETE in TEMPERATE than in tropical countries, so an overwhelmingly large proportion of species waiting to be discovered are in the TROPICS." },
    { front: "Is speciation currently adding new species to the Earth's treasury?", back: "It is DOUBTFUL whether any new species are being added through speciation — but there is NO DOUBT about their continuing LOSSES, and the accusing finger points at HUMAN ACTIVITIES." },
    { front: "Give the full list of India's ecological diversity (the 'India vs Norway' example).", back: "DESERTS, RAIN FORESTS, MANGROVES, CORAL REEFS, WETLANDS, ESTUARIES and ALPINE MEADOWS." }
  ],

  /* ---------- 5. ACTIVE RECALL (52) ---------- */
  recall: [
    { q: "Define biodiversity, name who popularised the term, and list its three components. (NCERT Exercise Q1)", hint: "A sociobiologist. Three levels.", a: "<b>Biodiversity</b> is the term popularised by the <b>sociobiologist EDWARD WILSON</b> to describe the <b>combined diversity at ALL the levels of biological organisation</b> — from <b>macromolecules within cells to biomes</b>.<br><br><b>The three components:</b><br><b>1. GENETIC diversity</b><br><b>2. SPECIES diversity</b><br><b>3. ECOLOGICAL diversity</b>" },
    { q: "Explain GENETIC diversity with all three of NCERT's examples.", hint: "One plant, two crops.", a: "<b>Genetic diversity</b> = a <b>single species</b> showing high diversity <b>at the genetic level</b> over its distributional range.<br><br>• <b><i>Rauwolfia vomitoria</i></b>, a medicinal plant growing in different <b>Himalayan ranges</b>, shows genetic variation in the <b>POTENCY and CONCENTRATION of the active chemical RESERPINE</b> that it produces.<br>• India has more than <b>50,000 genetically different STRAINS of RICE</b>.<br>• India has <b>1,000 varieties of MANGO</b>.<br><br><b>Trap:</b> genetic diversity is always <b>WITHIN one species</b>." },
    { q: "Explain SPECIES and ECOLOGICAL diversity with NCERT's examples.", hint: "Two Ghats. Two countries.", a: "<b>SPECIES diversity</b> — diversity at the species level.<br><i>Example:</i> the <b>WESTERN GHATS have a greater AMPHIBIAN species diversity than the EASTERN GHATS</b>.<br><br><b>ECOLOGICAL diversity</b> — diversity at the ecosystem level.<br><i>Example:</i> <b>INDIA</b>, with its <b>deserts, rain forests, mangroves, coral reefs, wetlands, estuaries and alpine meadows</b>, has <b>greater ecosystem diversity than a Scandinavian country like NORWAY</b>." },
    { q: "Give the global species number bank: described, estimated, and the animal/plant/insect split.", hint: "1.5, 7, 70, 22, 70.", a: "<b>Described so far (IUCN 2004):</b> slightly more than <b>1.5 MILLION</b> species.<br><b>Robert May's conservative estimate:</b> about <b>7 MILLION</b>. (Extreme estimates: 20–50 million.)<br><br><b>ANIMALS:</b> more than <b>70%</b> of described species.<br><b>PLANTS</b> (algae, fungi, bryophytes, gymnosperms, angiosperms): <b>no more than 22%</b>.<br><b>INSECTS:</b> the most species-rich taxonomic group — <b>70% of all animals</b>. Out of every <b>10 animals</b>, <b>7 are insects</b>.<br><br><b>Bonus:</b> the number of <b>FUNGI</b> species exceeds the <b>COMBINED total of fishes + amphibians + reptiles + mammals</b>." },
    { q: "Why are prokaryotes so badly under-counted?", hint: "Two reasons. And one memorable phrase.", a: "<b>1.</b> <b>Conventional taxonomic methods are NOT suitable</b> for identifying microbial species.<br><b>2.</b> Many prokaryotes are <b>NOT CULTURABLE under laboratory conditions</b>.<br><br>If <b>biochemical or molecular criteria</b> were applied instead, their diversity would be elevated to <b>'biblical proportions'</b>." },
    { q: "Give India's biodiversity statistics in full.", hint: "2.4, 8.1, 12, 45,000, 90,000.", a: "• India has only <b>2.4 per cent</b> of the world's <b>LAND AREA</b>…<br>• …but its share of <b>global SPECIES diversity</b> is an impressive <b>8.1 per cent</b>.<br>• This makes India one of the <b>12 MEGA-DIVERSITY COUNTRIES</b> of the world.<br>• Nearly <b>45,000 species of PLANTS</b> and <b>TWICE as many ANIMALS</b> (about <b>90,000</b>) have been recorded from India.<br>• Applying Robert May's estimate (only <b>22%</b> of species recorded), India still has more than <b>1,00,000 plant species</b> and more than <b>3,00,000 animal species</b> yet to be discovered.<br><br><b>Mnemonic: 'Small land (2.4), big life (8.1).'</b>" },
    { q: "How do ecologists estimate the total number of species present in the world? (NCERT Exercise Q2)", hint: "Insects, and a ratio.", a: "Species inventories are <b>more complete in TEMPERATE than in TROPICAL countries</b>, yet an overwhelmingly large proportion of the species waiting to be discovered are <b>in the tropics</b>.<br><br>So biologists:<br><b>1.</b> Take an <b>exhaustively studied group of INSECTS</b>.<br><b>2.</b> Make a <b>STATISTICAL COMPARISON</b> of its <b>temperate vs tropical species richness</b>.<br><b>3.</b> <b>EXTRAPOLATE</b> that ratio to <b>other groups of animals and plants</b>.<br><b>4.</b> Arrive at a <b>gross estimate of global species diversity</b>." },
    { q: "State the latitudinal gradient and give all four bird numbers.", hint: "Colombia, India, New York, Greenland.", a: "<b>The rule:</b> species diversity <b>DECREASES as we move away from the equator towards the poles</b>. With very few exceptions, the <b>TROPICS (23.5° N to 23.5° S)</b> harbour more species than temperate or polar areas.<br><br><b>Colombia</b> (near the equator): nearly <b>1,400</b> bird species<br><b>India</b> (much land in the tropics): more than <b>1,200</b><br><b>New York</b> (41° N): <b>105</b><br><b>Greenland</b> (71° N): only <b>56</b>" },
    { q: "Give the plant-diversity gradient example, and describe the Amazon rain forest completely.", hint: "Ecuador vs Midwest. Then seven numbers.", a: "<b>Plant gradient:</b> a forest in a tropical region like <b>ECUADOR</b> has up to <b>10 TIMES as many species of VASCULAR PLANTS</b> as a forest of equal area in a temperate region like the <b>MIDWEST of the USA</b>.<br><br><b>The AMAZONIAN RAIN FOREST</b> — the greatest biodiversity on Earth:<br>• Plants: more than <b>40,000</b><br>• Fishes: <b>3,000</b><br>• Birds: <b>1,300</b><br>• Mammals: <b>427</b><br>• Amphibians: <b>427</b> <i>(the same — use this coincidence as your anchor)</i><br>• Reptiles: <b>378</b><br>• Invertebrates: more than <b>1,25,000</b><br>• Insects <b>waiting to be discovered</b>: at least <b>2 MILLION</b>" },
    { q: "Give three hypotheses for explaining why tropics show the greatest levels of species richness. (NCERT Exercise Q3)", hint: "Time, Constancy, Energy.", a: "<b>(a) TIME.</b> Speciation is generally a <b>function of time</b>. Unlike temperate regions — subjected to <b>frequent GLACIATIONS</b> in the past — <b>tropical latitudes have remained relatively UNDISTURBED for millions of years</b>, and thus had a <b>long evolutionary time for species diversification</b>.<br><br><b>(b) CONSTANCY.</b> Tropical environments, unlike temperate ones, are <b>less seasonal, relatively more CONSTANT and PREDICTABLE</b>. Such constant environments <b>promote NICHE SPECIALISATION</b> and lead to greater species diversity.<br><br><b>(c) ENERGY.</b> There is <b>more SOLAR ENERGY available in the tropics</b>, which contributes to <b>higher PRODUCTIVITY</b>; this in turn might contribute <b>INDIRECTLY</b> to greater diversity." },
    { q: "Describe the species–area relationship: who found it, where, its shape, and its equation.", hint: "Humboldt. Rectangular hyperbola. Then logs.", a: "<b>ALEXANDER VON HUMBOLDT</b>, during his pioneering and extensive explorations in the <b>SOUTH AMERICAN JUNGLES</b>, observed that within a region <b>species richness increased with increasing explored AREA — but only UP TO A LIMIT</b>.<br><br>For a wide variety of taxa (<b>angiosperm plants, birds, bats, freshwater fishes</b>), the relation between species richness and area is a <b>RECTANGULAR HYPERBOLA</b>.<br><br>On a <b>LOGARITHMIC scale</b>, the relationship becomes a <b>STRAIGHT LINE</b>:<br><br><b>log S = log C + Z log A</b><br>S = species richness · A = area · <b>Z = slope of the line (regression coefficient)</b> · <b>C = Y-intercept</b>" },
    { q: "What is the significance of the slope of regression in a species–area relationship? Give all three Z values. (NCERT Exercise Q4)", hint: "0.1–0.2, 0.6–1.2, 1.15.", a: "<b>Z is the SLOPE — the regression coefficient.</b> It tells you <b>HOW FAST species richness rises with area</b>.<br><br><b>Z = 0.1 to 0.2</b> — for <b>small areas within a region</b>. Amazingly similar <b>regardless of the taxonomic group or the region</b> (plants in Britain, birds in California, molluscs in New York state). Richness climbs <b>SLOWLY</b>, because you keep sampling the same regional species pool.<br><br><b>Z = 0.6 to 1.2</b> — for <b>very large areas like entire CONTINENTS</b>. The slope is <b>MUCH STEEPER</b>: each new continent brings an entirely <b>different</b> species pool.<br><br><b>Z = 1.15</b> — for <b>FRUGIVOROUS (fruit-eating) birds and mammals</b> in the tropical forests of different continents.<br><br><b>Why it matters:</b> the consistency of the small-area Z across taxa and continents is what makes this a genuine <b>ecological law</b>, not a coincidence." },
    { q: "How is biodiversity important for ecosystem functioning? (NCERT Exercise Q6)", hint: "Stability + Tilman + Ehrlich.", a: "Ecologists have <b>not been able to give a definitive answer</b>, but the evidence points one way: <b>communities with MORE species tend to be MORE STABLE</b>.<br><br><b>Stability means three things:</b><br>1. It does <b>not show much variation in PRODUCTIVITY from year to year</b>.<br>2. It is <b>RESISTANT or RESILIENT to occasional DISTURBANCES</b> (natural or man-made).<br>3. It is <b>RESISTANT to INVASIONS by ALIEN species</b>.<br><br><b>DAVID TILMAN's outdoor-plot experiments:</b><br>• Plots with <b>more species</b> showed <b>LESS year-to-year variation in total BIOMASS</b>.<br>• <b>Increased diversity contributed to HIGHER PRODUCTIVITY</b>.<br><br><b>Conclusion:</b> rich biodiversity is <b>not only essential for ecosystem health but IMPERATIVE for the very SURVIVAL of the human race</b>." },
    { q: "Explain the Rivet Popper Hypothesis in full, including who proposed it and the wing-vs-seat point.", hint: "Ehrlich. Plane, rivets, passengers.", a: "Proposed by <b>PAUL EHRLICH</b>.<br><br><b>The analogy:</b><br>• The <b>AIRPLANE</b> = the <b>ECOSYSTEM</b>.<br>• The thousands of <b>RIVETS</b> holding it together = the <b>SPECIES</b>.<br>• Every <b>passenger popping a rivet</b> to take home = a <b>species driven to extinction</b>.<br><br><b>The argument:</b><br>1. Initially, popping a few rivets <b>may not affect flight safety</b> (the proper functioning of the ecosystem).<br>2. But as <b>more and more rivets are removed</b>, the plane becomes <b>DANGEROUSLY WEAK over a period of time</b>.<br>3. Furthermore, <b>WHICH rivet is removed is CRITICAL</b>: loss of rivets on the <b>WINGS</b> is obviously a <b>more serious threat</b> to flight safety than the loss of a few rivets on the <b>SEATS or WINDOWS</b> inside the plane.<br><br><b>Meaning:</b> the loss of a <b>KEY species</b> is far more dangerous than the loss of a peripheral one." },
    { q: "Give the complete extinction number bank.", hint: "2000, 784, 27, 15,500, 100–1000, 50%.", a: "• Colonisation of <b>tropical Pacific Islands</b> by humans → extinction of more than <b>2,000 species of native birds</b>.<br>• <b>IUCN Red List (2004)</b>: <b>784 species</b> extinct in the last <b>500 years</b> — <b>338 vertebrates + 359 invertebrates + 87 plants</b>. <i>(Note: invertebrates OUTNUMBER vertebrates. 338 + 359 + 87 = 784.)</i><br>• The last <b>20 years alone</b> saw the disappearance of <b>27 species</b>.<br>• Presently <b>15,500 species</b> worldwide face the threat of extinction.<br>• Current extinction rates are <b>100 to 1,000 TIMES FASTER</b> than in pre-human times.<br>• If present trends continue, <b>nearly HALF of all species on earth</b> could be wiped out within the next <b>100 YEARS</b> — <b>the Sixth Extinction</b>." },
    { q: "Name the recent extinctions with their regions, and state which group is most vulnerable.", hint: "Four species, four places, three tiger subspecies.", a: "<b>DODO</b> — Mauritius<br><b>QUAGGA</b> — Africa<br><b>THYLACINE</b> — Australia<br><b>STELLER'S SEA COW</b> — Russia<br><b>Three subspecies of TIGER</b> — <b>Bali, Javan, Caspian</b><br><br><b>Extinctions across taxa are NOT RANDOM.</b> Some groups are more vulnerable — NCERT singles out <b>AMPHIBIANS</b>.<br><br><b>Percentages facing extinction:</b> Amphibians <b>32%</b> &gt; Gymnosperms <b>31%</b> &gt; Mammals <b>23%</b> &gt; Birds <b>12%</b>." },
    { q: "List the three consequences of biodiversity loss in a region.", hint: "Production, resistance, variability.", a: "<b>1.</b> <b>DECLINE in plant PRODUCTION.</b><br><b>2.</b> <b>LOWERED RESISTANCE to environmental perturbations</b> such as <b>drought</b>.<br><b>3.</b> <b>INCREASED VARIABILITY in certain ecosystem processes</b> — <b>plant productivity, water use, and pest and disease cycles</b>." },
    { q: "What are the major causes of species losses in a geographical region? (NCERT Exercise Q5) Name and rank them.", hint: "The Evil Quartet — and one is the most important.", a: "<b>THE EVIL QUARTET</b> — mnemonic: <b>'Humans Over-Ate Creation'</b><br><br><b>1. HABITAT LOSS AND FRAGMENTATION</b> — <b>the MOST IMPORTANT cause</b>.<br><b>2. OVER-EXPLOITATION</b><br><b>3. ALIEN SPECIES INVASIONS</b><br><b>4. CO-EXTINCTIONS</b><br><br>If a question asks for the <b>single most important</b> cause, the answer is <b>always habitat loss and fragmentation</b>." },
    { q: "Explain habitat loss and fragmentation fully — with the rain forest numbers.", hint: "14 → 6. Soya beans and beef.", a: "This is the <b>MOST IMPORTANT cause</b> driving animals and plants to extinction.<br><br>• <b>Tropical rain forests</b> once covered more than <b>14 PER CENT</b> of the earth's land surface; they now cover <b>NO MORE THAN 6 PER CENT</b>.<br>• The <b>AMAZON rain forest</b> — so huge that it is called the <b>'LUNGS OF THE PLANET'</b> — harbours probably millions of species, and is being <b>cut and cleared for cultivating SOYA BEANS</b> or for <b>conversion to grasslands for raising BEEF CATTLE</b>.<br>• Besides total loss, the <b>DEGRADATION of many habitats by POLLUTION</b> also threatens survival.<br>• <b>FRAGMENTATION:</b> when large habitats are broken into small fragments, <b>mammals and birds requiring LARGE TERRITORIES</b>, and animals with <b>MIGRATORY habits</b>, are <b>badly affected</b> — leading to <b>population declines</b>." },
    { q: "Explain over-exploitation with NCERT's examples.", hint: "Need vs greed.", a: "Humans have always depended on nature for food and shelter, but <b>when 'NEED' turns to 'GREED'</b>, it leads to <b>over-exploitation of natural resources</b>.<br><br>• Species extinctions in the last 500 years due to over-exploitation: the <b>STELLER'S SEA COW</b> and the <b>PASSENGER PIGEON</b>.<br>• Presently, many <b>MARINE FISH populations</b> around the world are <b>over-harvested</b>, endangering the continued existence of some <b>commercially important species</b>." },
    { q: "Explain alien species invasions with all three of NCERT's examples.", hint: "Lake Victoria, three weeds, one catfish.", a: "When alien species are introduced <b>unintentionally OR deliberately</b>, some turn <b>INVASIVE</b> and cause the <b>decline or extinction of indigenous species</b>.<br><br><b>1. Nile perch → LAKE VICTORIA, east Africa.</b> It led eventually to the <b>extinction of an ecologically unique assemblage of MORE THAN 200 SPECIES of CICHLID FISH</b> in the lake.<br><br><b>2. Invasive weeds in India:</b> <b>carrot grass (<i>Parthenium</i>)</b>, <b>Lantana</b>, and <b>water hyacinth (<i>Eichhornia</i>)</b>.<br><br><b>3. African catfish (<i>Clarias gariepinus</i>)</b> — <b>illegally introduced</b> for <b>aquaculture</b>, now posing a threat to the <b>indigenous catfishes</b> in our rivers." },
    { q: "Define co-extinction and give NCERT's two examples.", hint: "Obligatory association.", a: "<b>Co-extinction:</b> when a species becomes extinct, the plant and animal species <b>associated with it in an OBLIGATORY way</b> also become extinct.<br><br><b>Example 1:</b> when a <b>HOST FISH species becomes extinct</b>, its <b>unique assemblage of PARASITES</b> meets the same fate.<br><br><b>Example 2:</b> in a <b>CO-EVOLVED PLANT–POLLINATOR MUTUALISM</b>, the <b>extinction of one invariably leads to the extinction of the other</b>. (Think of the fig–wasp one-to-one relationship from Chapter 11.)" },
    { q: "Give the NARROWLY UTILITARIAN reasons for conserving biodiversity, with all numbers.", hint: "Goods, drugs, bioprospecting.", a: "Humans derive <b>countless direct economic benefits</b> from nature:<br>• <b>Food</b> — cereals, pulses, fruits<br>• <b>Firewood, fibre, construction material</b><br>• <b>Industrial products</b> — tannins, lubricants, dyes, resins, perfumes<br>• <b>Products of medicinal importance</b><br><br>• More than <b>25 PER CENT of the drugs currently sold worldwide are derived from PLANTS</b>.<br>• <b>25,000 species of plants</b> contribute to the <b>traditional medicines</b> used by native peoples around the world.<br><br><b>BIOPROSPECTING</b> = <b>exploring molecular, genetic and species-level diversity for products of economic importance</b>. Nations endowed with rich biodiversity can <b>reap enormous benefits</b>." },
    { q: "Give the BROADLY UTILITARIAN and ETHICAL reasons for conserving biodiversity.", hint: "Oxygen, pollination, aesthetics — then intrinsic value.", a: "<b>BROADLY UTILITARIAN — ecosystem services:</b><br>• The fast-dwindling <b>AMAZON forest</b> is estimated to produce, through photosynthesis, <b>20 PER CENT of the total OXYGEN in the earth's atmosphere</b>.<br>• <b>POLLINATION</b> — without which plants cannot give us fruits or seeds — provided by <b>bees, bumblebees, birds and bats</b>.<br>• <b>Intangible aesthetic pleasures</b>: walking through thick woods, watching spring flowers in bloom, waking up to a <b>bulbul's song</b>. <b>'Can we put a price tag on them?'</b><br><br><b>ETHICAL:</b><br><b>Every species has an INTRINSIC VALUE</b>, even if it may not be of current or any economic value to us. We have a <b>MORAL DUTY to care for their well-being</b> and to <b>pass on our biological legacy in good order to future generations</b>." },
    { q: "Distinguish in situ from ex situ conservation, with examples of each.", hint: "On site vs off site.", a: "<table class='cmp'><thead><tr><th>Feature</th><th>IN SITU (on site)</th><th>EX SITU (off site)</th></tr></thead><tbody><tr><td>Where</td><td><b>In the natural habitat</b></td><td><b>Outside the natural habitat</b></td></tr><tr><td>What is protected</td><td>The <b>WHOLE ECOSYSTEM</b> — biodiversity at ALL levels</td><td><b>Individual threatened species</b>, given special care</td></tr><tr><td>Principle</td><td>'Save the entire <b>FOREST</b> to save the <b>TIGER</b>'</td><td>Take it out and protect it</td></tr><tr><td>Examples</td><td><b>Biodiversity hotspots, biosphere reserves, national parks, wildlife sanctuaries, sacred groves</b></td><td><b>Zoological parks, botanical gardens, wildlife safari parks, cryopreservation, in vitro fertilisation, tissue culture, seed banks</b></td></tr></tbody></table>" },
    { q: "Define a biodiversity hotspot, give the two criteria, and the full number bank.", hint: "25 + 9. <2%. 30%.", a: "A <b>biodiversity hotspot</b> is a region identified for <b>maximum protection</b> because it has:<br><b>1.</b> Very high levels of <b>SPECIES RICHNESS</b>, and<br><b>2.</b> A high degree of <b>ENDEMISM</b> — species <b>confined to that region and not found anywhere else</b>.<br><br>• Initially <b>25</b> hotspots were identified; <b>9 more</b> were subsequently added → <b>TOTAL 34</b> in the world.<br>• They are also regions of <b>ACCELERATED HABITAT LOSS</b>.<br>• All hotspots together cover <b>LESS THAN 2 PER CENT of the earth's land area</b>.<br>• <b>Strict protection of these hotspots could reduce the ongoing mass extinctions by almost 30 PER CENT.</b>" },
    { q: "Name the three biodiversity hotspots covering India, and list India's legally protected areas.", hint: "'We Indians Have'. Then 14/90/448.", a: "<b>The three Indian hotspots:</b><br>(i) <b>WESTERN GHATS and SRI LANKA</b><br>(ii) <b>INDO-BURMA</b><br>(iii) <b>HIMALAYA</b><br><br><b>India's legally protected areas:</b><br>• <b>14 BIOSPHERE RESERVES</b><br>• <b>90 NATIONAL PARKS</b><br>• <b>448 WILDLIFE SANCTUARIES</b><br><br>These are ecologically unique and biodiversity-rich regions protected <b>in situ</b>." },
    { q: "What are sacred groves? What is their role in conservation? (NCERT Exercise Q7)", hint: "Four regions. And one special line about Meghalaya.", a: "<b>Sacred groves</b> are <b>tracts of forest set aside</b> under India's religious and cultural traditions, where <b>all the trees and wildlife within were VENERATED and given TOTAL PROTECTION</b>.<br><br><b>Where they are found:</b><br>• <b>Khasi and Jaintia Hills</b> — <b>Meghalaya</b><br>• <b>Aravalli Hills</b> — <b>Rajasthan</b><br>• <b>Western Ghat regions</b> — <b>Karnataka and Maharashtra</b><br>• <b>Sarguja, Chanda and Bastar areas</b> — <b>Madhya Pradesh</b><br><br><b>Their role:</b> they are a form of <b>community-driven IN SITU conservation</b> — the <b>whole habitat</b> is protected in place, not just one species. <b>In Meghalaya, the sacred groves are the LAST REFUGES for a large number of RARE and THREATENED PLANTS.</b>" },
    { q: "Describe ex situ conservation, including the four modern techniques.", hint: "Zoos and gardens — then C-I-T-S.", a: "In <b>ex situ conservation</b>, <b>threatened animals and plants are taken OUT of their natural habitat</b> and placed in a <b>special setting</b> where they can be <b>protected and given special care</b>.<br><br><b>Classic sites:</b> <b>zoological parks, botanical gardens and wildlife safari parks</b>. <b>Many animals that have become extinct in the wild continue to be maintained in zoological parks.</b><br><br><b>Modern advances (mnemonic C-I-T-S):</b><br>• <b>CRYOPRESERVATION</b> — <b>gametes</b> of threatened species preserved in <b>viable and fertile condition for long periods</b>.<br>• <b>IN VITRO fertilisation</b> — <b>eggs can be fertilised in vitro</b>.<br>• <b>TISSUE CULTURE</b> — <b>plants can be propagated</b>.<br>• <b>SEED BANKS</b> — <b>seeds of different genetic strains</b> of commercially important plants kept for long periods." },
    { q: "Describe the two international summits on biodiversity, with dates, places and pledges.", hint: "Rio 92, Joburg 02.", a: "<b>Biodiversity knows no political boundaries</b> — its conservation is therefore a <b>collective responsibility of all nations</b>.<br><br><b>1992 — The EARTH SUMMIT, RIO DE JANEIRO.</b> It called upon all nations to take appropriate measures for the <b>conservation of biodiversity</b> and the <b>sustainable utilisation of its benefits</b>.<br><br><b>2002 — The WORLD SUMMIT ON SUSTAINABLE DEVELOPMENT, JOHANNESBURG, SOUTH AFRICA.</b> <b>190 COUNTRIES</b> pledged their commitment to achieve, by <b>2010</b>, a <b>significant reduction in the current rate of biodiversity loss</b> at <b>global, regional and local levels</b>." },
    { q: "Among the ecosystem services are control of floods and soil erosion. How is this achieved by the biotic components of the ecosystem? (NCERT Exercise Q8)", hint: "Roots, canopy, litter, run-off.", a: "<b>1. Roots BIND soil particles</b> together, holding the soil against wind and water and preventing <b>erosion</b>.<br><b>2. The canopy INTERCEPTS rainfall</b>, breaking the force with which raindrops strike the soil surface, so soil is not dislodged.<br><b>3. Leaf litter and humus INCREASE INFILTRATION</b> and the soil's water-holding capacity, so water soaks in rather than running off.<br><b>4. Vegetation SLOWS surface run-off</b>, allowing water to percolate into the ground instead of rushing downhill as flood water.<br><br><b>Consequence:</b> deforestation directly increases <b>flooding, siltation and soil erosion</b> — which is precisely why intact vegetation is an <b>ecosystem service</b>." },
    { q: "The species diversity of plants (22%) is much less than that of animals (72%). What could explain how animals achieved greater diversification? (NCERT Exercise Q9)", hint: "Three structural/behavioural reasons.", a: "<b>1. Greater MOTILITY.</b> Animals can <b>MOVE</b> — allowing them to <b>escape adverse conditions</b> and <b>colonise new habitats</b>, which drives geographic isolation and speciation. Plants are rooted in place.<br><br><b>2. Complex and sensitive NERVOUS SYSTEMS.</b> These allow animals to <b>perceive and respond to environmental stimuli</b>, adapting behaviour to varied and changing conditions.<br><br><b>3. The rigid EXOSKELETON in ARTHROPODS.</b> It provided <b>protection and support</b>, enabling the vast diversification of the single largest animal group.<br><br>Together these gave animals far more routes to adaptive radiation than plants had." },
    { q: "Can you think of a situation where we deliberately want to make a species extinct? How would you justify it? (NCERT Exercise Q10)", hint: "One virus.", a: "<b>YES</b> — in the case of <b>harmful, disease-causing microorganisms</b>.<br><br><b>The example:</b> the <b>SMALLPOX VIRUS</b> was <b>deliberately eradicated globally</b> through worldwide vaccination programmes.<br><br><b>The justification:</b><br>• It is a matter of <b>HUMAN WELFARE</b> — smallpox caused <b>enormous suffering and death</b> over centuries.<br>• The virus is an <b>obligate human pathogen</b>: it provides <b>no ecosystem service</b> and occupies <b>no beneficial ecological role</b>, so its removal does not weaken any food web or nutrient cycle.<br>• Similar arguments apply to the polio virus and other pathogens targeted for eradication.<br><br><b>But note the limit:</b> this is a <b>narrow exception</b>. It cannot be extended to organisms that merely inconvenience us — biodiversity conservation remains the rule." },
    { q: "Why is biodiversity conservation described as a collective responsibility of all nations?", hint: "One phrase.", a: "Because <b>BIODIVERSITY KNOWS NO POLITICAL BOUNDARIES</b>. Species, migratory routes, river systems and airsheds cross borders freely, so no single nation can protect its biological wealth alone.<br><br>This is precisely why the <b>Earth Summit (Rio, 1992)</b> and the <b>World Summit on Sustainable Development (Johannesburg, 2002, 190 countries)</b> were convened." },
    { q: "Is speciation currently adding new species to the Earth? What does NCERT say?", hint: "It's doubtful.", a: "It is <b>DOUBTFUL whether any new species are being added</b> (through speciation) into the earth's <b>'treasury of species'</b> — but there is <b>NO DOUBT about their continuing LOSSES</b>.<br><br>The biological wealth of our planet has been <b>declining rapidly</b>, and <b>the accusing finger is clearly pointing to HUMAN ACTIVITIES</b>." },
    { q: "Why are species inventories more complete in temperate countries than in tropical ones — and why does that matter?", hint: "It biases the count.", a: "For many taxonomic groups, <b>species inventories are more complete in TEMPERATE than in TROPICAL countries</b> — because temperate regions have been studied far longer and more intensively.<br><br><b>Why it matters:</b> an <b>overwhelmingly large proportion of the species waiting to be discovered are IN THE TROPICS</b>. So a straight count would badly underestimate global diversity. That is exactly why ecologists must use the <b>statistical extrapolation method</b> — comparing the temperate-vs-tropical richness of a well-studied insect group and applying the ratio to other taxa." },
    { q: "Contrast species richness in a small area within one region versus across whole continents, using Z.", hint: "Same pool vs different pools.", a: "<b>Within a region (small areas):</b> Z = <b>0.1 to 0.2</b>. Richness climbs <b>slowly</b> with area, because as you expand your sampling you keep encountering the <b>same regional species pool</b> over and over. Remarkably, this value holds <b>regardless of taxon or region</b> — plants in Britain, birds in California, molluscs in New York state.<br><br><b>Across continents (very large areas):</b> Z = <b>0.6 to 1.2</b>. The slope is <b>much steeper</b>, because each continent has its own <b>independently evolved species pool</b> — a new continent means genuinely new species, not more of the same.<br><br><b>Specific case:</b> frugivorous birds and mammals in tropical forests of different continents give <b>Z = 1.15</b>." },
    { q: "What makes the Amazon rain forest simultaneously the richest AND the most threatened habitat?", hint: "Both sides of the ledger.", a: "<b>Richest:</b> the <b>Amazonian rain forest</b> has the <b>greatest biodiversity on earth</b> — &gt;40,000 plants, 3,000 fishes, 1,300 birds, 427 mammals, 427 amphibians, 378 reptiles, &gt;1,25,000 invertebrates, and at least <b>2 million undiscovered insect species</b>. It also produces about <b>20% of the earth's atmospheric oxygen</b> — hence the <b>'lungs of the planet'</b>.<br><br><b>Most threatened:</b> it is being <b>cut and cleared for cultivating SOYA BEANS</b> and for <b>conversion to grasslands for raising BEEF CATTLE</b>. Tropical rain forests worldwide have shrunk from <b>&gt;14% to ≤6%</b> of the earth's land surface.<br><br>This is exactly the <b>hotspot paradox</b>: the richest regions are also the regions of <b>accelerated habitat loss</b>." },
    { q: "State everything NCERT says about ENDEMISM.", hint: "It's one of the two hotspot criteria.", a: "<b>Endemism</b> = species being <b>confined to that region</b> and <b>not found anywhere else</b>.<br><br>It is <b>one of the TWO defining criteria of a biodiversity hotspot</b> (the other being very high <b>species richness</b>).<br><br><b>Why it matters:</b> an endemic species has <b>nowhere else to survive</b>. If its region is destroyed, it goes extinct globally — not just locally. That is why regions combining <b>high endemism + high species richness + accelerated habitat loss</b> are prioritised for <b>maximum protection</b>." },
    { q: "Which single fact best captures how dominant insects are on Earth?", hint: "A ratio out of ten.", a: "<b>Out of every 10 animals on this planet, 7 are INSECTS.</b><br><br>Insects are the <b>most species-rich taxonomic group</b>, making up <b>70 per cent of all animals</b> — and animals themselves make up more than <b>70 per cent</b> of all described species.<br><br><b>Bonus fact of the same flavour:</b> the number of <b>FUNGI</b> species exceeds the <b>COMBINED total</b> of all fishes, amphibians, reptiles and mammals." },
    { q: "Why does NCERT say ecologists have 'not been able to give a definitive answer' about whether species number matters?", hint: "Be honest about the science.", a: "Because the question — <b>does the number of species in a community really matter to the functioning of the ecosystem?</b> — is genuinely hard to answer experimentally at ecosystem scale.<br><br>What ecologists <b>do believe</b>, and what the evidence supports, is that <b>communities with more species tend to be more stable</b>.<br><br><b>David Tilman's outdoor-plot experiments</b> provide the <b>'tentative answers'</b>: more species → <b>less year-to-year variation in total biomass</b>, and <b>higher productivity</b>. NCERT deliberately uses the word 'tentative' — the science is suggestive, not settled." },
    { q: "In the rivet popper analogy, what is the practical lesson about which species to prioritise?", hint: "Wings vs seats.", a: "<b>Not all species are equal in structural importance.</b><br><br>Ehrlich's point: <b>loss of rivets on the WINGS is obviously a more serious threat to flight safety than loss of a few rivets on the SEATS or WINDOWS inside the plane.</b><br><br><b>Translation:</b> the extinction of a <b>KEY species</b> — one on which many others depend, such as a keystone predator or a sole pollinator — can destabilise an entire ecosystem, while the loss of a peripheral species may be absorbed.<br><br><b>But the deeper warning stands:</b> we generally <b>do not know which rivet is a wing rivet</b> until it is gone." },
    { q: "Give NCERT's three intangible/aesthetic examples of what biodiversity provides.", hint: "Woods, flowers, a bird.", a: "The <b>intangible benefits</b> derived from nature — the <b>aesthetic pleasures</b> of:<br>• <b>walking through thick woods</b><br>• <b>watching spring flowers in full bloom</b><br>• <b>waking up to a BULBUL's song in the morning</b><br><br>NCERT then asks the rhetorical question: <b>'Can we put a price tag on them?'</b><br><br>These fall under the <b>BROADLY UTILITARIAN</b> reasons for conservation." },
    { q: "How do the tropical rain forest habitat-loss figures connect to the Sixth Extinction?", hint: "Cause and consequence.", a: "<b>The cause:</b> <b>habitat loss and fragmentation</b> is the <b>MOST IMPORTANT</b> driver of extinction. Tropical rain forests — the most species-rich habitats on Earth — have shrunk from more than <b>14 PER CENT</b> of the earth's land surface to <b>no more than 6 PER CENT</b>.<br><br><b>The consequence:</b> current extinction rates are <b>100 to 1,000 times faster</b> than pre-human times, and if trends continue, <b>nearly half of all species on Earth could be wiped out within the next 100 years</b>.<br><br><b>The link:</b> because <b>species richness rises with area</b> (log S = log C + Z log A), destroying a large fraction of the richest habitat removes a large fraction of the world's species — the species–area relationship makes the extinction arithmetic predictable, not speculative." },
    { q: "What exactly did Humboldt's 'up to a limit' observation mean?", hint: "Rectangular hyperbola.", a: "Humboldt observed that within a region, <b>species richness increased with increasing explored area — but only UP TO A LIMIT</b>.<br><br><b>What that means:</b> at first, every new patch you survey adds many new species. But as you keep expanding, you begin re-encountering species you have already recorded, so the <b>rate of accumulation slows and the curve flattens</b>.<br><br>Mathematically this produces a <b>RECTANGULAR HYPERBOLA</b> — a curve that rises steeply then bends toward a plateau. Taking logarithms of both axes <b>straightens</b> it into <b>log S = log C + Z log A</b>." },
    { q: "State all four Z-value facts in one block.", hint: "Range, consistency, continents, frugivores.", a: "<b>1.</b> <b>Z = 0.1 to 0.2</b> for species–area relationships within a region.<br><b>2.</b> This range holds <b>regardless of the taxonomic group or the region</b> — the slopes of the regression lines for <b>plants in Britain, birds in California and molluscs in New York state</b> are <b>amazingly similar</b>.<br><b>3.</b> For <b>very large areas like entire continents</b>, the slope is <b>much steeper: Z = 0.6 to 1.2</b>.<br><b>4.</b> For <b>frugivorous (fruit-eating) birds and mammals in the tropical forests of different continents</b>, the slope is <b>1.15</b>." },
    { q: "List everything NCERT names as an INVASIVE species, and where.", hint: "One fish, three weeds, one catfish.", a: "<b>1. Nile perch</b> — introduced into <b>Lake Victoria, east Africa</b> → drove <b>&gt;200 species of cichlid fish</b> to extinction.<br><b>2. Carrot grass (<i>Parthenium</i>)</b> — invasive weed in India.<br><b>3. Lantana</b> — invasive weed in India.<br><b>4. Water hyacinth (<i>Eichhornia</i>)</b> — invasive weed in India.<br><b>5. African catfish (<i>Clarias gariepinus</i>)</b> — <b>illegally introduced</b> for <b>aquaculture</b>, threatening India's <b>indigenous catfishes</b>.<br><br><b>Cross-link:</b> <i>Parthenium hysterophorus</i> (carrot grass) also appears in Chapter 11 as the density-measurement example against the banyan tree." },
    { q: "Summarise the whole chapter in one paragraph, using its five biggest ideas.", hint: "Wilson, gradients, area, quartet, conservation.", a: "<b>Biodiversity</b> (a term popularised by <b>Edward Wilson</b>) exists at <b>three levels — genetic, species and ecological</b>. It follows two great patterns: it <b>rises toward the equator</b> (the <b>latitudinal gradient</b>, explained by <b>time, constancy and energy</b>), and it <b>rises with area</b> according to <b>log S = log C + Z log A</b> (<b>Humboldt</b>). It matters because diverse communities are <b>more stable and more productive</b> (<b>Tilman</b>), and because we cannot know which species is a load-bearing 'wing rivet' until it is gone (<b>Ehrlich</b>). It is being destroyed by <b>the Evil Quartet</b> — habitat loss (the worst), over-exploitation, alien invasions and co-extinctions — at <b>100–1,000× the natural rate</b>. We conserve it for <b>narrowly utilitarian, broadly utilitarian and ethical</b> reasons, through <b>in situ</b> protection (34 hotspots, biosphere reserves, national parks, sanctuaries, sacred groves) and <b>ex situ</b> methods (zoos, botanical gardens, cryopreservation, IVF, tissue culture, seed banks)." },
    { q: "A conservationist has funding to protect ONE region. Using NCERT's logic, how should she choose — and what does the arithmetic of hotspots tell her?", hint: "Two criteria, and two percentages.", a: "She should choose a <b>BIODIVERSITY HOTSPOT</b> — a region with <b>(1) very high species richness</b> AND <b>(2) a high degree of ENDEMISM</b>.<br><br><b>The arithmetic:</b> all <b>34</b> hotspots together cover <b>LESS THAN 2 PER CENT</b> of the earth's land area, yet <b>strict protection of them could reduce the ongoing mass extinctions by almost 30 PER CENT</b>.<br><br><b>Why endemism is the decisive criterion:</b> an endemic species is found <b>nowhere else</b>. If its region is lost, it goes extinct <b>globally</b>, not just locally. Species richness alone would not justify the priority — it is richness <b>plus</b> irreplaceability <b>plus</b> accelerated habitat loss." },
    { q: "Connect the species-area relationship to the extinction crisis. Why does habitat loss produce PREDICTABLE species loss?", hint: "The equation runs in both directions.", a: "The relationship <b>log S = log C + Z log A</b> says species richness is a <b>function of AREA</b>. Ecologists normally read it forwards: enlarge the area, gain species.<br><br><b>But it runs backwards too.</b> If you <b>destroy</b> area, you <b>lose</b> species — and by a calculable amount, not a guess.<br><br><b>Apply it:</b> tropical rain forests have shrunk from more than <b>14%</b> of the earth's land surface to <b>no more than 6%</b>. Since these are the most species-rich habitats on Earth, removing that fraction of the richest area removes a large, <b>predictable</b> fraction of the world's species.<br><br>This is why the <b>100-1,000&times; extinction rate</b> and the <b>'half of all species in 100 years'</b> warning are treated as arithmetic, not alarmism." },
    { q: "Which NCERT organisms appear in MORE THAN ONE chapter of the ecology unit, and in what roles?", hint: "Cross-links pay in NEET.", a: "<b><i>Parthenium</i> (carrot grass)</b><br>&bull; <b>Ch 11</b> &mdash; the <b>200 carrot grass plants vs 1 huge banyan</b> example, showing why <b>per cent cover / biomass</b> beats total number as a density measure.<br>&bull; <b>Ch 13</b> &mdash; an <b>invasive weed species</b> threatening India's natives.<br><br><b>Co-evolved plant&ndash;pollinator mutualisms (fig&ndash;wasp, <i>Ophrys</i>&ndash;bee)</b><br>&bull; <b>Ch 11</b> &mdash; the showcase examples of <b>mutualism and co-evolution</b>.<br>&bull; <b>Ch 13</b> &mdash; the mechanism behind <b>CO-EXTINCTION</b>: extinction of one <b>invariably</b> leads to extinction of the other.<br><br><b>The Amazon</b><br>&bull; <b>Ch 13</b> &mdash; greatest biodiversity on Earth; <b>20% of atmospheric oxygen</b> (broadly utilitarian); and the flagship victim of <b>habitat loss</b> (soya beans, beef cattle)." },
    { q: "State every NCERT figure that involves the number 'per cent' in this chapter, and what each refers to.", hint: "Roughly a dozen.", a: "&bull; <b>&gt;70%</b> of described species are <b>ANIMALS</b><br>&bull; <b>&le;22%</b> of described species are <b>PLANTS</b><br>&bull; <b>70%</b> of all animals are <b>INSECTS</b><br>&bull; <b>2.4%</b> &mdash; India's share of the world's <b>LAND AREA</b><br>&bull; <b>8.1%</b> &mdash; India's share of <b>global species diversity</b><br>&bull; <b>32% / 31% / 23% / 12%</b> &mdash; amphibians / gymnosperms / mammals / birds facing extinction<br>&bull; <b>&gt;14% &rarr; &le;6%</b> &mdash; tropical rain forest cover, then and now<br>&bull; <b>&gt;25%</b> of drugs sold worldwide are derived from <b>PLANTS</b><br>&bull; <b>20%</b> of atmospheric <b>OXYGEN</b> is produced by the Amazon<br>&bull; <b>&lt;2%</b> of land area is covered by all <b>HOTSPOTS</b><br>&bull; <b>~30%</b> &mdash; reduction in mass extinctions achievable by strictly protecting hotspots" }
  ],

  /* ---------- 6. QUIZ BATTLE — MCQs (118) ---------- */
  mcqs: [
    { q: "The term 'biodiversity' was popularised by:", o: ["David Tilman", "Alexander von Humboldt", "Paul Ehrlich", "Edward Wilson"], c: 3, e: "<b>Edward Wilson</b>, a <b>sociobiologist</b>, popularised the term to describe the combined diversity at all levels of biological organisation." },
    { q: "Edward Wilson was a:", o: ["Palaeontologist", "Taxonomist", "Geneticist", "Sociobiologist"], c: 3, e: "NCERT specifies <b>sociobiologist</b> — and examiners test the profession, not just the name." },
    { q: "The three important components of biodiversity are:", o: ["Genetic, taxonomic and regional diversity", "Species, population and community diversity", "Genetic, molecular and biome diversity", "Genetic, species and ecological diversity"], c: 3, e: "<b>Genetic, Species and Ecological</b> diversity." },
    { q: "Rauwolfia vomitoria growing in different Himalayan ranges shows variation in reserpine potency. This illustrates:", o: ["Genetic diversity", "Ecosystem diversity", "Species diversity", "Ecological diversity"], c: 0, e: "<b>Genetic diversity</b> — variation WITHIN a single species over its distributional range." },
    { q: "The active chemical produced by Rauwolfia vomitoria is:", o: ["Quinine", "Nicotine", "Strychnine", "Reserpine"], c: 3, e: "<b>Reserpine</b> — its potency and concentration vary across Himalayan ranges." },
    { q: "India has how many genetically different strains of rice?", o: ["More than 50,000", "More than 5,00,000", "More than 1,000", "More than 5,000"], c: 0, e: "More than <b>50,000</b> strains of rice — and <b>1,000</b> varieties of mango." },
    { q: "The Western Ghats having greater amphibian species diversity than the Eastern Ghats is an example of:", o: ["Ecological diversity", "Endemism", "Genetic diversity", "Species diversity"], c: 3, e: "Different <b>species</b> of amphibians → <b>SPECIES diversity</b>, not genetic." },
    { q: "India having deserts, rain forests, mangroves, coral reefs, wetlands, estuaries and alpine meadows — unlike Norway — illustrates:", o: ["Ecological diversity", "Bioprospecting", "Genetic diversity", "Species diversity"], c: 0, e: "<b>Ecological (ecosystem) diversity.</b>" },
    { q: "According to IUCN (2004), the number of plant and animal species described so far is:", o: ["About 7 million", "20 to 50 million", "Slightly more than 0.5 million", "Slightly more than 1.5 million"], c: 3, e: "Slightly more than <b>1.5 million</b>. (7 million is Robert May's ESTIMATE of the true total.)" },
    { q: "Robert May's conservative estimate of global species diversity is:", o: ["7 million", "50 million", "1.5 million", "5 million"], c: 0, e: "About <b>7 million</b>. Extreme estimates range from 20 to 50 million, but May's is the scientifically sound one." },
    { q: "Of all described species, animals constitute:", o: ["No more than 22 per cent", "Exactly 50 per cent", "About 30 per cent", "More than 70 per cent"], c: 3, e: "<b>Animals &gt; 70%</b>; <b>plants ≤ 22%</b>." },
    { q: "Plants (including algae, fungi, bryophytes, gymnosperms and angiosperms) comprise what share of described species?", o: ["No more than 22 per cent", "About 45 per cent", "About 8 per cent", "More than 70 per cent"], c: 0, e: "<b>No more than 22 per cent.</b>" },
    { q: "The most species-rich taxonomic group among animals is:", o: ["Mammals", "Fishes", "Birds", "Insects"], c: 3, e: "<b>Insects</b> — they make up <b>70% of all animals</b>. Out of every 10 animals, 7 are insects." },
    { q: "Out of every 10 animals on this planet, how many are insects?", o: ["2", "5", "7", "9"], c: 2, e: "<b>7</b> — insects are 70% of all animals." },
    { q: "The number of fungi species in the world is:", o: ["More than the combined total of fishes, amphibians, reptiles and mammals", "About equal to the number of bird species", "Less than the number of plant species", "Less than the number of insect species alone"], c: 0, e: "Fungi <b>outnumber the COMBINED total</b> of fishes + amphibians + reptiles + mammals." },
    { q: "Prokaryotic species are not adequately represented in biodiversity counts because:", o: ["They have no genetic diversity", "They are not considered living organisms", "They are too small to see", "Conventional taxonomic methods are unsuitable and many are not culturable in the laboratory"], c: 3, e: "Both reasons. Molecular/biochemical criteria would elevate their diversity to <b>'biblical proportions'</b>." },
    { q: "India occupies what percentage of the world's land area?", o: ["2.4 per cent", "8.1 per cent", "12 per cent", "22 per cent"], c: 0, e: "Only <b>2.4%</b> of the land — but <b>8.1%</b> of global species diversity." },
    { q: "India's share of the global species diversity is:", o: ["2.4 per cent", "8.1 per cent", "12 per cent", "22 per cent"], c: 1, e: "An impressive <b>8.1 per cent</b>, making India one of the <b>12 mega-diversity countries</b>." },
    { q: "India is one of how many mega-diversity countries in the world?", o: ["8", "12", "25", "34"], c: 1, e: "<b>12</b>. (34 is the number of biodiversity HOTSPOTS — do not confuse them.)" },
    { q: "How many plant species have been recorded from India?", o: ["Nearly 45,000", "Nearly 90,000", "Nearly 1,00,000", "Nearly 3,00,000"], c: 0, e: "Nearly <b>45,000 plants</b> and <b>twice as many animals</b> (~90,000)." },
    { q: "Ecologists estimate the total number of species in the world by:", o: ["Counting every species in a sample plot", "Statistically comparing temperate and tropical species richness of a well-studied insect group and extrapolating", "Using satellite imagery of forests", "Sequencing all known genomes"], c: 1, e: "A <b>statistical comparison</b> of temperate vs tropical richness of an <b>exhaustively studied insect group</b>, <b>extrapolated</b> to other taxa." },
    { q: "The latitudinal range of the tropics is:", o: ["41° N to 41° S", "71° N to 71° S", "0° to 15° N and S", "23.5° N to 23.5° S"], c: 3, e: "<b>23.5° N to 23.5° S.</b>" },
    { q: "Colombia, located near the equator, has nearly how many bird species?", o: ["105", "56", "1,200", "1,400"], c: 3, e: "Nearly <b>1,400</b>. India has &gt;1,200; New York (41° N) has 105; Greenland (71° N) has 56." },
    { q: "Greenland, at 71° N, has how many bird species?", o: ["56", "105", "378", "1,300"], c: 0, e: "Only <b>56</b> — the poles are species-poor." },
    { q: "New York is at which latitude, and how many bird species does it have?", o: ["41° N, 105 species", "23.5° N, 427 species", "41° S, 1,400 species", "71° N, 56 species"], c: 0, e: "<b>41° N, 105 species.</b>" },
    { q: "A tropical forest in Ecuador has how many times as many vascular plant species as an equal-area temperate forest in the Midwest USA?", o: ["5 times", "Up to 10 times", "100 times", "2 times"], c: 1, e: "Up to <b>10 times</b> as many species of <b>vascular plants</b>." },
    { q: "Which region has the greatest biodiversity on Earth?", o: ["The Western Ghats", "The Congo Basin", "The Amazonian rain forest", "The Great Barrier Reef"], c: 2, e: "The <b>Amazonian rain forest</b> in South America." },
    { q: "How many plant species does the Amazon rain forest harbour?", o: ["More than 1,25,000", "More than 2 million", "More than 3,000", "More than 40,000"], c: 3, e: "More than <b>40,000 plants</b>. (3,000 = fishes; 1,25,000 = invertebrates; 2 million = undiscovered insects.)" },
    { q: "The Amazon rain forest has how many mammal species and how many amphibian species?", o: ["427 and 427", "378 and 427", "1,300 and 3,000", "427 and 378"], c: 0, e: "<b>Mammals 427, Amphibians 427</b> — identical. Reptiles are 378. Use the coincidence as your anchor." },
    { q: "How many insect species are estimated to remain undiscovered in the Amazon rain forest?", o: ["At least 1,25,000", "At least 2 million", "At least 7 million", "At least 40,000"], c: 1, e: "At least <b>2 MILLION</b> insect species waiting to be discovered and named." },
    { q: "The TIME hypothesis for greater tropical species richness argues that:", o: ["Tropics have more solar energy", "Tropical environments are less seasonal", "Tropical latitudes remained relatively undisturbed by glaciations for millions of years", "Tropics have more predators"], c: 2, e: "Speciation is a <b>function of TIME</b>; unlike temperate regions hit by <b>frequent glaciations</b>, the tropics had a <b>long evolutionary time</b> to diversify." },
    { q: "The CONSTANCY hypothesis says tropical environments promote greater diversity because they are:", o: ["Warmer and wetter than temperate zones", "Larger in total area", "Less disturbed by glaciations", "Less seasonal, more constant and predictable — promoting niche specialisation"], c: 3, e: "Constant environments <b>promote NICHE SPECIALISATION</b>, which leads to greater species diversity." },
    { q: "The ENERGY hypothesis states that more solar energy in the tropics leads to:", o: ["Higher productivity, which might contribute INDIRECTLY to greater diversity", "Faster glaciation cycles", "Lower niche specialisation", "Directly higher species number"], c: 0, e: "Note NCERT's hedge: the contribution to diversity is <b>INDIRECT</b>, via <b>higher productivity</b>." },
    { q: "The species–area relationship was observed by:", o: ["Robert May", "Alexander von Humboldt", "David Tilman", "Paul Ehrlich"], c: 1, e: "<b>Alexander von Humboldt</b>, during his explorations of the <b>South American jungles</b>." },
    { q: "Humboldt observed that within a region, species richness:", o: ["Increased without limit", "Decreased with increasing area", "Increased with increasing explored area, but only up to a limit", "Stayed constant regardless of area"], c: 2, e: "The key phrase is <b>'but only up to a limit'</b> — which is why the curve is a rectangular hyperbola, not a straight line." },
    { q: "On a normal (non-logarithmic) scale, the species–area curve is:", o: ["A sigmoid curve", "A J-shaped curve", "A straight line", "A rectangular hyperbola"], c: 3, e: "A <b>RECTANGULAR HYPERBOLA</b>. On a log scale it becomes a straight line." },
    { q: "The species–area relationship on a logarithmic scale is described by:", o: ["log S = log C + Z log A", "log S = log Z + C log A", "S = C + Z + A", "log A = log C + Z log S"], c: 0, e: "<b>log S = log C + Z log A.</b> S = species richness, A = area, Z = slope, C = Y-intercept." },
    { q: "In the equation log S = log C + Z log A, 'Z' represents:", o: ["The Y-intercept", "The slope of the line (regression coefficient)", "The area", "Species richness"], c: 1, e: "<b>Z = slope = regression coefficient.</b> C is the Y-intercept." },
    { q: "In the equation log S = log C + Z log A, 'C' represents:", o: ["The carrying capacity", "The slope", "The Y-intercept", "The species count"], c: 2, e: "<b>C = Y-intercept.</b> (This is NOT the carrying capacity from Chapter 11 — different chapter, different C.)" },
    { q: "The value of Z for species–area relationships within a region typically lies between:", o: ["0.6 and 1.2", "1.0 and 1.15", "2.0 and 3.0", "0.1 and 0.2"], c: 3, e: "<b>0.1 to 0.2</b> — and it is amazingly similar regardless of taxon or region." },
    { q: "For very large areas like entire continents, the Z value lies in the range:", o: ["0.6 to 1.2", "0.01 to 0.05", "2 to 5", "0.1 to 0.2"], c: 0, e: "<b>0.6 to 1.2</b> — the slope of the line is <b>much steeper</b>." },
    { q: "For frugivorous birds and mammals in tropical forests of different continents, the slope Z is:", o: ["0.1", "0.2", "1.15", "2.15"], c: 2, e: "<b>Z = 1.15</b> — the single most-tested specific Z value in the chapter." },
    { q: "'Frugivorous' means:", o: ["Insect-eating", "Fruit-eating", "Flesh-eating", "Nectar-feeding"], c: 1, e: "<b>Fruit-eating.</b>" },
    { q: "NCERT states that the Z value of 0.1–0.2 holds for which examples?", o: ["Insects in the Amazon only", "Fishes in Lake Victoria", "Plants in Britain, birds in California, molluscs in New York state", "Frugivorous birds and mammals across continents"], c: 2, e: "The slopes of the regression lines for these three are <b>amazingly similar</b> — which is what makes it a real ecological law." },
    { q: "Ecologists believe that communities with more species tend to be:", o: ["Equally stable", "More vulnerable to drought", "Less stable", "More stable"], c: 3, e: "<b>More stable</b> — steady productivity, resistant to disturbance, resistant to alien invasion." },
    { q: "Which is NOT one of the three criteria for a STABLE community?", o: ["Having the highest possible number of top carnivores", "Little year-to-year variation in productivity", "Resistance or resilience to occasional disturbances", "Resistance to invasions by alien species"], c: 0, e: "The three criteria are <b>steady productivity, resistance/resilience to disturbance, and resistance to alien invasion</b>." },
    { q: "David Tilman's experiments were conducted using:", o: ["Laboratory cultures", "Outdoor plots", "Computer simulations", "Aquarium tanks"], c: 1, e: "Long-term ecosystem experiments using <b>OUTDOOR PLOTS</b>." },
    { q: "Tilman found that plots with more species showed:", o: ["Lower productivity", "More year-to-year variation in total biomass", "Less year-to-year variation in total biomass", "No change in biomass"], c: 2, e: "<b>LESS year-to-year variation in total biomass</b> — AND <b>increased diversity contributed to HIGHER productivity</b>. Two separate findings." },
    { q: "Tilman also showed that increased diversity contributed to:", o: ["Greater biomass variation", "More alien invasions", "Lower productivity", "Higher productivity"], c: 3, e: "<b>Higher productivity.</b>" },
    { q: "The 'rivet popper hypothesis' was proposed by:", o: ["Paul Ehrlich", "Robert May", "Edward Wilson", "David Tilman"], c: 0, e: "<b>Paul Ehrlich</b>, the Stanford ecologist." },
    { q: "In the rivet popper hypothesis, the rivets represent:", o: ["Ecosystems", "Species", "Humans", "Trophic levels"], c: 1, e: "The <b>airplane = ecosystem</b>; the <b>rivets = species</b>; the <b>passengers popping rivets = humans causing extinctions</b>." },
    { q: "In the rivet popper analogy, why does it matter WHICH rivet is popped?", o: ["Because rivets on the seats are structural", "Because all rivets are identical", "Because rivets on the wings matter far more than rivets on the seats or windows", "Because rivets can be replaced"], c: 2, e: "Losing a <b>KEY species</b> (a wing rivet) is far more dangerous than losing a peripheral one." },
    { q: "The colonisation of tropical Pacific Islands by humans led to the extinction of more than how many native bird species?", o: ["200", "784", "2,000", "15,500"], c: 2, e: "More than <b>2,000</b> species of native birds." },
    { q: "The IUCN Red List (2004) documents the extinction of how many species in the last 500 years?", o: ["338", "359", "784", "15,500"], c: 2, e: "<b>784 species</b> = 338 vertebrates + 359 invertebrates + 87 plants." },
    { q: "Of the 784 species extinct in the last 500 years, how many were invertebrates?", o: ["87", "338", "359", "427"], c: 2, e: "<b>359 invertebrates</b> — MORE than the 338 vertebrates. This reversal is a favourite trap." },
    { q: "Of the 784 documented extinctions, how many were plants?", o: ["87", "338", "359", "784"], c: 0, e: "<b>87 plants.</b> (338 + 359 + 87 = 784.)" },
    { q: "The dodo became extinct in:", o: ["Russia", "Africa", "Australia", "Mauritius"], c: 3, e: "<b>Dodo — Mauritius.</b> Quagga — Africa. Thylacine — Australia. Steller's Sea Cow — Russia." },
    { q: "The thylacine was native to:", o: ["Australia", "Africa", "Russia", "Mauritius"], c: 0, e: "<b>Australia.</b>" },
    { q: "Steller's Sea Cow became extinct in:", o: ["Australia", "Russia", "Mauritius", "Africa"], c: 1, e: "<b>Russia</b> — and it is also NCERT's example of extinction by <b>over-exploitation</b>." },
    { q: "Which three subspecies of tiger have become extinct?", o: ["Bengal, Javan, Siberian", "Bengal, Siberian, Sumatran", "Bali, Javan, Caspian", "Indochinese, Malayan, South China"], c: 2, e: "<b>Bali, Javan and Caspian.</b>" },
    { q: "How many species have disappeared in the last twenty years alone?", o: ["12", "27", "87", "784"], c: 1, e: "<b>27 species.</b>" },
    { q: "How many species worldwide are presently facing the threat of extinction?", o: ["784", "2,000", "15,500", "40,000"], c: 2, e: "<b>15,500 species.</b>" },
    { q: "Which group does NCERT identify as MORE VULNERABLE to extinction, showing that extinctions are not random?", o: ["Mammals", "Reptiles", "Birds", "Amphibians"], c: 3, e: "<b>Amphibians</b> — 32% of all amphibian species face the threat of extinction, the highest of the four groups given." },
    { q: "What percentage of all amphibian species face the threat of extinction?", o: ["12%", "23%", "31%", "32%"], c: 3, e: "<b>32%</b> — the highest. Gymnosperms 31%, mammals 23%, birds 12%." },
    { q: "What percentage of all bird species face the threat of extinction?", o: ["12%", "23%", "31%", "32%"], c: 0, e: "<b>12%</b> — the lowest of the four groups NCERT lists." },
    { q: "What percentage of all mammal species face the threat of extinction?", o: ["12%", "23%", "31%", "32%"], c: 1, e: "<b>23%.</b> Descending order: Amphibians 32 &gt; Gymnosperms 31 &gt; Mammals 23 &gt; Birds 12." },
    { q: "What percentage of all gymnosperm species face the threat of extinction?", o: ["12%", "23%", "31%", "32%"], c: 2, e: "<b>31%</b> — just below amphibians (32%)." },
    { q: "Current species extinction rates are estimated to be how much faster than in pre-human times?", o: ["100 to 1,000 times", "2 to 5 times", "1 million times", "10 to 20 times"], c: 0, e: "<b>100 to 1,000 times faster</b> — and our activities are responsible." },
    { q: "If present trends continue, ecologists warn that within the next 100 years:", o: ["10% of species will be wiped out", "Nearly half of all species on earth might be wiped out", "All insects will go extinct", "Extinction rates will return to normal"], c: 1, e: "<b>Nearly HALF of all species</b> — this is the 'Sixth Extinction' warning." },
    { q: "Which is NOT a consequence of biodiversity loss in a region?", o: ["Lowered resistance to environmental perturbations such as drought", "Increased variability in ecosystem processes", "Increased stability of pest and disease cycles", "Decline in plant production"], c: 2, e: "Loss causes <b>INCREASED VARIABILITY</b> in pest and disease cycles — not increased stability." },
    { q: "The four causes of biodiversity loss are collectively called:", o: ["The Extinction Vortex", "The Rivet Poppers", "The Fatal Four", "The Evil Quartet"], c: 3, e: "<b>The Evil Quartet.</b> Mnemonic: 'Humans Over-Ate Creation'." },
    { q: "The MOST IMPORTANT cause driving animals and plants to extinction is:", o: ["Habitat loss and fragmentation", "Co-extinctions", "Over-exploitation", "Alien species invasions"], c: 0, e: "<b>Habitat loss and fragmentation</b> — NCERT states this explicitly." },
    { q: "Tropical rain forests once covered more than what percentage of the earth's land surface?", o: ["6 per cent", "14 per cent", "22 per cent", "30 per cent"], c: 1, e: "Once more than <b>14%</b>; now <b>no more than 6%</b>." },
    { q: "Tropical rain forests now cover no more than:", o: ["2 per cent", "6 per cent", "14 per cent", "22 per cent"], c: 1, e: "<b>6 per cent</b> — down from more than 14 per cent." },
    { q: "The Amazon rain forest is being cut and cleared mainly for:", o: ["Timber for paper only", "Cultivating soya beans and raising beef cattle", "Mining gold and diamonds", "Building cities"], c: 1, e: "<b>Soya beans</b> and <b>grasslands for beef cattle</b>." },
    { q: "The Amazon rain forest is called the:", o: ["Nursery of the earth", "Cradle of life", "Lungs of the planet", "Heart of the world"], c: 2, e: "The <b>'lungs of the planet'</b> — it produces ~20% of the earth's atmospheric oxygen." },
    { q: "Habitat FRAGMENTATION most badly affects:", o: ["Insects only", "Aquatic plants", "Microbes and fungi", "Mammals and birds requiring large territories, and animals with migratory habits"], c: 3, e: "Animals needing <b>large territories</b> or with <b>migratory habits</b> suffer population declines." },
    { q: "Over-exploitation occurs when:", o: ["'Need' turns to 'greed'", "Alien species are introduced", "A host species goes extinct", "Habitats are polluted"], c: 0, e: "NCERT's exact phrasing: when <b>'need' turns to 'greed'</b>." },
    { q: "Which two species does NCERT name as extinct due to over-exploitation?", o: ["Dodo and thylacine", "Steller's sea cow and the passenger pigeon", "Quagga and the Bali tiger", "Nile perch and cichlid fish"], c: 1, e: "<b>Steller's sea cow</b> and the <b>passenger pigeon</b>." },
    { q: "The introduction of the Nile perch into Lake Victoria led to the extinction of:", o: ["27 species of amphibians", "The African catfish", "More than 200 species of cichlid fish", "More than 2,000 species of native birds"], c: 2, e: "An ecologically unique assemblage of <b>more than 200 species of cichlid fish</b>." },
    { q: "Lake Victoria is located in:", o: ["Southeast Asia", "Australia", "South America", "East Africa"], c: 3, e: "<b>East Africa.</b>" },
    { q: "Which of the following is an invasive weed species in India?", o: ["Water hyacinth (Eichhornia)", "Bamboo", "Calotropis", "Rauwolfia vomitoria"], c: 0, e: "The three invasive weeds NCERT names are <b>carrot grass (Parthenium), Lantana and water hyacinth (Eichhornia)</b>." },
    { q: "The African catfish Clarias gariepinus was illegally introduced into Indian rivers for:", o: ["Ornamental purposes", "Aquaculture", "Mosquito control", "Weed control"], c: 1, e: "For <b>aquaculture</b> — and it now threatens the <b>indigenous catfishes</b> in our rivers." },
    { q: "Co-extinction occurs when:", o: ["A habitat is fragmented", "Two species compete for the same resource", "A species associated with another in an OBLIGATORY way also goes extinct when the first does", "An alien species invades a habitat"], c: 2, e: "Key word: <b>OBLIGATORY</b> association. E.g., a host fish's parasites, or a co-evolved plant–pollinator pair." },
    { q: "Which of the following is NCERT's example of co-extinction?", o: ["Prickly pear and the cactus-feeding moth", "Balanus and Chthamalus", "Nile perch and cichlid fish", "A host fish and its unique assemblage of parasites"], c: 3, e: "When a <b>host fish species becomes extinct, its parasites meet the same fate</b>. The other example is a <b>co-evolved plant–pollinator mutualism</b>." },
    { q: "The three categories of reasons for conserving biodiversity are:", o: ["Narrowly utilitarian, broadly utilitarian and ethical", "Genetic, species and ecological", "In situ, ex situ and legal", "Economic, political and social"], c: 0, e: "Mnemonic: <b>'Nature's Bounty and Ethics'</b>." },
    { q: "More than what percentage of the drugs currently sold worldwide are derived from plants?", o: ["5 per cent", "25 per cent", "50 per cent", "70 per cent"], c: 1, e: "More than <b>25 per cent</b>." },
    { q: "How many plant species contribute to traditional medicines used by native peoples around the world?", o: ["2,500", "25,000", "45,000", "1,25,000"], c: 1, e: "<b>25,000 species of plants.</b>" },
    { q: "Bioprospecting is defined as:", o: ["Searching for mineral deposits in forests", "Exploring molecular, genetic and species-level diversity for products of economic importance", "Cataloguing all species in a hotspot", "Cryopreserving gametes of threatened species"], c: 1, e: "Nations endowed with rich biodiversity can <b>reap enormous benefits</b> from bioprospecting." },
    { q: "The Amazon forest is estimated to produce what fraction of the total oxygen in the earth's atmosphere?", o: ["2 per cent", "6 per cent", "20 per cent", "50 per cent"], c: 2, e: "About <b>20 per cent</b>, through photosynthesis — hence 'lungs of the planet'." },
    { q: "Which pollinators does NCERT name in the broadly utilitarian argument?", o: ["Wind and water", "Ants and termites", "Bees, bumblebees, birds and bats", "Beetles, flies and moths"], c: 2, e: "<b>Bees, bumblebees, birds and bats.</b>" },
    { q: "The ETHICAL argument for conserving biodiversity rests on:", o: ["The need for bioprospecting revenue", "The economic value of drugs derived from plants", "Ecosystem services like oxygen production", "Every species having an INTRINSIC value and our moral duty to future generations"], c: 3, e: "Every species has <b>intrinsic value</b> even without economic value; we have a <b>moral duty</b> to pass on our <b>biological legacy in good order</b>." },
    { q: "'We save the entire forest to save the tiger' describes:", o: ["In situ conservation", "Bioprospecting", "Cryopreservation", "Ex situ conservation"], c: 0, e: "<b>In situ</b> — protecting the whole ecosystem in its natural habitat." },
    { q: "Which of the following is EX SITU conservation?", o: ["A sacred grove", "A botanical garden", "A biosphere reserve", "A national park"], c: 1, e: "<b>Botanical gardens, zoological parks and wildlife safari parks</b> are ex situ. Biosphere reserves, national parks, sanctuaries and sacred groves are all <b>in situ</b>." },
    { q: "The TWO criteria defining a biodiversity hotspot are:", o: ["High rainfall and warm temperature", "Presence of national parks and sanctuaries", "Very high species richness and a high degree of endemism", "Large area and high productivity"], c: 2, e: "<b>Species richness + endemism.</b> They are also regions of <b>accelerated habitat loss</b>." },
    { q: "Endemism means:", o: ["Species that have gone extinct", "Species introduced from elsewhere", "Species that migrate seasonally", "Species confined to a region and not found anywhere else"], c: 3, e: "An endemic species has <b>nowhere else to survive</b> — which is why endemism-rich regions are prioritised." },
    { q: "How many biodiversity hotspots are there in the world?", o: ["12", "25", "34", "90"], c: 2, e: "<b>34</b> — initially 25 were identified, and 9 more were subsequently added." },
    { q: "Initially how many biodiversity hotspots were identified?", o: ["12", "25", "34", "9"], c: 1, e: "<b>25</b>, with <b>9 more</b> added later → total <b>34</b>." },
    { q: "All the biodiversity hotspots put together cover what fraction of the earth's land area?", o: ["Less than 2 per cent", "About 6 per cent", "About 14 per cent", "About 30 per cent"], c: 0, e: "<b>Less than 2 per cent</b> — yet strict protection could cut ongoing mass extinctions by almost <b>30 per cent</b>." },
    { q: "Strict protection of biodiversity hotspots could reduce the ongoing mass extinctions by almost:", o: ["2 per cent", "10 per cent", "30 per cent", "50 per cent"], c: 2, e: "By almost <b>30 per cent</b>." },
    { q: "Which of these is NOT one of the three biodiversity hotspots covering India?", o: ["Himalaya", "Sundaland", "Western Ghats and Sri Lanka", "Indo-Burma"], c: 1, e: "India's three are <b>Western Ghats & Sri Lanka, Indo-Burma, and Himalaya</b>. Mnemonic: 'We Indians Have'." },
    { q: "India has how many biosphere reserves?", o: ["14", "90", "448", "34"], c: 0, e: "<b>14 biosphere reserves</b>, <b>90 national parks</b>, <b>448 wildlife sanctuaries</b>." },
    { q: "India has how many national parks?", o: ["14", "90", "448", "34"], c: 1, e: "<b>90 national parks.</b>" },
    { q: "India has how many wildlife sanctuaries?", o: ["14", "90", "448", "484"], c: 2, e: "<b>448 wildlife sanctuaries.</b>" },
    { q: "Sacred groves are found in which of the following?", o: ["The Sundarbans of West Bengal", "The Andaman Islands", "Khasi and Jaintia Hills of Meghalaya", "The Thar Desert of Gujarat"], c: 2, e: "NCERT's list: <b>Khasi & Jaintia Hills (Meghalaya)</b>, <b>Aravalli Hills (Rajasthan)</b>, <b>Western Ghats (Karnataka & Maharashtra)</b>, <b>Sarguja, Chanda & Bastar (MP)</b>." },
    { q: "In which state are sacred groves the last refuges for a large number of rare and threatened plants?", o: ["Madhya Pradesh", "Rajasthan", "Karnataka", "Meghalaya"], c: 3, e: "<b>Meghalaya.</b>" },
    { q: "Sacred groves are an example of:", o: ["In situ conservation", "Bioprospecting", "Cryopreservation", "Ex situ conservation"], c: 0, e: "<b>In situ</b> — community-driven, culturally enforced protection of the whole habitat." },
    { q: "Cryopreservation in ex situ conservation is used to preserve:", o: ["Whole animals", "Gametes of threatened species in viable and fertile condition", "Soil samples", "Sacred groves"], c: 1, e: "<b>Gametes</b>, kept viable and fertile for long periods." },
    { q: "Which of these is NOT a modern ex situ conservation technique?", o: ["In vitro fertilisation", "Tissue culture propagation of plants", "Declaring a region a biodiversity hotspot", "Cryopreservation of gametes"], c: 2, e: "Declaring a <b>hotspot</b> is <b>IN SITU</b>. The other three are ex situ (mnemonic C-I-T-S, with seed banks)." },
    { q: "Seeds of different genetic strains of commercially important plants are kept in:", o: ["Wildlife safari parks", "Biosphere reserves", "Zoological parks", "Seed banks"], c: 3, e: "<b>Seed banks</b> — part of the modern ex situ toolkit." },
    { q: "The Earth Summit was held in:", o: ["Rio de Janeiro, 1992", "Johannesburg, 2002", "Stockholm, 1972", "Nairobi, 2010"], c: 0, e: "<b>Rio de Janeiro, 1992.</b> It called on all nations to conserve biodiversity and use its benefits sustainably." },
    { q: "The World Summit on Sustainable Development (2002) was held in:", o: ["Rio de Janeiro, Brazil", "Johannesburg, South Africa", "Kyoto, Japan", "Montreal, Canada"], c: 1, e: "<b>Johannesburg, South Africa</b> — where <b>190 countries</b> pledged commitment." },
    { q: "How many countries pledged their commitment at the 2002 World Summit on Sustainable Development?", o: ["34", "90", "190", "448"], c: 2, e: "<b>190 countries</b>, pledging to significantly reduce the rate of biodiversity loss by <b>2010</b>." },
    { q: "The target year set at the Johannesburg summit for significantly reducing biodiversity loss was:", o: ["2002", "2010", "2020", "2050"], c: 1, e: "<b>2010</b> — at global, regional and local levels." },
    { q: "Why is biodiversity conservation a collective responsibility of all nations?", o: ["Because all countries have equal species richness", "Because the UN mandates it", "Because biodiversity knows no political boundaries", "Because hotspots are equally distributed"], c: 2, e: "NCERT's exact phrase: <b>'Biodiversity knows no political boundaries.'</b>" },
    { q: "Animals achieved greater diversification than plants largely because of:", o: ["Their ability to photosynthesise", "Their shorter life spans", "Their smaller genome size", "Greater motility, complex nervous systems and (in arthropods) a rigid exoskeleton"], c: 3, e: "Motility lets them <b>escape adverse conditions and colonise new habitats</b>; nervous systems let them <b>perceive and respond</b>; the arthropod <b>exoskeleton</b> gave protection and support." },
    { q: "Which species was DELIBERATELY driven to extinction, and is used to justify the exception to conservation?", o: ["The smallpox virus", "The Nile perch", "The dodo", "The passenger pigeon"], c: 0, e: "The <b>smallpox virus</b> was deliberately eradicated worldwide through vaccination — justified by <b>human welfare</b>, since it provides no ecosystem service." },
    { q: "Which of the following pairs is INCORRECTLY matched?", o: ["Alexander von Humboldt — species–area relationship", "David Tilman — rivet popper hypothesis", "Robert May — global estimate of 7 million species", "Edward Wilson — popularised 'biodiversity'"], c: 1, e: "The <b>rivet popper hypothesis is PAUL EHRLICH's</b>. Tilman ran the <b>outdoor-plot experiments</b>." }
  ],

  /* ---------- 7. MATCH-UP (75 pairs → 10 shuffled sets of 7) ---------- */
  match: [
    /* SET A — People & terms */
    { term: "Edward Wilson", def: "Sociobiologist who popularised the term 'biodiversity'" },
    { term: "Alexander von Humboldt", def: "Discovered the species-area relationship in the South American jungles" },
    { term: "Robert May", def: "Estimated global species diversity at about 7 million" },
    { term: "David Tilman", def: "Outdoor-plot experiments: more species means less biomass variation and higher productivity" },
    { term: "Paul Ehrlich", def: "Proposed the Rivet Popper hypothesis" },
    { term: "Bioprospecting", def: "Exploring molecular, genetic and species-level diversity for products of economic importance" },
    { term: "Endemism", def: "Species confined to a region and found nowhere else" },

    /* SET B — Three levels */
    { term: "Genetic diversity", def: "Variation WITHIN a single species over its distributional range" },
    { term: "Rauwolfia vomitoria", def: "Medicinal plant whose reserpine potency varies across Himalayan ranges" },
    { term: "50,000 rice strains and 1,000 mango varieties", def: "India's showcase of genetic diversity" },
    { term: "Species diversity", def: "Western Ghats have more amphibian species than the Eastern Ghats" },
    { term: "Ecological diversity", def: "India beats Norway — deserts, rain forests, mangroves, coral reefs, wetlands, estuaries, alpine meadows" },

    /* SET C — Global & Indian numbers */
    { term: "1.5 million", def: "Species described so far, according to IUCN 2004" },
    { term: "7 million", def: "Robert May's conservative estimate of global species diversity" },
    { term: "More than 70 per cent", def: "Share of described species that are animals" },
    { term: "No more than 22 per cent", def: "Share of described species that are plants" },
    { term: "Insects", def: "Most species-rich taxonomic group — 70 per cent of all animals" },
    { term: "Fungi", def: "Outnumber fishes, amphibians, reptiles and mammals combined" },
    { term: "2.4 per cent and 8.1 per cent", def: "India's share of world land area, and of global species diversity" },
    { term: "12 mega-diversity countries", def: "The group India belongs to" },
    { term: "45,000 and 90,000", def: "Plant and animal species recorded from India" },

    /* SET D — Latitudinal gradient */
    { term: "23.5 degrees N to 23.5 degrees S", def: "The latitudinal range of the tropics" },
    { term: "Colombia", def: "Near the equator — nearly 1,400 bird species" },
    { term: "New York (41 degrees N)", def: "105 bird species" },
    { term: "Greenland (71 degrees N)", def: "Only 56 bird species" },
    { term: "Ecuador vs the Midwest USA", def: "A tropical forest has up to 10 times the vascular plant species of a temperate one" },
    { term: "Amazonian rain forest", def: "The greatest biodiversity on Earth" },
    { term: "427 and 427", def: "Amazon mammal and amphibian species counts — identical" },
    { term: "2 million insects", def: "Estimated still undiscovered in the Amazon rain forest" },
    { term: "TIME hypothesis", def: "Tropics remained undisturbed by glaciations, giving long evolutionary time" },
    { term: "CONSTANCY hypothesis", def: "Less seasonal, more predictable environments promote niche specialisation" },
    { term: "ENERGY hypothesis", def: "More solar energy raises productivity, contributing indirectly to diversity" },

    /* SET E — Species-area relationship */
    { term: "log S = log C + Z log A", def: "The species-area relationship on a logarithmic scale" },
    { term: "Rectangular hyperbola", def: "Shape of the species-area curve on a normal scale" },
    { term: "Z", def: "Slope of the regression line" },
    { term: "C", def: "Y-intercept of the species-area line" },
    { term: "0.1 to 0.2", def: "Z value within a region, regardless of taxon" },
    { term: "0.6 to 1.2", def: "Z value across entire continents — a much steeper slope" },
    { term: "1.15", def: "Z value for frugivorous birds and mammals across tropical forests of different continents" },
    { term: "Plants in Britain, birds in California, molluscs in New York", def: "Taxa whose regression slopes are amazingly similar" },

    /* SET F — Importance & loss */
    { term: "Rivet Popper hypothesis", def: "Airplane is the ecosystem; rivets are the species; wing rivets are the key species" },
    { term: "Steady, sturdy, sealed", def: "The three conditions of a stable community" },
    { term: "784 species", def: "Extinctions in the last 500 years, per the IUCN Red List 2004" },
    { term: "338, 359 and 87", def: "Vertebrates, invertebrates and plants among the 784 extinctions" },
    { term: "15,500", def: "Species worldwide presently facing the threat of extinction" },
    { term: "100 to 1,000 times", def: "How much faster current extinction rates are than pre-human rates" },
    { term: "Amphibians (32 per cent)", def: "The group most threatened with extinction" },
    { term: "Birds (12 per cent)", def: "The least threatened of the four groups NCERT lists" },

    /* SET G — Extinct species & the Evil Quartet */
    { term: "Dodo", def: "Extinct — Mauritius" },
    { term: "Quagga", def: "Extinct — Africa" },
    { term: "Thylacine", def: "Extinct — Australia" },
    { term: "Steller's Sea Cow", def: "Extinct — Russia; also a victim of over-exploitation" },
    { term: "Bali, Javan and Caspian", def: "The three extinct subspecies of tiger" },
    { term: "Habitat loss and fragmentation", def: "The MOST IMPORTANT cause of extinction" },
    { term: "14 per cent to 6 per cent", def: "Shrinkage of the world's tropical rain forests" },
    { term: "Soya beans and beef cattle", def: "What the Amazon is being cleared for" },
    { term: "When need turns to greed", def: "The definition of over-exploitation" },
    { term: "Nile perch in Lake Victoria", def: "Alien invasion that wiped out more than 200 cichlid fish species" },
    { term: "Parthenium, Lantana and Eichhornia", def: "Invasive weed species threatening India's natives" },
    { term: "Clarias gariepinus", def: "African catfish illegally introduced for aquaculture" },
    { term: "Co-extinction", def: "A host fish dies and its obligate parasites die with it" },

    /* SET H — Conservation */
    { term: "In situ conservation", def: "Save the entire forest to save the tiger — protection in the natural habitat" },
    { term: "Ex situ conservation", def: "Threatened species taken out of their habitat and given special care" },
    { term: "Biodiversity hotspot", def: "Region with very high species richness AND high endemism" },
    { term: "25 plus 9 equals 34", def: "How the world's hotspot count was reached" },
    { term: "Less than 2 per cent", def: "Land area covered by all hotspots put together" },
    { term: "Almost 30 per cent", def: "Reduction in mass extinctions achievable by strictly protecting hotspots" },
    { term: "Western Ghats and Sri Lanka, Indo-Burma, Himalaya", def: "The three hotspots covering India" },
    { term: "14, 90 and 448", def: "India's biosphere reserves, national parks and wildlife sanctuaries" },
    { term: "Sacred groves", def: "Forest tracts venerated and given total protection — in situ, community-driven" },
    { term: "Meghalaya", def: "Where sacred groves are the last refuges of many rare and threatened plants" },
    { term: "Cryopreservation", def: "Preserving gametes of threatened species in viable and fertile condition" },
    { term: "Rio de Janeiro, 1992", def: "The Earth Summit" },
    { term: "Johannesburg, 2002", def: "World Summit on Sustainable Development — 190 countries, 2010 target" },
    { term: "Smallpox virus", def: "A species deliberately driven extinct, justified by human welfare" }
  ],

  /* ---------- 8. BUILD THE PATHWAY (9 sets) ---------- */
  pathways: [
    {
      title: "The Species–Area Relationship, Step by Step",
      prompt: "Sequence how Humboldt's field observation became a mathematical law.",
      steps: ["Humboldt explores the South American jungles", "He observes that species richness increases with explored area — but only UP TO A LIMIT", "Plotting species richness (S) against area (A) gives a RECTANGULAR HYPERBOLA", "Both axes are converted to a LOGARITHMIC scale", "The relationship straightens into a STRAIGHT LINE", "The line is described by: log S = log C + Z log A", "Z (the slope / regression coefficient) is found to be 0.1 to 0.2 within a region", "Across whole continents, Z becomes much steeper: 0.6 to 1.2"]
    },
    {
      title: "The Evil Quartet — Ranked",
      prompt: "Order the four causes of biodiversity loss, starting with the MOST IMPORTANT.",
      steps: ["1. Habitat loss and fragmentation — the most important cause", "2. Over-exploitation — when 'need' turns to 'greed'", "3. Alien species invasions — e.g., Nile perch in Lake Victoria", "4. Co-extinctions — obligate partners die together"]
    },
    {
      title: "The Rivet Popper Hypothesis",
      prompt: "Sequence Paul Ehrlich's analogy from take-off to catastrophe.",
      steps: ["The airplane represents the ECOSYSTEM", "The thousands of rivets holding it together represent the SPECIES", "Every passenger pops a rivet to take home — a species is driven to extinction", "At first, flight safety is NOT noticeably affected", "As more and more rivets are removed, the plane becomes DANGEROUSLY WEAK over time", "WHICH rivet is popped turns out to be critical", "Losing WING rivets (key species) is far more serious than losing SEAT or WINDOW rivets"]
    },
    {
      title: "Alien Invasion — Lake Victoria",
      prompt: "Sequence the collapse of Lake Victoria's cichlid fish.",
      steps: ["The Nile perch is introduced into Lake Victoria, east Africa", "As an alien species it faces no natural checks in the invaded lake", "It preys heavily on the lake's native cichlid fish", "The ecologically unique assemblage of cichlids collapses", "More than 200 species of cichlid fish are driven to extinction"]
    },
    {
      title: "How Ecologists Estimate Global Species Number",
      prompt: "Sequence the statistical method used to arrive at a global estimate.",
      steps: ["Note that species inventories are more complete in TEMPERATE than in TROPICAL countries", "Recognise that most undiscovered species live in the TROPICS", "Take an exhaustively studied group of INSECTS", "Statistically compare its temperate vs tropical species richness", "Extrapolate that ratio to other groups of animals and plants", "Arrive at a gross global estimate — Robert May's figure of about 7 million"]
    },
    {
      title: "In Situ Conservation — The Ladder",
      prompt: "Sequence India's in situ conservation strategy from principle to practice.",
      steps: ["Principle: conserve the WHOLE ECOSYSTEM — save the forest to save the tiger", "Identify regions of very high species richness AND high endemism", "Designate them as BIODIVERSITY HOTSPOTS (34 worldwide, 3 in India)", "Legally protect biodiversity-rich regions as biosphere reserves, national parks and sanctuaries", "India: 14 biosphere reserves, 90 national parks, 448 wildlife sanctuaries", "Community-protected SACRED GROVES add further refuge, especially in Meghalaya"]
    },
    {
      title: "Ex Situ Conservation — The Modern Toolkit",
      prompt: "Sequence the ex situ methods, from the oldest to the most advanced.",
      steps: ["Threatened animals and plants are taken OUT of their natural habitat", "They are housed in zoological parks, botanical gardens and wildlife safari parks", "GAMETES are preserved by CRYOPRESERVATION in viable and fertile condition", "Eggs are fertilised IN VITRO", "Plants are propagated using TISSUE CULTURE", "Seeds of different genetic strains are stored in SEED BANKS"]
    },
    {
      title: "Global Conservation Timeline",
      prompt: "Sequence the international response to biodiversity loss.",
      steps: ["Recognition that biodiversity knows no political boundaries", "1992 — The Earth Summit is held in Rio de Janeiro", "All nations are called upon to conserve biodiversity and use its benefits sustainably", "2002 — The World Summit on Sustainable Development is held in Johannesburg, South Africa", "190 countries pledge their commitment", "The target: a significant reduction in the rate of biodiversity loss by 2010, at global, regional and local levels"]
    },
    {
      title: "Habitat Loss — From 14% to Extinction",
      prompt: "Trace the chain from deforestation to the Sixth Extinction.",
      steps: ["Tropical rain forests once covered more than 14 per cent of the earth's land surface", "The Amazon is cut and cleared for soya beans and for beef-cattle grasslands", "Rain forests now cover no more than 6 per cent of the land surface", "Because species richness rises with area (log S = log C + Z log A), species vanish with the habitat", "Large habitats break into fragments; animals needing large territories decline", "Current extinction rates run 100 to 1,000 times faster than pre-human rates", "If trends continue, nearly half of all species could be wiped out within 100 years"]
    }
  ],

  /* ---------- 9. BOSS BATTLE (27 — hard, integrative, numerical) ---------- */
  boss: [
    { q: "Assertion: The rivet popper hypothesis says all species are equally important. Reason: In the analogy, losing wing rivets is no worse than losing seat rivets.", o: ["Both A and R are true, and R is the correct explanation", "Both A and R are true, but R is NOT the correct explanation", "A is true, R is false", "Both A and R are false"], c: 3, e: "<b>BOTH FALSE.</b> Ehrlich's whole point is that <b>WHICH rivet is popped is CRITICAL</b> — losing rivets on the <b>WINGS</b> (key species) is <b>far more serious</b> than losing a few on the seats or windows." },
    { q: "The IUCN 2004 figures are 338 vertebrates, 359 invertebrates and 87 plants. Which statement is CORRECT?", o: ["They total 784, and vertebrates outnumber invertebrates", "They total 784, and invertebrates outnumber vertebrates", "They total 748, and plants outnumber vertebrates", "They total 900, and all three are roughly equal"], c: 1, e: "338 + 359 + 87 = <b>784</b>. And <b>359 invertebrates &gt; 338 vertebrates</b> — the reversal is the trap." },
    { q: "A researcher samples a small region and finds Z = 0.15. She then repeats the analysis across four continents and finds Z = 1.1. What does this tell her?", o: ["Her small-area data must be wrong", "Species richness rises far more steeply across continents, because each continent has its own independently evolved species pool", "The species–area relationship does not hold at continental scale", "Z should be identical at all scales"], c: 1, e: "Within a region you keep re-sampling the <b>same species pool</b> (Z = 0.1–0.2). Across <b>continents</b>, each new area brings a genuinely <b>different</b> pool → <b>Z = 0.6–1.2</b>. Both results are exactly what NCERT predicts." },
    { q: "Which sequence correctly ranks these groups by the percentage facing extinction, HIGHEST first?", o: ["Gymnosperms > Amphibians > Birds > Mammals", "Mammals > Amphibians > Birds > Gymnosperms", "Birds > Mammals > Gymnosperms > Amphibians", "Amphibians > Gymnosperms > Mammals > Birds"], c: 3, e: "<b>Amphibians 32% &gt; Gymnosperms 31% &gt; Mammals 23% &gt; Birds 12%.</b> Amphibians are also the group NCERT names as most vulnerable." },
    { q: "Statement I: Sacred groves are an example of in situ conservation. Statement II: Botanical gardens are an example of in situ conservation.", o: ["Only I is correct", "Only II is correct", "Both I and II are correct", "Neither is correct"], c: 0, e: "<b>Only I.</b> Sacred groves protect the <b>whole habitat in place</b> → in situ. <b>Botanical gardens are EX SITU</b> — species removed from their natural habitat." },
    { q: "A student writes: 'India has 34 hotspots and is one of 25 mega-diversity countries.' How many errors are in this claim?", o: ["None — it is correct", "One error", "Two errors", "Three errors"], c: 2, e: "<b>TWO errors.</b> (1) The <b>WORLD</b> has 34 hotspots; <b>India has THREE</b>. (2) India is one of <b>12</b> mega-diversity countries — 25 is the number of hotspots <b>initially</b> identified." },
    { q: "Which pair correctly matches a scientist to their contribution?", o: ["Ehrlich — rivet popper hypothesis; Tilman — outdoor plot experiments", "Wilson — species–area relationship; Humboldt — popularised 'biodiversity'", "May — rivet popper hypothesis; Wilson — 7 million species estimate", "Tilman — rivet popper hypothesis; Ehrlich — outdoor plot experiments"], c: 0, e: "<b>Ehrlich = rivet popper. Tilman = outdoor plots.</b> Wilson popularised 'biodiversity'. Humboldt found the species–area relationship. May estimated 7 million species." },
    { q: "Assertion: Genetic diversity is illustrated by the Western Ghats having more amphibian species than the Eastern Ghats. Reason: Genetic diversity refers to variation within a single species.", o: ["Both A and R are true, and R is the correct explanation", "Both A and R are true, but R is NOT the correct explanation", "A is false, R is true", "Both A and R are false"], c: 2, e: "<b>A is FALSE, R is TRUE.</b> More amphibian SPECIES = <b>SPECIES diversity</b>. Genetic diversity is indeed variation <b>within one species</b> (e.g., Rauwolfia's reserpine)." },
    { q: "In the equation log S = log C + Z log A, if Z = 0.2 and the area is increased 100-fold, species richness increases by a factor of approximately:", o: ["1.2", "1.6", "2.5", "20"], c: 2, e: "S is proportional to A<sup>Z</sup>, so the factor = 100<sup>0.2</sup> = 10<sup>(2 &times; 0.2)</sup> = 10<sup>0.4</sup> &asymp; <b>2.5</b>.<br><br><b>The lesson:</b> with a small Z, a <b>100-fold</b> increase in area yields only a <b>~2.5-fold</b> increase in species. That is exactly why the untransformed curve is a <b>rectangular hyperbola</b> that flattens &mdash; Humboldt's 'only up to a limit'." },
    { q: "Which of the following would NOT reduce biodiversity, according to NCERT?", o: ["Fragmenting a large forest into small patches", "Establishing a sacred grove in Meghalaya", "Over-harvesting marine fish populations", "Introducing the Nile perch into Lake Victoria"], c: 1, e: "A <b>sacred grove</b> is <b>in situ CONSERVATION</b>. The other three are, respectively, alien invasion, habitat fragmentation and over-exploitation — three-quarters of the Evil Quartet." },
    { q: "The Amazon rain forest produces ~20% of atmospheric oxygen, yet is being cleared for soya and cattle. Which two categories does this single fact span?", o: ["Narrowly utilitarian value, and over-exploitation", "Ethical value, and co-extinction", "Genetic diversity, and alien invasion", "Broadly utilitarian value, and habitat loss"], c: 3, e: "Oxygen production is an <b>ecosystem service → BROADLY UTILITARIAN</b>. Clearing for soya and beef is <b>HABITAT LOSS</b> — the most important cause of extinction." },
    { q: "Which statement about biodiversity hotspots is FALSE?", o: ["They are regions of unusually LOW habitat loss", "Strict protection could reduce ongoing mass extinctions by almost 30 per cent", "They are defined by high species richness and high endemism", "They cover less than 2 per cent of the earth's land area"], c: 0, e: "Hotspots are regions of <b>ACCELERATED habitat loss</b> — which is precisely what makes them urgent." },
    { q: "Robert May estimates 7 million species globally, but only ~1.5 million have been described. Applying the same logic to India (45,000 plants recorded), roughly how many plant species remain undiscovered?", o: ["About 10,000", "More than 1,00,000", "More than 3,00,000", "About 45,000"], c: 1, e: "If only <b>22%</b> of species have been recorded, India would still have more than <b>1,00,000 plant species</b> and more than <b>3,00,000 animal species</b> yet to be discovered." },
    { q: "Which combination of NCERT facts is entirely CORRECT?", o: ["Fungi are fewer than fishes alone; insects are 22% of animals", "Animals are 22% of species; plants are 70%", "Insects are 70% of all animals; animals are >70% of all described species", "Insects are 22% of all animals; plants are 70% of all species"], c: 2, e: "<b>Animals &gt;70% of described species; insects = 70% of animals; plants ≤22%.</b> Also: fungi outnumber fishes + amphibians + reptiles + mammals COMBINED." },
    { q: "A species of fig tree goes extinct, and its sole pollinator wasp disappears with it. This is:", o: ["Habitat fragmentation", "Over-exploitation", "Alien species invasion", "Co-extinction"], c: 3, e: "<b>Co-extinction</b> — a co-evolved <b>plant–pollinator mutualism</b> where extinction of one <b>invariably leads to the extinction of the other</b>. (Cross-link to the fig–wasp mutualism of Chapter 11.)" },
    { q: "Which of the following statements about David Tilman's findings is INCORRECT?", o: ["He proved definitively that species number does not matter to ecosystem function", "Plots with more species showed less year-to-year variation in total biomass", "Increased diversity contributed to higher productivity", "He used long-term outdoor plots"], c: 0, e: "NCERT calls his answers <b>'tentative'</b> and explicitly says ecologists have <b>NOT been able to give a definitive answer</b> — but his results support the view that diversity matters." },
    { q: "Colombia has 1,400 bird species and Greenland has 56. What best explains the difference?", o: ["Colombia has more area", "The latitudinal gradient — diversity decreases from the equator towards the poles", "Greenland has more predators", "Colombia has fewer alien species"], c: 1, e: "The <b>latitudinal gradient</b>. Colombia is near the <b>equator</b>; Greenland is at <b>71° N</b>. Explained by <b>time, constancy and energy</b>." },
    { q: "Which is the correct chronological and numerical pairing for the two summits?", o: ["Rio 2002 (Earth Summit); Johannesburg 1992 (190 countries)", "Rio 1992 (190 countries); Johannesburg 2002 (2010 target)", "Rio 1992 (Earth Summit); Johannesburg 2002 (190 countries, 2010 target)", "Johannesburg 1992; Rio 2002 (190 countries)"], c: 2, e: "<b>Rio de Janeiro 1992 = the Earth Summit.</b> <b>Johannesburg 2002 = World Summit on Sustainable Development, 190 countries, target year 2010.</b>" },
    { q: "Why is the deliberate eradication of the smallpox virus defensible, whereas driving a tiger subspecies extinct is not?", o: ["Because tigers are prettier", "Because the smallpox virus had low genetic diversity", "Because viruses are not really alive", "Because smallpox is an obligate human pathogen providing no ecosystem service, and its removal serves human welfare"], c: 3, e: "The exception is <b>narrow</b>: a pathogen that causes enormous suffering, occupies no beneficial ecological role, and whose removal weakens no food web or nutrient cycle. It does <b>not</b> extend to organisms that merely inconvenience us." },
    { q: "Which pair of Chapter 13 numbers is CORRECTLY matched?", o: ["12 — mega-diversity countries; 34 — biodiversity hotspots", "25 — total hotspots today; 9 — hotspots in India", "3 — hotspots worldwide; 34 — hotspots in India", "34 — mega-diversity countries; 12 — biodiversity hotspots"], c: 0, e: "<b>India is one of 12 MEGA-DIVERSITY countries.</b> There are <b>34 HOTSPOTS</b> in the world (25 initially + 9 added), of which <b>3</b> cover India." },
    { q: "An ecologist wants to conserve an endemic orchid that survives in only one small valley, now being cleared. The single most effective step, per NCERT's framework, is:", o: ["Store its seeds in a seed bank", "Protect the valley itself, conserving the whole ecosystem in situ", "Cryopreserve its gametes", "Move a few plants to a botanical garden"], c: 1, e: "<b>IN SITU is the primary approach</b> — 'we save the entire forest to save the tiger'. Because the species is <b>endemic</b>, it has nowhere else to survive. Ex situ methods (garden, seed bank, cryopreservation) are valuable BACKUPS, not substitutes." },
    { q: "Habitat loss, over-exploitation, alien invasion and co-extinction all appear in a question. What must you say if asked for the SINGLE most important cause?", o: ["Over-exploitation", "Alien species invasion", "Habitat loss and fragmentation", "Co-extinction"], c: 2, e: "NCERT states it explicitly: <b>habitat loss and fragmentation is the MOST IMPORTANT cause driving animals and plants to extinction</b>." },
    { q: "Which statement correctly links two chapters of the ecology unit?", o: ["The Nile perch appears in Ch 11 as a predation example", "The rivet popper hypothesis explains the 10 per cent law of Ch 12", "The Amazon's oxygen output is an example of secondary productivity", "Parthenium hysterophorus appears as an invasive weed in Ch 13 AND as a density-measurement example in Ch 11"], c: 3, e: "<b><i>Parthenium</i> (carrot grass)</b> appears in <b>Ch 11</b> as the '200 carrot grass plants vs 1 banyan' density example, and in <b>Ch 13</b> as an invasive weed. The same organism, two roles." },
    { q: "Which is NOT true of the tropical CONSTANCY hypothesis?", o: ["Constant environments reduce the number of available niches", "Tropical environments are less seasonal", "Tropical environments are relatively more constant and predictable", "Constant environments promote niche specialisation"], c: 0, e: "Constancy <b>PROMOTES</b> niche specialisation — allowing MORE species to coexist in narrower niches, hence <b>greater</b> species diversity." },
    { q: "In situ and ex situ conservation differ fundamentally because:", o: ["In situ costs more money", "In situ protects the whole ecosystem in its natural habitat; ex situ protects individual species outside it", "Ex situ is only used for plants", "In situ is only used for animals"], c: 1, e: "In situ = <b>on site, whole ecosystem</b>. Ex situ = <b>off site, individual threatened species given special care</b>." },
    { q: "Assertion: All hotspots together cover less than 2% of the earth's land area. Reason: Protecting them strictly could reduce ongoing mass extinctions by almost 30%.", o: ["Both A and R are true, and R is a consequence of the extraordinary species density implied by A", "Both A and R are true, but R is unrelated to A", "A is true, R is false", "Both A and R are false"], c: 0, e: "Both figures are correct, and they are <b>logically linked</b>: hotspots pack an extraordinary number of species (and endemics) into a tiny area, which is exactly why protecting <b>&lt;2% of land</b> can save <b>~30% of threatened species</b>." },
    { q: "Which single fact best demonstrates that biodiversity conservation has direct economic value?", o: ["Waking up to a bulbul's song is pleasurable", "The Amazon produces 20% of atmospheric oxygen", "More than 25% of drugs sold worldwide are derived from plants", "Every species has intrinsic value"], c: 2, e: "That is the <b>NARROWLY UTILITARIAN</b> argument — direct economic benefit. Oxygen production is <b>broadly utilitarian</b> (ecosystem service); intrinsic value and the bulbul's song are <b>ethical/aesthetic</b>." }
  ]
};
