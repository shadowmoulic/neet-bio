/* ============================================================================
   BioArena — CHAPTER 12 : ECOSYSTEM
   NCERT Class XII Biology (Rationalised 2023-24) — lebo112
   Sections retained: 12.1 Structure & Function | 12.2 Productivity |
   12.3 Decomposition | 12.4 Energy Flow | 12.5 Ecological Pyramids
   (+ Nutrient Cycling & Ecosystem Services, which survive in the SUMMARY
    and EXERCISES only — flagged clearly in the notes.)
   ============================================================================ */

DATA.chapters.ecosystem = {

  /* ---------- 1. METADATA ---------- */
  id: "ecosystem",
  num: 12,
  title: "Ecosystem",
  subtitle: "Structure & function · Productivity (GPP/NPP) · Decomposition · Energy flow & the 10% law · Ecological pyramids",
  color: "#16a085",
  colorD: "#0e6655",
  glyph: "🌍",

  /* ---------- 2. STUDY NOTES (9 sections) ---------- */
  notes: [

    {
      id: "e1_structure",
      heading: "1. Ecosystem — What It Is, Its Types & Its Structure",
      html: `
        <p>An <span class="kw">ecosystem</span> is a <b>functional unit of nature</b> where <b>living organisms interact among themselves AND with the surrounding physical environment</b>.</p>

        <div class="callout"><b>Scale:</b> An ecosystem varies greatly in size — from a <b>small pond</b> to a <b>large forest or a sea</b>. Many ecologists regard the <b>entire biosphere as a global ecosystem</b>, a composite of all local ecosystems on Earth. Because that is too big and complex to study at once, it is divided into two basic categories.</div>

        <table class="cmp">
          <thead><tr><th>Category</th><th>NCERT examples</th></tr></thead>
          <tbody>
            <tr><td><b>Terrestrial</b></td><td><b>Forest, Grassland, Desert</b></td></tr>
            <tr><td><b>Aquatic</b></td><td><b>Pond, Lake, Wetland, River, Estuary</b></td></tr>
            <tr><td><b>Man-made</b></td><td><b>Crop fields, Aquarium</b></td></tr>
          </tbody>
        </table>

        <h4>Structural features — the two S's</h4>
        <p>The interaction of biotic and abiotic components produces a <b>physical structure that is characteristic for each type of ecosystem</b>. Its two structural features are:</p>
        <table class="cmp">
          <thead><tr><th>Feature</th><th>Definition</th><th>Example</th></tr></thead>
          <tbody>
            <tr><td><b>Species composition</b></td><td><b>Identification and enumeration</b> of the plant and animal species of an ecosystem</td><td>Listing every species present in a forest</td></tr>
            <tr><td><b>Stratification</b></td><td><b>VERTICAL distribution</b> of different species occupying different levels</td><td><b>Trees</b> = top strata; <b>Shrubs</b> = second layer; <b>Herbs and grasses</b> = bottom layers</td></tr>
          </tbody>
        </table>

        <h4>Components of an ecosystem</h4>
        <table class="cmp">
          <thead><tr><th>Type</th><th>What it includes</th></tr></thead>
          <tbody>
            <tr><td><b>ABIOTIC</b></td><td>Inorganic materials — <b>air, water and soil</b></td></tr>
            <tr><td><b>BIOTIC</b></td><td><b>Producers, Consumers and Decomposers</b></td></tr>
          </tbody>
        </table>

        <h4>The FOUR functional aspects (the whole chapter, in one list)</h4>
        <div class="flow">
          <span class="node">1. Productivity</span><span class="arr">→</span>
          <span class="node">2. Decomposition</span><span class="arr">→</span>
          <span class="node">3. Energy Flow</span><span class="arr">→</span>
          <span class="node">4. Nutrient Cycling</span>
        </div>
        <div class="callout"><b>Frame it as INPUT → TRANSFER → OUTPUT:</b><br>
          <b>Input</b> = productivity &nbsp;|&nbsp; <b>Transfer</b> = food chain/web + nutrient cycling &nbsp;|&nbsp; <b>Output</b> = degradation and energy loss.</div>

        <div class="callout"><b>What the 2023-24 rationalisation DELETED from this chapter</b> (do not waste time on these unless your coaching insists):<br>
          • Ecological Succession (hydrarch, xerarch, pioneer species, climax community)<br>
          • The detailed <b>Carbon cycle</b> and <b>Phosphorus cycle</b> diagrams<br>
          • Ecosystem Services with <b>Robert Constanza's</b> valuation figures<br><br>
          <b>What SURVIVES only in the Summary + Exercises:</b> the definition of nutrient cycling, gaseous vs sedimentary cycles, and a one-line mention of ecosystem services. Section 8 below covers exactly that much — no more.</div>
      `
    },

    {
      id: "e2_pond",
      heading: "2. The Pond — A Complete Model Ecosystem",
      html: `
        <p>NCERT uses a <b>small pond</b> as the model because it is a <b>fairly self-sustainable unit</b> and a <b>rather simple example</b> that still explains even the complex interactions of an aquatic ecosystem. A pond is a <b>shallow water body</b> in which all <b>four basic functional components are well exhibited</b>.</p>

        <table class="cmp">
          <thead><tr><th>Component</th><th>In the pond</th></tr></thead>
          <tbody>
            <tr>
              <td><b>ABIOTIC</b></td>
              <td>The <b>water</b> with all the <b>dissolved inorganic and organic substances</b>, and the <b>rich soil deposit at the bottom</b> of the pond</td>
            </tr>
            <tr>
              <td><b>Regulating factors</b></td>
              <td>The <b>solar input</b>, the <b>cycle of temperature</b>, <b>day-length</b> and other <b>climatic conditions</b> — these regulate the <b>rate of function of the entire pond</b></td>
            </tr>
            <tr>
              <td><b>AUTOTROPHS</b></td>
              <td><b>Phytoplankton</b>, some <b>algae</b>, and the <b>floating, submerged and marginal plants</b> found at the edges</td>
            </tr>
            <tr>
              <td><b>CONSUMERS</b></td>
              <td><b>Zooplankton</b>, the <b>free-swimming</b> forms and the <b>bottom-dwelling</b> forms</td>
            </tr>
            <tr>
              <td><b>DECOMPOSERS</b></td>
              <td><b>Fungi, bacteria and flagellates</b> — especially abundant <b>at the bottom of the pond</b></td>
            </tr>
          </tbody>
        </table>

        <h4>The four functions the pond performs (same as the whole biosphere)</h4>
        <div class="flow">
          <span class="node">Autotrophs convert INORGANIC → ORGANIC using the sun's radiant energy</span><span class="arr">→</span>
          <span class="node">Heterotrophs CONSUME the autotrophs</span><span class="arr">→</span>
          <span class="node">Dead matter is DECOMPOSED and MINERALISED</span><span class="arr">→</span>
          <span class="node">Nutrients RELEASED back for reuse by autotrophs</span><span class="arr">→</span>
          <span class="node">Repeat, over and over again</span>
        </div>

        <div class="callout"><b>The one-sentence truth of the whole chapter:</b> There is <b>UNIDIRECTIONAL movement of ENERGY</b> towards the higher trophic levels, and its <b>dissipation and loss as HEAT</b> to the environment.<br><br>
        Compare: <b>NUTRIENTS CYCLE</b> (they are reused again and again). <b>ENERGY DOES NOT CYCLE</b> (it flows one way and is lost as heat).</div>
      `
    },

    {
      id: "e3_productivity",
      heading: "3. Productivity — GPP, NPP & Secondary Productivity",
      html: `
        <p>A <b>constant input of solar energy</b> is the basic requirement for any ecosystem to function and sustain.</p>

        <h4>Production vs Productivity — the distinction NCERT tests</h4>
        <table class="cmp">
          <thead><tr><th>Term</th><th>Definition</th><th>Units</th></tr></thead>
          <tbody>
            <tr>
              <td><b>Primary PRODUCTION</b></td>
              <td>The <b>AMOUNT</b> of biomass or organic matter produced <b>per unit area over a time period</b> by plants during photosynthesis</td>
              <td>Weight: <b>g m<sup>&minus;2</sup></b><br>Energy: <b>kcal m<sup>&minus;2</sup></b></td>
            </tr>
            <tr>
              <td><b>PRODUCTIVITY</b></td>
              <td>The <b>RATE</b> of biomass production</td>
              <td><b>g m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b><br>or <b>kcal m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b><br><i>(used to COMPARE different ecosystems)</i></td>
            </tr>
          </tbody>
        </table>

        <h4>The three productivities</h4>
        <table class="cmp">
          <thead><tr><th>Type</th><th>Definition</th></tr></thead>
          <tbody>
            <tr>
              <td><b>Gross Primary Productivity (GPP)</b></td>
              <td>The <b>rate of production of organic matter during photosynthesis</b>. A considerable amount of GPP is <b>utilised by plants in respiration</b>.</td>
            </tr>
            <tr>
              <td><b>Net Primary Productivity (NPP)</b></td>
              <td><b>GPP minus respiration losses (R)</b>. This is the <b>biomass AVAILABLE for consumption by heterotrophs</b> — i.e., <b>herbivores AND decomposers</b>.</td>
            </tr>
            <tr>
              <td><b>Secondary Productivity</b></td>
              <td>The <b>rate of formation of new organic matter by CONSUMERS</b>.</td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>THE FORMULA:</b> &nbsp; <b>GPP &minus; R = NPP</b><br><br>
        <b>Think of it like income:</b> GPP = what you EARN. R = what you SPEND on staying alive. NPP = what you actually KEEP (and what everyone else in the ecosystem gets to eat).</div>

        <h4>What primary productivity depends on</h4>
        <ul>
          <li>The <b>plant species</b> inhabiting the particular area</li>
          <li><b>Environmental factors</b></li>
          <li><b>Availability of nutrients</b></li>
          <li><b>Photosynthetic capacity of plants</b></li>
        </ul>
        <p>Because of these, <b>productivity varies in different types of ecosystems</b>.</p>

        <h4>Global numbers (learn these cold)</h4>
        <table class="cmp">
          <thead><tr><th>Quantity</th><th>Value</th></tr></thead>
          <tbody>
            <tr><td>Annual NPP of the <b>whole biosphere</b></td><td><b>~170 billion tons</b> (dry weight) of organic matter</td></tr>
            <tr><td>Annual NPP of the <b>oceans</b></td><td><b>only 55 billion tons</b></td></tr>
            <tr><td>Annual NPP of <b>land</b></td><td>The rest — <b>~115 billion tons</b></td></tr>
            <tr><td>Fraction of Earth's surface covered by oceans</td><td><b>~70 per cent</b></td></tr>
          </tbody>
        </table>

        <div class="callout"><b>The paradox NCERT asks you to explain:</b> Oceans occupy <b>~70% of the surface</b> yet contribute <b>only ~32% of global NPP</b>. Why so low?<br><br>
        <b>Because LIGHT is the limiting factor in aquatic ecosystems.</b> Sunlight penetrates only the thin upper (photic) layer, so photosynthesis is confined to a shallow film of water. Nutrient scarcity in open ocean surface waters compounds it.<br><br>
        <i>(This is also NCERT Exercise 1(c): "In aquatic ecosystems, the limiting factor for the productivity is <b>LIGHT</b>.")</i></div>
      `
    },

    {
      id: "e4_decomposition",
      heading: "4. Decomposition — The Five Steps",
      html: `
        <p>The <b>earthworm</b> is called the <b>farmer's 'friend'</b> because it helps in the <b>breakdown of complex organic matter</b> and in the <b>loosening of the soil</b>.</p>

        <div class="callout"><b>Decomposition:</b> the process by which <b>decomposers break down complex organic matter into inorganic substances</b> like <b>carbon dioxide, water and nutrients</b>.</div>

        <h4>Detritus — the raw material</h4>
        <p><span class="kw">Detritus</span> = <b>dead plant remains</b> (leaves, bark, flowers) + <b>dead remains of animals, INCLUDING faecal matter</b>. This is the <b>raw material for decomposition</b>.</p>

        <h4>The five steps (they all operate SIMULTANEOUSLY)</h4>
        <div class="flow">
          <span class="node">DETRITUS</span><span class="arr">→</span>
          <span class="node">1. Fragmentation</span><span class="arr">→</span>
          <span class="node">2. Leaching</span><span class="arr">→</span>
          <span class="node">3. Catabolism</span><span class="arr">→</span>
          <span class="node">4. Humification</span><span class="arr">→</span>
          <span class="node">5. Mineralisation</span><span class="arr">→</span>
          <span class="node">INORGANIC NUTRIENTS</span>
        </div>

        <table class="cmp">
          <thead><tr><th>Step</th><th>What happens</th><th>Who does it</th></tr></thead>
          <tbody>
            <tr>
              <td><b>1. Fragmentation</b></td>
              <td><b>Detritus is broken down into smaller particles</b></td>
              <td><b>Detritivores</b> — e.g., the <b>earthworm</b></td>
            </tr>
            <tr>
              <td><b>2. Leaching</b></td>
              <td><b>Water-soluble inorganic nutrients go DOWN into the soil horizon</b> and get <b>precipitated as UNAVAILABLE salts</b></td>
              <td>Water (physical process)</td>
            </tr>
            <tr>
              <td><b>3. Catabolism</b></td>
              <td><b>Detritus is degraded into simpler inorganic substances</b></td>
              <td><b>Bacterial and fungal ENZYMES</b></td>
            </tr>
            <tr>
              <td><b>4. Humification</b></td>
              <td>Leads to the accumulation of <b>HUMUS</b> — a <b>dark-coloured amorphous substance</b></td>
              <td>Occurs <b>in the soil</b></td>
            </tr>
            <tr>
              <td><b>5. Mineralisation</b></td>
              <td>Humus is <b>further degraded</b> and <b>inorganic nutrients are RELEASED</b></td>
              <td><b>Some microbes</b>; occurs <b>in the soil</b></td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>HUMUS — three properties NCERT wants:</b><br>
          1. <b>Dark-coloured and amorphous</b><br>
          2. <b>Highly resistant to microbial action</b>; decomposes at an <b>extremely slow rate</b><br>
          3. <b>Colloidal in nature</b> → serves as a <b>RESERVOIR OF NUTRIENTS</b></div>

        <div class="callout"><b>Trap alert:</b> The <b>SUMMARY</b> of the NCERT chapter says decomposition involves <b>THREE</b> processes (fragmentation, leaching, catabolism), while the <b>MAIN TEXT</b> lists <b>FIVE</b> (adding humification and mineralisation). Both appear in exams. The <b>five-step version is the complete and correct one</b>; humification and mineralisation are the two that occur <b>in the soil</b>.</div>

        <h4>Rate of decomposition — what controls it</h4>
        <p>Decomposition is <b>largely an OXYGEN-REQUIRING (aerobic) process</b>. Its rate is controlled by <b>(a) the chemical composition of the detritus</b> and <b>(b) climatic factors</b>.</p>

        <table class="cmp">
          <thead><tr><th>Factor</th><th>SLOWS decomposition</th><th>SPEEDS UP decomposition</th></tr></thead>
          <tbody>
            <tr>
              <td><b>Chemical composition of detritus</b></td>
              <td>Rich in <b>LIGNIN and CHITIN</b></td>
              <td>Rich in <b>NITROGEN</b> and <b>water-soluble substances like SUGARS</b></td>
            </tr>
            <tr>
              <td><b>Climate</b></td>
              <td><b>Low temperature</b> and <b>anaerobiosis</b> → inhibit decomposition → <b>BUILD-UP of organic materials</b></td>
              <td><b>Warm and moist</b> environment</td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>The two most important climatic factors</b> regulating decomposition are <b>TEMPERATURE and SOIL MOISTURE</b> — through their effects on the <b>activities of soil microbes</b>.</div>
      `
    },

    {
      id: "e5_energyflow",
      heading: "5. Energy Flow — Sun → PAR → Producers",
      html: `
        <div class="callout"><b>Except for the deep-sea hydro-thermal ecosystem, the SUN is the ONLY source of energy for all ecosystems on Earth.</b> (The hydrothermal exception is the single most-tested one-liner in this section.)</div>

        <h4>The energy cascade — four numbers you MUST know</h4>
        <div class="flow">
          <span class="node">Incident solar radiation</span><span class="arr">→</span>
          <span class="node">&lt; 50% is PAR</span><span class="arr">→</span>
          <span class="node">Plants capture only 2&ndash;10% of the PAR</span><span class="arr">→</span>
          <span class="node">~1% of available sunlight ends up as NPP</span><span class="arr">→</span>
          <span class="node">10% transferred per trophic level</span>
        </div>

        <table class="cmp">
          <thead><tr><th>Number</th><th>What it refers to</th></tr></thead>
          <tbody>
            <tr><td><b>Less than 50%</b></td><td>of the <b>incident solar radiation</b> is <b>Photosynthetically Active Radiation (PAR)</b></td></tr>
            <tr><td><b>2&ndash;10%</b></td><td>of the <b>PAR</b> is captured by plants — <b>and this small amount sustains the entire living world</b></td></tr>
            <tr><td><b>~1%</b></td><td>In an <b>ideal pyramid of energy</b>, primary producers convert only <b>1% of the energy in the sunlight available to them</b> into NPP</td></tr>
            <tr><td><b>10%</b></td><td>The <b>10 per cent law</b> — only 10% of energy is transferred to each trophic level from the lower trophic level</td></tr>
          </tbody>
        </table>

        <div class="callout"><b>THE CLASSIC NEET TRAP:</b><br>
          Q: "What is the percentage of PAR in the incident solar radiation?" → <b>50%</b> (i.e., less than 50%).<br>
          Q: "What percentage of PAR do plants capture?" → <b>2&ndash;10%</b>.<br><br>
          Students swap these two constantly. <b>50 is about PAR; 2&ndash;10 is about capture.</b></div>

        <h4>Thermodynamics of an ecosystem</h4>
        <table class="cmp">
          <thead><tr><th>Law</th><th>How the ecosystem obeys it</th></tr></thead>
          <tbody>
            <tr><td><b>First Law</b></td><td>Energy is neither created nor destroyed — the sun's energy is <b>converted</b> (fixed by autotrophs into food), not made. Flow is <b>unidirectional: sun → producers → consumers</b>.</td></tr>
            <tr><td><b>Second Law</b></td><td>Ecosystems are <b>not exempt</b>. They need a <b>constant supply of energy</b> to synthesise the molecules they require, in order to <b>counteract the universal tendency toward increasing disorderliness (entropy)</b>.</td></tr>
          </tbody>
        </table>

        <h4>Producers</h4>
        <table class="cmp">
          <thead><tr><th>Ecosystem</th><th>Major producers</th></tr></thead>
          <tbody>
            <tr><td><b>Terrestrial</b></td><td><b>Herbaceous and woody plants</b></td></tr>
            <tr><td><b>Aquatic</b></td><td><b>Phytoplankton, algae and higher plants</b></td></tr>
          </tbody>
        </table>

        <div class="callout"><b>Key line:</b> "No energy that is trapped into an organism remains in it forever." The energy trapped by the producer is <b>either passed on to a consumer, or the organism dies</b>. <b>Death of an organism is the BEGINNING of the detritus food chain/web.</b></div>
      `
    },

    {
      id: "e6_foodchains",
      heading: "6. Food Chains, Food Webs & Trophic Levels",
      html: `
        <h4>Consumers</h4>
        <p>All animals depend on plants directly or indirectly for their food — they are <b>consumers</b>, also called <b>heterotrophs</b>.</p>
        <table class="cmp">
          <thead><tr><th>Level</th><th>Name</th><th>Also called</th><th>Examples</th></tr></thead>
          <tbody>
            <tr><td>Feed on producers</td><td><b>Primary consumers</b></td><td><b>Herbivores</b></td><td><b>Terrestrial:</b> insects, birds, mammals<br><b>Aquatic:</b> <b>molluscs</b></td></tr>
            <tr><td>Feed on herbivores</td><td><b>Secondary consumers</b></td><td><b>Primary carnivores</b></td><td>Frog, small fish</td></tr>
            <tr><td>Feed on primary carnivores</td><td><b>Tertiary consumers</b></td><td><b>Secondary carnivores</b></td><td>Snake, hawk</td></tr>
          </tbody>
        </table>

        <h4>Grazing Food Chain (GFC) — NCERT's exact example</h4>
        <div class="flow">
          <span class="node">Grass<br>(Producer)</span><span class="arr">→</span>
          <span class="node">Goat<br>(Primary Consumer)</span><span class="arr">→</span>
          <span class="node">Man<br>(Secondary Consumer)</span>
        </div>

        <h4>Detritus Food Chain (DFC)</h4>
        <ul>
          <li><b>Begins with DEAD ORGANIC MATTER.</b></li>
          <li>Made up of <b>decomposers</b> — <b>heterotrophic organisms, mainly FUNGI and BACTERIA</b>.</li>
          <li>They meet their energy and nutrient requirements by <b>degrading dead organic matter (detritus)</b>.</li>
          <li>Also known as <span class="kw">SAPROTROPHS</span> (<b>sapro = to decompose</b>).</li>
          <li>They <b>secrete digestive enzymes</b> that break down dead and waste materials into <b>simple inorganic materials, which are subsequently ABSORBED by them</b>.</li>
        </ul>

        <h4>GFC vs DFC — HIGH-YIELD comparison</h4>
        <table class="cmp">
          <thead><tr><th>Feature</th><th>Grazing Food Chain (GFC)</th><th>Detritus Food Chain (DFC)</th></tr></thead>
          <tbody>
            <tr><td>Starts with</td><td><b>Living producers</b> (plants)</td><td><b>Dead organic matter</b> (detritus)</td></tr>
            <tr><td>Energy source</td><td><b>Sun</b> (directly)</td><td><b>Detritus</b></td></tr>
            <tr><td>Main organisms</td><td>Herbivores → carnivores</td><td><b>Decomposers / saprotrophs</b> (fungi, bacteria)</td></tr>
            <tr><td><b>Dominant in AQUATIC ecosystems</b></td><td><b>YES — GFC is the major conduit for energy flow</b></td><td>Minor</td></tr>
            <tr><td><b>Dominant in TERRESTRIAL ecosystems</b></td><td>Minor</td><td><b>YES — a much larger fraction of energy flows through the DFC</b></td></tr>
            <tr><td>Trophic levels</td><td><b>Restricted</b> (by the 10% law)</td><td>Not similarly restricted</td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Memory hook: "Water grazes, Land rots."</b> Aquatic → GFC dominates. Terrestrial → DFC dominates.</div>

        <h4>Food web</h4>
        <p>The DFC <b>may be connected with the GFC at some levels</b>: some organisms of the DFC are <b>prey to GFC animals</b>, and in a natural ecosystem some animals — like <b>cockroaches and crows</b> — are <b>omnivores</b>. These <b>natural interconnections of food chains make it a FOOD WEB</b>.</p>
        <table class="cmp">
          <thead><tr><th>Food Chain</th><th>Food Web</th></tr></thead>
          <tbody>
            <tr><td>A <b>single, linear</b> sequence of who-eats-whom</td><td><b>Many interconnected</b> food chains</td></tr>
            <tr><td>An organism occupies <b>one</b> position</td><td>An organism may occupy <b>several</b> positions</td></tr>
            <tr><td>Almost <b>never exists</b> in nature in pure form</td><td>What <b>actually exists</b> in nature</td></tr>
          </tbody>
        </table>

        <h4>Trophic levels</h4>
        <p>Based on the <b>source of their nutrition or food</b>, organisms occupy a specific place in the food chain known as their <span class="kw">trophic level</span>.</p>
        <table class="cmp">
          <thead><tr><th>Trophic Level</th><th>Occupant</th></tr></thead>
          <tbody>
            <tr><td><b>First (T1)</b></td><td><b>Producers</b></td></tr>
            <tr><td><b>Second (T2)</b></td><td><b>Herbivores</b> (primary consumers)</td></tr>
            <tr><td><b>Third (T3)</b></td><td><b>Carnivores</b> (secondary consumers)</td></tr>
            <tr><td><b>Fourth (T4)</b></td><td><b>Secondary carnivores</b> (tertiary consumers)</td></tr>
          </tbody>
        </table>

        <div class="callout"><b>CRITICAL CONCEPT:</b> A <b>trophic level represents a FUNCTIONAL LEVEL, NOT a species.</b> <b>A given species may occupy more than one trophic level in the SAME ecosystem at the SAME time.</b><br><br>
        <b>NCERT's example:</b> A <b>sparrow</b> is a <b>primary consumer</b> when it eats <b>seeds, fruits and peas</b>, and a <b>secondary consumer</b> when it eats <b>insects and worms</b>.</div>

        <h4>Standing crop</h4>
        <p>Each trophic level has a certain <b>mass of living material at a particular time</b> — its <span class="kw">standing crop</span>.</p>
        <ul>
          <li>Measured as the <b>mass of living organisms (biomass)</b> or the <b>number in a unit area</b>.</li>
          <li>Biomass of a species is expressed in <b>fresh or dry weight</b>.</li>
          <li><b>Measurement in DRY WEIGHT is MORE ACCURATE</b> — because <b>fresh weight varies with water content</b>, which fluctuates with hydration, humidity and species, and water contributes no organic matter or energy.</li>
        </ul>

        <h4>The 10 per cent law</h4>
        <div class="callout"><b>Only 10 per cent of the energy is transferred to each trophic level from the lower trophic level.</b><br><br>
        Consequence: <b>the number of trophic levels in the grazing food chain is RESTRICTED</b> — there simply isn't enough energy left to support a fifth or sixth level. The <b>amount of energy DECREASES at successive trophic levels</b>, and organisms at each level <b>depend on those at the lower level</b> for their energy demands.<br><br>
        <b>Worked example:</b> 10,000 J at producers → 1,000 J at herbivores → 100 J at primary carnivores → 10 J at secondary carnivores.</div>

        <p>When any organism dies it is converted to <b>detritus or dead biomass</b>, which serves as an <b>energy source for decomposers</b>.</p>
      `
    },

    {
      id: "e7_pyramids",
      heading: "7. Ecological Pyramids — Number, Biomass & Energy",
      html: `
        <p>An <span class="kw">ecological pyramid</span> expresses the food or energy relationship between organisms at different trophic levels, in terms of <b>number, biomass or energy</b>.</p>
        <ul>
          <li>The <b>BASE</b> of each pyramid represents the <b>producers (first trophic level)</b>.</li>
          <li>The <b>APEX</b> represents the <b>tertiary or top-level consumer</b>.</li>
        </ul>

        <h4>The three types</h4>
        <table class="cmp">
          <thead><tr><th>Pyramid</th><th>What each bar shows</th><th>Can it be inverted?</th><th>NCERT's example</th></tr></thead>
          <tbody>
            <tr>
              <td><b>Pyramid of NUMBERS</b></td>
              <td>Number of individuals at each trophic level</td>
              <td><b>YES</b> — in a <b>TREE ecosystem</b></td>
              <td><b>Grassland:</b> nearly <b>6 million plants</b> support only <b>3 top carnivores</b> (upright)</td>
            </tr>
            <tr>
              <td><b>Pyramid of BIOMASS</b></td>
              <td>Standing crop (mass of living material) at each level</td>
              <td><b>YES</b> — in the <b>SEA</b></td>
              <td><b>Inverted in the sea:</b> a <b>small standing crop of phytoplankton supports a large standing crop of zooplankton</b> / the <b>biomass of fishes far exceeds that of phytoplankton</b></td>
            </tr>
            <tr>
              <td><b>Pyramid of ENERGY</b></td>
              <td>Amount of energy present at each trophic level in a given time or annually per unit area</td>
              <td><b>NEVER. ALWAYS UPRIGHT.</b></td>
              <td><b>Ideal energy pyramid:</b> primary producers convert only <b>1%</b> of the sunlight available to them into NPP</td>
            </tr>
          </tbody>
        </table>

        <div class="callout"><b>WHY the pyramid of energy can NEVER be inverted:</b><br>
        Because when energy flows from a particular trophic level to the next, <b>some energy is ALWAYS lost as HEAT at each step</b>. Energy at a lower trophic level is therefore <b>always more</b> than at a higher level. There is no physical way around it.</div>

        <div class="callout"><b>The sea-biomass PARADOX, resolved:</b> How can a <b>small</b> phytoplankton biomass feed a <b>large</b> zooplankton/fish biomass?<br><br>
        Because <b>biomass is a STANDING CROP — a snapshot at one instant, not a rate.</b> Phytoplankton have an <b>extremely high turnover rate</b>: they reproduce and are eaten within hours to days. Over a year they PRODUCE an enormous amount of biomass, but at any given moment very little of it is standing around. The long-lived fish accumulate their biomass and hold it. <b>Energy still flows correctly downhill</b> — which is exactly why the <b>energy</b> pyramid stays upright even when the <b>biomass</b> pyramid flips.</div>

        <h4>The exceptions — memorise these three lines</h4>
        <div class="flow">
          <span class="node">TREE flips NUMBERS</span><span class="arr">|</span>
          <span class="node">SEA flips BIOMASS</span><span class="arr">|</span>
          <span class="node">NOTHING flips ENERGY</span>
        </div>
        <p>In <b>most</b> ecosystems all three pyramids are <b>upright</b>: producers are more in number and biomass than herbivores, and herbivores more than carnivores; and energy at a lower trophic level is always more than at a higher level.</p>

        <h4>Rules for constructing pyramids</h4>
        <ul>
          <li>Any calculation of energy content, biomass or numbers <b>must include ALL organisms at that trophic level</b>. No generalisation is true if only a few individuals are counted.</li>
          <li>A given organism <b>may occupy more than one trophic level simultaneously</b> — the trophic level is a <b>functional level, not a species</b>.</li>
        </ul>

        <h4>LIMITATIONS of ecological pyramids (the three S's)</h4>
        <table class="cmp">
          <thead><tr><th>Limitation</th><th>Why it matters</th></tr></thead>
          <tbody>
            <tr><td><b>Same species, two levels</b></td><td>It <b>does not take into account the same species belonging to two or more trophic levels</b> (e.g., the sparrow).</td></tr>
            <tr><td><b>Simple chain assumed</b></td><td>It <b>assumes a simple food chain</b> — something that <b>almost never exists in nature</b>. It <b>does not accommodate a food web</b>.</td></tr>
            <tr><td><b>Saprophytes skipped</b></td><td><b>Saprophytes are not given any place</b> in ecological pyramids, even though they play a <b>vital role</b> in the ecosystem.</td></tr>
          </tbody>
        </table>
      `
    },

    {
      id: "e8_nutrientcycling",
      heading: "8. Nutrient Cycling & Ecosystem Services (Summary-level only)",
      html: `
        <div class="callout"><b>Read this first:</b> The rationalised 2023-24 chapter <b>deleted</b> the full sections on nutrient cycling (carbon cycle, phosphorus cycle diagrams) and ecosystem services. What is written below is <b>everything that still survives</b>, in the chapter's SUMMARY and EXERCISES. Learn exactly this much — no more.</div>

        <h4>Nutrient cycling</h4>
        <p><span class="kw">Nutrient cycling</span> is the <b>storage and movement of nutrient elements through the various components of the ecosystem</b>. Through this process, <b>nutrients are used repeatedly</b>.</p>

        <table class="cmp">
          <thead><tr><th>Type of cycle</th><th>Reservoir</th><th>NCERT's example element</th></tr></thead>
          <tbody>
            <tr><td><b>GASEOUS</b></td><td><b>Atmosphere or Hydrosphere</b></td><td><b>Carbon</b></td></tr>
            <tr><td><b>SEDIMENTARY</b></td><td><b>Earth's crust</b></td><td><b>Phosphorus</b></td></tr>
          </tbody>
        </table>
        <div class="callout"><b>Mnemonic: "Carbon flies, Phosphorus lies."</b> Carbon is in the air (gaseous); phosphorus lies in the rocks (sedimentary).</div>

        <div class="callout"><b>Exercise 1(e):</b> "The major reservoir of carbon on earth is ______" → <b>OCEANS</b>. (Roughly 71% of Earth's carbon is dissolved in the oceans, which act as a huge sink regulating atmospheric CO<sub>2</sub>.)</div>

        <h4>The energy/nutrient contrast — the single most examined idea in this chapter</h4>
        <table class="cmp">
          <thead><tr><th>Feature</th><th>ENERGY</th><th>NUTRIENTS</th></tr></thead>
          <tbody>
            <tr><td>Path</td><td><b>UNIDIRECTIONAL (flows)</b></td><td><b>CYCLIC (cycles)</b></td></tr>
            <tr><td>Fate</td><td><b>Lost as HEAT</b> at every step</td><td><b>Reused repeatedly</b></td></tr>
            <tr><td>Source</td><td><b>Must be constantly resupplied by the sun</b></td><td>Drawn from a <b>reservoir</b> (atmosphere/hydrosphere or Earth's crust)</td></tr>
            <tr><td>Can it be recycled?</td><td><b>NO</b></td><td><b>YES</b></td></tr>
          </tbody>
        </table>

        <h4>Ecosystem services</h4>
        <p><span class="kw">Ecosystem services</span> = the <b>products of ecosystem processes</b>.<br>
        <b>NCERT's example:</b> the <b>purification of air and water by forests</b>.</p>
      `
    },

    {
      id: "e9_cheatsheet",
      heading: "9. Cheat Sheet — Every Number, Formula, Distinction & Exercise Answer",
      html: `
        <h4>Formula & number bank</h4>
        <table class="cmp">
          <thead><tr><th>Item</th><th>Value / Formula</th></tr></thead>
          <tbody>
            <tr><td>Net primary productivity</td><td><b>NPP = GPP &minus; R</b></td></tr>
            <tr><td>Units of primary PRODUCTION</td><td><b>g m<sup>&minus;2</sup></b> or <b>kcal m<sup>&minus;2</sup></b></td></tr>
            <tr><td>Units of PRODUCTIVITY</td><td><b>g m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b> or <b>kcal m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b></td></tr>
            <tr><td>PAR in incident solar radiation</td><td><b>less than 50%</b></td></tr>
            <tr><td>PAR captured by plants</td><td><b>2&ndash;10%</b></td></tr>
            <tr><td>Sunlight converted to NPP (ideal energy pyramid)</td><td><b>~1%</b></td></tr>
            <tr><td>Energy transfer between trophic levels</td><td><b>10% law</b></td></tr>
            <tr><td>Annual NPP of the biosphere</td><td><b>~170 billion tons</b> (dry weight)</td></tr>
            <tr><td>Annual NPP of the oceans</td><td><b>55 billion tons</b></td></tr>
            <tr><td>Ocean share of Earth's surface</td><td><b>~70%</b></td></tr>
            <tr><td>Grassland pyramid of numbers</td><td><b>~6 million plants</b> support <b>3 top carnivores</b></td></tr>
          </tbody>
        </table>

        <h4>The six NCERT "Distinguish between" pairs (Exercise 6)</h4>
        <table class="cmp">
          <thead><tr><th>Pair</th><th>The key line</th></tr></thead>
          <tbody>
            <tr><td><b>(a) GFC vs DFC</b></td><td>GFC starts with <b>living producers</b> and dominates <b>AQUATIC</b> ecosystems; DFC starts with <b>dead organic matter</b> and dominates <b>TERRESTRIAL</b> ecosystems.</td></tr>
            <tr><td><b>(b) Production vs Decomposition</b></td><td>Production <b>BUILDS</b> complex organic matter from inorganic (photosynthesis, needs sunlight); Decomposition <b>BREAKS DOWN</b> complex organic matter into inorganic (needs oxygen, done by decomposers).</td></tr>
            <tr><td><b>(c) Upright vs Inverted pyramid</b></td><td>Upright: base (producers) is the <b>largest</b>, narrowing to the apex. Inverted: base is <b>smaller</b> than the levels above (tree → numbers; sea → biomass).</td></tr>
            <tr><td><b>(d) Food chain vs Food web</b></td><td>Food chain = a <b>single linear</b> sequence; food web = <b>many interconnected</b> food chains. Only the web actually exists in nature.</td></tr>
            <tr><td><b>(e) Litter vs Detritus</b></td><td><b>Litter</b> = the surface layer of <b>dead PLANT material</b> (fallen leaves, twigs, bark) lying on the soil. <b>Detritus</b> is <b>broader</b> — <b>all</b> dead organic matter: dead plant remains <b>AND</b> dead animal remains <b>AND faecal matter</b>. Litter is one part of detritus.</td></tr>
            <tr><td><b>(f) Primary vs Secondary productivity</b></td><td>Primary = rate of biomass production by <b>PRODUCERS</b> (photosynthesis). Secondary = rate of formation of new organic matter by <b>CONSUMERS</b>.</td></tr>
          </tbody>
        </table>

        <h4>Exercise answer key (fill-in-the-blanks &amp; MCQs)</h4>
        <table class="cmp">
          <thead><tr><th>Question</th><th>Answer</th></tr></thead>
          <tbody>
            <tr><td>1(a) Plants are called ___ because they fix carbon dioxide</td><td><b>Producers / Autotrophs</b></td></tr>
            <tr><td>1(b) In an ecosystem dominated by trees, the pyramid of numbers is ___ type</td><td><b>INVERTED</b></td></tr>
            <tr><td>1(c) In aquatic ecosystems, the limiting factor for productivity is ___</td><td><b>LIGHT</b></td></tr>
            <tr><td>1(d) Common detritivores in our ecosystem are ___</td><td><b>Earthworms</b></td></tr>
            <tr><td>1(e) The major reservoir of carbon on earth is ___</td><td><b>OCEANS</b></td></tr>
            <tr><td>2. Largest population in a food chain</td><td><b>Producers</b></td></tr>
            <tr><td>3. The second trophic level in a lake</td><td><b>Zooplankton</b> (phytoplankton are the FIRST)</td></tr>
            <tr><td>4. Secondary producers are</td><td><b>Herbivores</b> — they are the first consumers, and secondary productivity is the rate of new organic matter formed by consumers</td></tr>
            <tr><td>5. Percentage of PAR in incident solar radiation</td><td><b>50%</b> (option (d) "2&ndash;10%" is the trap — that's the fraction of PAR CAPTURED)</td></tr>
          </tbody>
        </table>

        <h4>The "always/never" list</h4>
        <ul>
          <li>Energy flow is <b>ALWAYS unidirectional</b>.</li>
          <li>The pyramid of energy is <b>ALWAYS upright — it can NEVER be inverted</b>.</li>
          <li>Energy at a lower trophic level is <b>ALWAYS more</b> than at a higher level.</li>
          <li>The sun is the <b>ONLY</b> energy source for all ecosystems — <b>except</b> the deep-sea hydrothermal ecosystem.</li>
          <li>All five decomposition steps operate <b>SIMULTANEOUSLY</b> on the detritus.</li>
          <li>Dry weight is <b>ALWAYS more accurate</b> than fresh weight for measuring biomass.</li>
        </ul>
      `
    }
  ],

  /* ---------- 3. MNEMONICS (15) ---------- */
  mnemonics: [
    {
      title: "The Four Functional Components — 'PDEN'",
      device: `<b>P</b>roductivity → <b>D</b>ecomposition → <b>E</b>nergy flow → <b>N</b>utrient cycling`,
      expand: [
        { L: "P", t: "Productivity — the INPUT. GPP, NPP, secondary productivity." },
        { L: "D", t: "Decomposition — breakdown of detritus back to inorganic nutrients." },
        { L: "E", t: "Energy flow — unidirectional, lost as heat, 10% law." },
        { L: "N", t: "Nutrient cycling — CYCLIC, nutrients reused repeatedly." },
        { L: "★", t: "Frame: INPUT (productivity) → TRANSFER (food web + nutrient cycling) → OUTPUT (degradation + energy loss)." }
      ]
    },
    {
      title: "Decomposition Steps — 'Fresh Leaves Cook, Humus Made'",
      device: `<b>F</b>ragmentation → <b>L</b>eaching → <b>C</b>atabolism → <b>H</b>umification → <b>M</b>ineralisation`,
      expand: [
        { L: "F", t: "Fragmentation — DETRITIVORES (earthworm) break detritus into smaller particles." },
        { L: "L", t: "Leaching — water-soluble nutrients go DOWN the soil horizon and precipitate as UNAVAILABLE salts." },
        { L: "C", t: "Catabolism — BACTERIAL and FUNGAL ENZYMES degrade detritus into simpler inorganic substances." },
        { L: "H", t: "Humification — accumulation of HUMUS: dark, amorphous, resistant, colloidal, a nutrient reservoir. Happens IN THE SOIL." },
        { L: "M", t: "Mineralisation — microbes further degrade humus, RELEASING inorganic nutrients. Happens IN THE SOIL." },
        { L: "★", t: "ALL FIVE STEPS OPERATE SIMULTANEOUSLY on the detritus — not one after another." }
      ]
    },
    {
      title: "GPP − R = NPP — 'Earn minus Spend equals Keep'",
      device: `<b>GPP</b> (what you earn) &minus; <b>R</b> (what respiration spends) = <b>NPP</b> (what everyone else gets to eat)`,
      expand: [
        { L: "GPP", t: "Gross Primary Productivity — the rate of production of organic matter during photosynthesis." },
        { L: "R", t: "Respiration losses — a considerable amount of GPP is burned by the plant itself." },
        { L: "NPP", t: "Net Primary Productivity — the biomass AVAILABLE for consumption by heterotrophs (herbivores AND decomposers)." },
        { L: "2°", t: "Secondary productivity = the rate of formation of new organic matter by CONSUMERS." }
      ]
    },
    {
      title: "The Energy Cascade — '50 → 10 → 1 → 10'",
      device: `<b>Half arrives</b> (PAR) · <b>a tenth is grabbed</b> (capture) · <b>one percent is banked</b> (NPP) · <b>a tenth moves up</b> (10% law)`,
      expand: [
        { L: "<50%", t: "Less than 50% of the INCIDENT SOLAR RADIATION is PAR (photosynthetically active radiation)." },
        { L: "2–10%", t: "Plants capture only 2–10% OF THE PAR — and this tiny fraction sustains the ENTIRE living world." },
        { L: "~1%", t: "In an ideal energy pyramid, producers convert only ~1% of the available sunlight into NPP." },
        { L: "10%", t: "The 10 PER CENT LAW — only 10% of energy passes to the next trophic level." },
        { L: "⚠", t: "TRAP: 'PAR in incident radiation' = 50%. 'PAR captured by plants' = 2–10%. Do not swap them." }
      ]
    },
    {
      title: "Pyramid Inversions — 'Tree flips Numbers, Sea flips Biomass, Nothing flips Energy'",
      device: `Numbers can invert (a big <b>TREE</b>) · Biomass can invert (the <b>SEA</b>) · <b>ENERGY NEVER INVERTS</b>`,
      expand: [
        { L: "N", t: "PYRAMID OF NUMBERS — inverted in a TREE ecosystem: one tree supports thousands of insects, which support fewer birds." },
        { L: "B", t: "PYRAMID OF BIOMASS — inverted in the SEA: a small standing crop of phytoplankton supports a large standing crop of zooplankton/fish." },
        { L: "E", t: "PYRAMID OF ENERGY — ALWAYS UPRIGHT, CAN NEVER BE INVERTED, because energy is always lost as HEAT at every step." },
        { L: "★", t: "In MOST ecosystems, all three are upright. The two inversions above are the only NCERT exceptions." }
      ]
    },
    {
      title: "Decomposition Rate — 'LC slows, NS speeds'",
      device: `<b>L</b>ignin + <b>C</b>hitin = <b>sLow</b> &nbsp;|&nbsp; <b>N</b>itrogen + <b>S</b>ugars = <b>Speedy</b>`,
      expand: [
        { L: "SLOW", t: "Detritus rich in LIGNIN and CHITIN decomposes slowly." },
        { L: "FAST", t: "Detritus rich in NITROGEN and water-soluble substances like SUGARS decomposes quickly." },
        { L: "T & M", t: "TEMPERATURE and SOIL MOISTURE are the two most important CLIMATIC factors — they act via soil microbe activity." },
        { L: "🔥💧", t: "WARM + MOIST → favours decomposition. LOW TEMPERATURE + ANAEROBIOSIS → inhibits it → build-up of organic material." },
        { L: "O₂", t: "Decomposition is largely an OXYGEN-REQUIRING process." }
      ]
    },
    {
      title: "Where Each Chain Rules — 'Water grazes, Land rots'",
      device: `<b>AQUATIC</b> → the <b>GFC</b> is the major conduit &nbsp;|&nbsp; <b>TERRESTRIAL</b> → a much larger fraction flows through the <b>DFC</b>`,
      expand: [
        { L: "💧", t: "AQUATIC ecosystem: the GRAZING food chain is the major conduit for energy flow." },
        { L: "🌱", t: "TERRESTRIAL ecosystem: a much larger fraction of energy flows through the DETRITUS food chain than through the GFC." },
        { L: "🔗", t: "The two are CONNECTED — some DFC organisms are prey to GFC animals, and omnivores like COCKROACHES and CROWS link them. That is what makes a FOOD WEB." }
      ]
    },
    {
      title: "The Pond, Component by Component — 'A-A-C-D'",
      device: `<b>A</b>biotic → <b>A</b>utotrophs → <b>C</b>onsumers → <b>D</b>ecomposers`,
      expand: [
        { L: "A", t: "ABIOTIC — the water with dissolved inorganic AND organic substances, plus the rich soil deposit at the BOTTOM." },
        { L: "A", t: "AUTOTROPHS — phytoplankton, some algae, and the floating/submerged/marginal plants at the edges." },
        { L: "C", t: "CONSUMERS — zooplankton, free-swimming forms, and bottom-dwelling forms." },
        { L: "D", t: "DECOMPOSERS — fungi, bacteria and FLAGELLATES, especially abundant at the BOTTOM of the pond." },
        { L: "☀", t: "REGULATORS — solar input, temperature cycle, day-length and other climatic conditions set the pond's rate of function." }
      ]
    },
    {
      title: "Nutrient Cycle Types — 'Carbon flies, Phosphorus lies'",
      device: `<b>GASEOUS</b> cycle (Carbon) → reservoir = <b>atmosphere / hydrosphere</b> &nbsp;|&nbsp; <b>SEDIMENTARY</b> cycle (Phosphorus) → reservoir = <b>Earth's crust</b>`,
      expand: [
        { L: "C", t: "CARBON — gaseous cycle. It FLIES: reservoir is the atmosphere or hydrosphere." },
        { L: "P", t: "PHOSPHORUS — sedimentary cycle. It LIES: reservoir is the Earth's crust (rocks)." },
        { L: "🌊", t: "The MAJOR RESERVOIR of carbon on earth = the OCEANS (NCERT Exercise 1e)." }
      ]
    },
    {
      title: "Energy vs Nutrients — 'Energy FLOWS, Nutrients CYCLE'",
      device: `<b>ENERGY:</b> unidirectional, lost as heat, must be resupplied &nbsp;|&nbsp; <b>NUTRIENTS:</b> cyclic, reused repeatedly`,
      expand: [
        { L: "→", t: "ENERGY is UNIDIRECTIONAL. It flows sun → producers → consumers, and is dissipated as HEAT. It can NEVER be recycled." },
        { L: "↻", t: "NUTRIENTS are CYCLIC. They are stored and moved through the ecosystem's components and used again and again." },
        { L: "★", t: "This is why the ecosystem needs a CONSTANT input of solar energy — but does not need a constant input of phosphorus." }
      ]
    },
    {
      title: "Pyramid Limitations — The Three S's",
      device: `<b>S</b>ame species in two levels · <b>S</b>imple chain assumed · <b>S</b>aprophytes skipped`,
      expand: [
        { L: "S", t: "SAME SPECIES: does not account for a species belonging to two or more trophic levels (e.g., the sparrow)." },
        { L: "S", t: "SIMPLE CHAIN: assumes a simple food chain that almost never exists in nature; it cannot accommodate a FOOD WEB." },
        { L: "S", t: "SAPROPHYTES: given NO place in ecological pyramids, despite playing a VITAL role in the ecosystem." }
      ]
    },
    {
      title: "The Sparrow Rule — Trophic level is a FUNCTION, not a species",
      device: `Sparrow eating <b>seeds</b> = <b>PRIMARY consumer</b> &nbsp;|&nbsp; Sparrow eating <b>insects and worms</b> = <b>SECONDARY consumer</b>`,
      expand: [
        { L: "T2", t: "Eating seeds, fruits, peas → PRIMARY CONSUMER (second trophic level)." },
        { L: "T3", t: "Eating insects and worms → SECONDARY CONSUMER (third trophic level)." },
        { L: "★", t: "A given species may occupy MORE THAN ONE trophic level in the SAME ecosystem at the SAME time." }
      ]
    },
    {
      title: "The Two Structural S's",
      device: `<b>S</b>pecies composition &nbsp;+&nbsp; <b>S</b>tratification`,
      expand: [
        { L: "S", t: "SPECIES COMPOSITION — identification and enumeration of the plant and animal species of an ecosystem." },
        { L: "S", t: "STRATIFICATION — the VERTICAL distribution of species at different levels." },
        { L: "🌳", t: "Forest strata, top to bottom: TREES → SHRUBS → HERBS and GRASSES." }
      ]
    },
    {
      title: "Ocean Productivity Paradox — 'Big but lazy'",
      device: `Oceans = <b>~70% of surface</b> but only <b>55 of the 170</b> billion tons of annual NPP`,
      expand: [
        { L: "170", t: "Annual NPP of the WHOLE BIOSPHERE ≈ 170 billion tons (dry weight) of organic matter." },
        { L: "55", t: "Annual NPP of the OCEANS = only 55 billion tons — despite covering ~70% of the surface." },
        { L: "115", t: "The rest — ~115 billion tons — is produced on LAND." },
        { L: "💡", t: "WHY? LIGHT is the limiting factor in aquatic ecosystems — sunlight only penetrates a thin upper layer." }
      ]
    },
    {
      title: "The Sun's One Exception",
      device: `The sun is the ONLY energy source for all ecosystems — <b>EXCEPT the deep-sea hydro-thermal ecosystem</b>`,
      expand: [
        { L: "☀", t: "For every ecosystem on Earth, the SUN is the only source of energy…" },
        { L: "🌋", t: "…EXCEPT the DEEP-SEA HYDRO-THERMAL ecosystem, which runs on chemical energy from vents." },
        { L: "★", t: "This single exception is one of the most frequently asked one-liners from this chapter." }
      ]
    }
  ],

  /* ---------- 4. FLASHCARDS (108) ---------- */
  flashcards: [
    { front: "Define an ecosystem.", back: "A functional unit of nature where living organisms interact among themselves AND with the surrounding physical environment." },
    { front: "What is the largest ecosystem of all?", back: "The entire BIOSPHERE — regarded by many ecologists as a global ecosystem, a composite of all local ecosystems on Earth." },
    { front: "Name the two basic categories of ecosystems, with NCERT's examples.", back: "TERRESTRIAL — forest, grassland, desert. AQUATIC — pond, lake, wetland, river, estuary." },
    { front: "Give two examples of MAN-MADE ecosystems.", back: "Crop fields and an aquarium." },
    { front: "What are the two main STRUCTURAL features of an ecosystem?", back: "1. SPECIES COMPOSITION — identification and enumeration of plant and animal species. 2. STRATIFICATION — the vertical distribution of different species occupying different levels." },
    { front: "Define stratification and give the forest example.", back: "The VERTICAL distribution of different species occupying different levels. In a forest: TREES occupy the top strata, SHRUBS the second, and HERBS AND GRASSES the bottom layers." },
    { front: "Name the four functional aspects of an ecosystem.", back: "(i) Productivity, (ii) Decomposition, (iii) Energy flow, (iv) Nutrient cycling. Mnemonic: PDEN." },
    { front: "What are the ABIOTIC components of an ecosystem?", back: "Inorganic materials — AIR, WATER and SOIL." },
    { front: "What are the BIOTIC components of an ecosystem?", back: "Producers, Consumers and Decomposers." },
    { front: "In a pond, what constitutes the abiotic component?", back: "The WATER with all the dissolved inorganic AND organic substances, plus the RICH SOIL DEPOSIT at the BOTTOM of the pond." },
    { front: "What regulates the rate of function of the entire pond?", back: "The SOLAR INPUT, the CYCLE OF TEMPERATURE, DAY-LENGTH and other CLIMATIC CONDITIONS." },
    { front: "Name the autotrophic components of a pond.", back: "PHYTOPLANKTON, some ALGAE, and the FLOATING, SUBMERGED and MARGINAL plants found at the edges." },
    { front: "Name the consumers in a pond.", back: "ZOOPLANKTON, the FREE-SWIMMING forms and the BOTTOM-DWELLING forms." },
    { front: "Name the decomposers in a pond and say where they are most abundant.", back: "FUNGI, BACTERIA and FLAGELLATES — especially abundant at the BOTTOM of the pond." },
    { front: "Summarise the movement of energy in an ecosystem in one line.", back: "There is UNIDIRECTIONAL movement of energy towards the higher trophic levels, and its DISSIPATION and LOSS AS HEAT to the environment." },
    { front: "What is the basic requirement for any ecosystem to function and sustain?", back: "A CONSTANT INPUT OF SOLAR ENERGY." },
    { front: "Define PRIMARY PRODUCTION.", back: "The AMOUNT of biomass or organic matter produced per unit area over a time period by plants during photosynthesis." },
    { front: "In what units is primary PRODUCTION expressed?", back: "Weight — g m⁻² — or energy — kcal m⁻²." },
    { front: "Define PRODUCTIVITY and give its units.", back: "The RATE of biomass production. Expressed in g m⁻² yr⁻¹ or kcal m⁻² yr⁻¹, so that different ecosystems can be COMPARED." },
    { front: "What is the difference between production and productivity?", back: "PRODUCTION is an AMOUNT (g m⁻²). PRODUCTIVITY is a RATE (g m⁻² yr⁻¹)." },
    { front: "Define Gross Primary Productivity (GPP).", back: "The RATE OF PRODUCTION OF ORGANIC MATTER DURING PHOTOSYNTHESIS. A considerable amount of GPP is utilised by plants in respiration." },
    { front: "Define Net Primary Productivity (NPP) and write the formula.", back: "GPP minus respiration losses (R). Formula: GPP − R = NPP. NPP is the biomass AVAILABLE for consumption by heterotrophs (herbivores AND decomposers)." },
    { front: "Define secondary productivity.", back: "The RATE OF FORMATION OF NEW ORGANIC MATTER BY CONSUMERS." },
    { front: "List the factors on which primary productivity depends.", back: "The PLANT SPECIES inhabiting the area; ENVIRONMENTAL FACTORS; AVAILABILITY OF NUTRIENTS; and the PHOTOSYNTHETIC CAPACITY of the plants." },
    { front: "What is the annual net primary productivity of the whole biosphere?", back: "Approximately 170 BILLION TONS (dry weight) of organic matter." },
    { front: "What is the annual NPP of the oceans, and what fraction of the Earth's surface do they occupy?", back: "Only 55 BILLION TONS — despite occupying about 70 PER CENT of the surface." },
    { front: "How much of the biosphere's annual NPP is produced on LAND?", back: "The rest — approximately 115 billion tons (170 − 55)." },
    { front: "Why is ocean productivity so low despite the oceans covering ~70% of the surface?", back: "Because LIGHT is the LIMITING FACTOR in aquatic ecosystems — sunlight penetrates only a thin upper layer, so photosynthesis is confined to a shallow film of water." },
    { front: "Why is the earthworm called the farmer's 'friend'?", back: "Because it helps in the BREAKDOWN OF COMPLEX ORGANIC MATTER and in the LOOSENING OF THE SOIL." },
    { front: "Define decomposition.", back: "The process in which decomposers break down COMPLEX ORGANIC MATTER into INORGANIC substances like CARBON DIOXIDE, WATER and NUTRIENTS." },
    { front: "What is detritus?", back: "Dead plant remains (leaves, bark, flowers) AND the dead remains of animals, INCLUDING FAECAL MATTER. It is the RAW MATERIAL for decomposition." },
    { front: "Name the five steps of decomposition in order.", back: "FRAGMENTATION → LEACHING → CATABOLISM → HUMIFICATION → MINERALISATION. Mnemonic: 'Fresh Leaves Cook, Humus Made'." },
    { front: "Define fragmentation and name the agents.", back: "DETRITIVORES (e.g., the EARTHWORM) break down detritus into SMALLER PARTICLES." },
    { front: "Define leaching.", back: "The process by which WATER-SOLUBLE INORGANIC NUTRIENTS go DOWN into the SOIL HORIZON and get PRECIPITATED AS UNAVAILABLE SALTS." },
    { front: "Define catabolism (in decomposition).", back: "BACTERIAL AND FUNGAL ENZYMES degrade detritus into SIMPLER INORGANIC SUBSTANCES." },
    { front: "Define humification.", back: "The step of decomposition that leads to the accumulation of HUMUS — a dark-coloured amorphous substance. It occurs in the SOIL." },
    { front: "Define mineralisation.", back: "The process in which HUMUS IS FURTHER DEGRADED by some microbes, RELEASING INORGANIC NUTRIENTS. It occurs in the SOIL." },
    { front: "Give three properties of humus.", back: "1. Dark-coloured and AMORPHOUS. 2. HIGHLY RESISTANT to microbial action — decomposes at an EXTREMELY SLOW rate. 3. COLLOIDAL in nature — serves as a RESERVOIR OF NUTRIENTS." },
    { front: "Do the steps of decomposition occur one after another?", back: "NO. ALL the steps operate SIMULTANEOUSLY on the detritus." },
    { front: "Is decomposition aerobic or anaerobic?", back: "It is LARGELY AN OXYGEN-REQUIRING (aerobic) PROCESS." },
    { front: "What two things control the RATE of decomposition?", back: "1. The CHEMICAL COMPOSITION of the detritus. 2. CLIMATIC FACTORS." },
    { front: "Which detritus composition SLOWS decomposition?", back: "Detritus rich in LIGNIN and CHITIN." },
    { front: "Which detritus composition SPEEDS UP decomposition?", back: "Detritus rich in NITROGEN and water-soluble substances like SUGARS." },
    { front: "Which two climatic factors most regulate decomposition, and how?", back: "TEMPERATURE and SOIL MOISTURE — through their effects on the ACTIVITIES OF SOIL MICROBES." },
    { front: "What conditions FAVOUR decomposition, and what conditions INHIBIT it?", back: "FAVOUR: a WARM and MOIST environment. INHIBIT: LOW TEMPERATURE and ANAEROBIOSIS — which cause a BUILD-UP OF ORGANIC MATERIALS." },
    { front: "Which is the only ecosystem on Earth NOT powered by the sun?", back: "The DEEP-SEA HYDRO-THERMAL ECOSYSTEM." },
    { front: "What percentage of incident solar radiation is photosynthetically active radiation (PAR)?", back: "LESS THAN 50 PER CENT." },
    { front: "What percentage of the PAR do plants actually capture?", back: "Only 2–10 PER CENT — and this small amount of energy sustains the ENTIRE LIVING WORLD." },
    { front: "How does an ecosystem obey the Second Law of Thermodynamics?", back: "Ecosystems are NOT exempt from it. They need a CONSTANT SUPPLY OF ENERGY to synthesise the molecules they require, in order to COUNTERACT THE UNIVERSAL TENDENCY TOWARD INCREASING DISORDERLINESS." },
    { front: "Who are the major producers in a terrestrial ecosystem?", back: "HERBACEOUS and WOODY plants." },
    { front: "Who are the producers in an aquatic ecosystem?", back: "PHYTOPLANKTON, ALGAE and HIGHER PLANTS." },
    { front: "What are the two possible fates of energy trapped by a producer?", back: "It is either PASSED ON TO A CONSUMER, or the ORGANISM DIES. The death of an organism is the BEGINNING of the detritus food chain/web." },
    { front: "Name the common herbivores in terrestrial and aquatic ecosystems.", back: "TERRESTRIAL: insects, birds and mammals. AQUATIC: MOLLUSCS." },
    { front: "A secondary consumer is more correctly called a…", back: "PRIMARY CARNIVORE. (And a tertiary consumer is a SECONDARY CARNIVORE.)" },
    { front: "Write out NCERT's grazing food chain (GFC) with the trophic labels.", back: "GRASS (Producer) → GOAT (Primary Consumer) → MAN (Secondary Consumer)." },
    { front: "What does the detritus food chain (DFC) begin with, and who makes it up?", back: "It begins with DEAD ORGANIC MATTER. It is made up of DECOMPOSERS — heterotrophic organisms, mainly FUNGI and BACTERIA." },
    { front: "What are saprotrophs? What does the name mean?", back: "Another name for the decomposers of the DFC. 'Sapro' = TO DECOMPOSE." },
    { front: "How do decomposers actually feed?", back: "They SECRETE DIGESTIVE ENZYMES that break down dead and waste materials into SIMPLE INORGANIC MATERIALS, which are subsequently ABSORBED BY THEM." },
    { front: "In an AQUATIC ecosystem, which food chain is the major conduit for energy flow?", back: "The GRAZING FOOD CHAIN (GFC)." },
    { front: "In a TERRESTRIAL ecosystem, which food chain carries a much larger fraction of the energy?", back: "The DETRITUS FOOD CHAIN (DFC)." },
    { front: "How are the GFC and DFC connected?", back: "Some organisms of the DFC are PREY TO GFC ANIMALS, and some animals like COCKROACHES and CROWS are OMNIVORES. These natural interconnections make it a FOOD WEB." },
    { front: "Define trophic level.", back: "The specific place an organism occupies in a food chain, based on the SOURCE OF ITS NUTRITION OR FOOD." },
    { front: "Which trophic levels do producers, herbivores and carnivores occupy?", back: "Producers = FIRST trophic level. Herbivores (primary consumers) = SECOND. Carnivores (secondary consumers) = THIRD." },
    { front: "Is a trophic level a species or a function?", back: "A FUNCTIONAL LEVEL, NOT A SPECIES. A given species may occupy MORE THAN ONE trophic level in the SAME ecosystem at the SAME time." },
    { front: "Give NCERT's example of one species occupying two trophic levels.", back: "A SPARROW is a PRIMARY CONSUMER when it eats SEEDS, FRUITS and PEAS, and a SECONDARY CONSUMER when it eats INSECTS and WORMS." },
    { front: "What happens to the amount of energy at successive trophic levels?", back: "It DECREASES. Organisms at each trophic level depend on those at the LOWER trophic level for their energy demands." },
    { front: "Define standing crop.", back: "The certain MASS OF LIVING MATERIAL at a trophic level at a PARTICULAR TIME. It is measured as BIOMASS or as the NUMBER in a unit area." },
    { front: "Why is dry weight a more accurate measure of biomass than fresh weight?", back: "Because FRESH WEIGHT VARIES WITH WATER CONTENT, which fluctuates with hydration, humidity and species. Water contributes no organic matter or energy, so dry weight reflects the true biomass." },
    { front: "State the 10 per cent law.", back: "Only 10 PER CENT of the energy is transferred to each trophic level FROM THE LOWER TROPHIC LEVEL." },
    { front: "What is the consequence of the 10 per cent law?", back: "The NUMBER OF TROPHIC LEVELS in the grazing food chain is RESTRICTED — there is not enough energy left to support more levels." },
    { front: "If producers hold 10,000 J of energy, how much reaches a secondary carnivore?", back: "10,000 J → 1,000 J (herbivore) → 100 J (primary carnivore) → 10 J (SECONDARY CARNIVORE)." },
    { front: "Define an ecological pyramid.", back: "A graphical representation of the food or energy relationship between organisms at different trophic levels, expressed in terms of NUMBER, BIOMASS or ENERGY." },
    { front: "What do the base and apex of an ecological pyramid represent?", back: "BASE = the PRODUCERS (first trophic level). APEX = the TERTIARY or TOP-LEVEL CONSUMER." },
    { front: "Name the three types of ecological pyramids.", back: "(a) Pyramid of NUMBER, (b) Pyramid of BIOMASS, (c) Pyramid of ENERGY." },
    { front: "In a grassland pyramid of numbers, what supports how many top carnivores?", back: "Nearly 6 MILLION PLANTS support only 3 TOP CARNIVORES." },
    { front: "In which ecosystem is the pyramid of NUMBERS inverted?", back: "A TREE ecosystem — one big tree supports many insects, which support fewer birds." },
    { front: "In which ecosystem is the pyramid of BIOMASS inverted, and why?", back: "The SEA. A SMALL standing crop of PHYTOPLANKTON supports a LARGE standing crop of ZOOPLANKTON — the biomass of fishes far exceeds that of phytoplankton." },
    { front: "Resolve the inverted-biomass paradox in the sea.", back: "Biomass is a STANDING CROP — a snapshot, not a rate. Phytoplankton have an EXTREMELY HIGH TURNOVER RATE: they are produced and eaten within hours to days, so very little stands around at any instant, even though they produce enormous biomass over a year. Long-lived fish accumulate and hold their biomass. Energy still flows downhill correctly." },
    { front: "Why can the pyramid of ENERGY never be inverted?", back: "Because when energy flows from one trophic level to the next, SOME ENERGY IS ALWAYS LOST AS HEAT at each step. Energy at a lower trophic level is ALWAYS more than at a higher level." },
    { front: "What does each bar in a pyramid of energy indicate?", back: "The amount of energy present at each trophic level IN A GIVEN TIME or ANNUALLY PER UNIT AREA." },
    { front: "In an ideal pyramid of energy, what percentage of available sunlight do primary producers convert into NPP?", back: "Only about 1 PER CENT." },
    { front: "State the three limitations of ecological pyramids.", back: "1. Does not account for the SAME SPECIES belonging to two or more trophic levels. 2. Assumes a SIMPLE FOOD CHAIN that almost never exists in nature — it cannot accommodate a FOOD WEB. 3. SAPROPHYTES are given NO PLACE, despite their vital role." },
    { front: "Why must all organisms at a trophic level be included in any pyramid calculation?", back: "Because NO GENERALISATION we make will be true if we take only a FEW INDIVIDUALS at any trophic level into account." },
    { front: "In most ecosystems, are the pyramids of number, biomass and energy upright or inverted?", back: "UPRIGHT — producers exceed herbivores in number and biomass, herbivores exceed carnivores, and energy at a lower level is always more than at a higher level." },
    { front: "Define nutrient cycling.", back: "The STORAGE AND MOVEMENT of nutrient elements through the various components of the ecosystem. Through it, nutrients are USED REPEATEDLY." },
    { front: "Name the two types of nutrient cycles and their reservoirs.", back: "GASEOUS — reservoir is the ATMOSPHERE or HYDROSPHERE (example: CARBON). SEDIMENTARY — reservoir is the EARTH'S CRUST (example: PHOSPHORUS)." },
    { front: "What is the major reservoir of carbon on Earth?", back: "The OCEANS." },
    { front: "Define ecosystem services and give NCERT's example.", back: "The PRODUCTS OF ECOSYSTEM PROCESSES. Example: the PURIFICATION OF AIR AND WATER BY FORESTS." },
    { front: "Contrast the movement of energy and nutrients in an ecosystem.", back: "ENERGY is UNIDIRECTIONAL — it FLOWS, is lost as HEAT, and can NEVER be recycled. NUTRIENTS are CYCLIC — they are used REPEATEDLY." },
    { front: "Distinguish GFC from DFC in one line each.", back: "GFC starts with LIVING PRODUCERS and dominates AQUATIC ecosystems. DFC starts with DEAD ORGANIC MATTER and dominates TERRESTRIAL ecosystems." },
    { front: "Distinguish production from decomposition.", back: "PRODUCTION BUILDS complex organic matter from inorganic materials (photosynthesis; requires sunlight). DECOMPOSITION BREAKS DOWN complex organic matter into inorganic substances (requires oxygen; done by decomposers)." },
    { front: "Distinguish litter from detritus.", back: "LITTER = the surface layer of dead PLANT material (fallen leaves, twigs, bark) lying on the soil. DETRITUS is BROADER — ALL dead organic matter: dead plant remains AND dead animal remains AND faecal matter. Litter is one part of detritus." },
    { front: "Distinguish a food chain from a food web.", back: "A FOOD CHAIN is a SINGLE LINEAR sequence of who-eats-whom; a FOOD WEB is MANY INTERCONNECTED food chains. Only the web actually exists in nature." },
    { front: "Distinguish an upright from an inverted pyramid.", back: "UPRIGHT: the base (producers) is the LARGEST and the pyramid narrows toward the apex. INVERTED: the base is SMALLER than the levels above it (tree → numbers; sea → biomass)." },
    { front: "Distinguish primary from secondary productivity.", back: "PRIMARY = rate of biomass production by PRODUCERS (via photosynthesis). SECONDARY = rate of formation of new organic matter by CONSUMERS." },
    { front: "NCERT Exercise: 'Plants are called ______ because they fix carbon dioxide.'", back: "PRODUCERS (autotrophs)." },
    { front: "NCERT Exercise: 'In an ecosystem dominated by trees, the pyramid of numbers is ______ type.'", back: "INVERTED." },
    { front: "NCERT Exercise: 'In aquatic ecosystems, the limiting factor for productivity is ______.'", back: "LIGHT." },
    { front: "NCERT Exercise: 'Common detritivores in our ecosystem are ______.'", back: "EARTHWORMS." },
    { front: "NCERT Exercise: 'Which has the largest population in a food chain?'", back: "PRODUCERS." },
    { front: "NCERT Exercise: 'The second trophic level in a lake is ______.'", back: "ZOOPLANKTON. (Phytoplankton are the FIRST trophic level.)" },
    { front: "NCERT Exercise: 'Secondary producers are ______.'", back: "HERBIVORES — they are the first level of consumers, and secondary productivity is the rate of formation of new organic matter by consumers." },
    { front: "What are the four steps of an ecosystem's functioning, as demonstrated by the pond?", back: "1. Autotrophs convert INORGANIC → ORGANIC using the sun's radiant energy. 2. Heterotrophs CONSUME the autotrophs. 3. Dead matter is DECOMPOSED and MINERALISED. 4. Nutrients are RELEASED back for REUSE by autotrophs — repeated over and over again." },
    { front: "Why is the pond chosen as NCERT's model ecosystem?", back: "Because it is a FAIRLY SELF-SUSTAINABLE UNIT and a RATHER SIMPLE example that still explains even the complex interactions of an aquatic ecosystem — all four basic components are well exhibited in it." },
    { front: "Frame the ecosystem in terms of input, transfer and output.", back: "INPUT = productivity. TRANSFER = food chain/web and nutrient cycling. OUTPUT = degradation and energy loss." },
    { front: "Are decomposers autotrophs or heterotrophs?", back: "HETEROTROPHS — mainly fungi and bacteria. They meet their energy and nutrient requirements by degrading dead organic matter." },
    { front: "What becomes of an organism when it dies, in energy terms?", back: "It is converted to DETRITUS or DEAD BIOMASS, which serves as an ENERGY SOURCE FOR DECOMPOSERS." },
    { front: "Why is energy flow described as unidirectional?", back: "Because all organisms depend on producers for food, directly or indirectly. Energy flows from the SUN → PRODUCERS → CONSUMERS, and is dissipated as heat. It never flows back." }
  ],

  /* ---------- 5. ACTIVE RECALL (51) ---------- */
  recall: [
    { q: "Define an ecosystem and describe its range of size.", hint: "Functional unit. Pond to biosphere.", a: "An <b>ecosystem</b> is a <b>functional unit of nature</b> where <b>living organisms interact among themselves and also with the surrounding physical environment</b>.<br><br>It varies greatly in size — from a <b>small pond</b> to a <b>large forest or a sea</b>. Many ecologists regard the <b>entire biosphere as a GLOBAL ECOSYSTEM</b>, a composite of all local ecosystems on Earth." },
    { q: "Classify ecosystems, giving all of NCERT's examples.", hint: "Two basic categories + one man-made.", a: "<b>TERRESTRIAL:</b> Forest, Grassland, Desert.<br><b>AQUATIC:</b> Pond, Lake, Wetland, River, Estuary.<br><b>MAN-MADE:</b> Crop fields, Aquarium." },
    { q: "Describe the components of an ecosystem. (NCERT Exercise Q7)", hint: "Abiotic + biotic; two structural features; four functional aspects.", a: "<b>ABIOTIC components:</b> inorganic materials — <b>air, water and soil</b>.<br><b>BIOTIC components:</b> <b>producers, consumers and decomposers</b>.<br><br><b>Two STRUCTURAL features:</b><br>• <b>Species composition</b> — identification and enumeration of plant and animal species.<br>• <b>Stratification</b> — the <b>vertical distribution</b> of species at different levels (trees → shrubs → herbs and grasses).<br><br><b>Four FUNCTIONAL aspects:</b> <b>Productivity, Decomposition, Energy flow, Nutrient cycling.</b>" },
    { q: "Describe the pond as a model ecosystem — all four components.", hint: "Abiotic, autotrophs, consumers, decomposers.", a: "A pond is a <b>shallow water body</b>, a <b>fairly self-sustainable unit</b>, in which all four basic components are well exhibited.<br><br><b>ABIOTIC:</b> the <b>water</b> with all the <b>dissolved inorganic and organic substances</b>, and the <b>rich soil deposit at the bottom</b>.<br><b>REGULATORS:</b> the <b>solar input</b>, the <b>cycle of temperature</b>, <b>day-length</b> and other <b>climatic conditions</b> — these set the rate of function of the entire pond.<br><b>AUTOTROPHS:</b> <b>phytoplankton</b>, some <b>algae</b>, and the <b>floating, submerged and marginal plants</b> at the edges.<br><b>CONSUMERS:</b> <b>zooplankton</b>, the <b>free-swimming</b> and <b>bottom-dwelling</b> forms.<br><b>DECOMPOSERS:</b> <b>fungi, bacteria and flagellates</b>, especially abundant at the <b>bottom</b>." },
    { q: "What four functions does the pond perform that any ecosystem — and the whole biosphere — performs?", hint: "Convert, consume, decompose, release.", a: "1. <b>Conversion of inorganic into organic material</b> with the help of the <b>radiant energy of the sun</b>, by the <b>autotrophs</b>.<br>2. <b>Consumption of the autotrophs by heterotrophs</b>.<br>3. <b>Decomposition and mineralisation of the dead matter</b>.<br>4. <b>Release of nutrients back for reuse by the autotrophs</b> — and these events are <b>repeated over and over again</b>.<br><br>Running through it all: <b>unidirectional movement of energy</b> toward higher trophic levels, and its <b>dissipation and loss as heat</b>." },
    { q: "Distinguish primary PRODUCTION from PRODUCTIVITY, including units.", hint: "Amount vs rate.", a: "<b>Primary PRODUCTION</b> = the <b>AMOUNT</b> of biomass or organic matter produced <b>per unit area over a time period</b> by plants during photosynthesis.<br>Units: <b>g m<sup>&minus;2</sup></b> (weight) or <b>kcal m<sup>&minus;2</sup></b> (energy).<br><br><b>PRODUCTIVITY</b> = the <b>RATE</b> of biomass production.<br>Units: <b>g m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b> or <b>kcal m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b> — expressed this way so that <b>different ecosystems can be COMPARED</b>." },
    { q: "Define GPP, NPP and secondary productivity, and give the formula linking the first two.", hint: "Earn, spend, keep.", a: "<b>GPP (Gross Primary Productivity)</b> = the <b>rate of production of organic matter during photosynthesis</b>. A considerable amount of it is <b>utilised by plants in respiration</b>.<br><br><b>NPP (Net Primary Productivity)</b> = <b>GPP &minus; R</b> (respiration losses). It is the <b>biomass AVAILABLE for consumption by heterotrophs</b> — <b>herbivores AND decomposers</b>.<br><br><b>SECONDARY PRODUCTIVITY</b> = the <b>rate of formation of new organic matter by CONSUMERS</b>.<br><br><b>Formula: GPP &minus; R = NPP</b>" },
    { q: "What is primary productivity? Give a brief description of the factors that affect it. (NCERT Exercise Q9)", hint: "Four factors.", a: "<b>Primary productivity</b> is the <b>rate of biomass production</b> by producers — the amount of organic matter produced per unit area per unit time during photosynthesis.<br><br><b>Factors affecting it:</b><br>1. The <b>PLANT SPECIES</b> inhabiting the particular area.<br>2. <b>ENVIRONMENTAL FACTORS</b> (light, temperature, water).<br>3. <b>AVAILABILITY OF NUTRIENTS</b>.<br>4. The <b>PHOTOSYNTHETIC CAPACITY</b> of the plants.<br><br>Because of these, <b>productivity varies in different types of ecosystems</b>." },
    { q: "Give the three global productivity numbers and explain the ocean paradox.", hint: "170, 55, 70%.", a: "<b>Annual NPP of the whole biosphere</b> ≈ <b>170 billion tons</b> (dry weight) of organic matter.<br><b>Annual NPP of the oceans</b> = only <b>55 billion tons</b> — despite the oceans occupying about <b>70 per cent</b> of the Earth's surface. The <b>rest (~115 billion tons) is on land</b>.<br><br><b>The paradox, resolved:</b> <b>LIGHT is the limiting factor</b> in aquatic ecosystems. Sunlight penetrates only a <b>thin upper (photic) layer</b>, so photosynthesis is confined to a shallow film of water. Nutrient scarcity in open-ocean surface waters compounds the problem." },
    { q: "Define decomposition and describe the raw material for it.", hint: "Complex → inorganic. Detritus.", a: "<b>Decomposition</b> is the process in which <b>decomposers break down complex organic matter into INORGANIC substances</b> like <b>carbon dioxide, water and nutrients</b>.<br><br><b>Detritus</b> — the <b>raw material</b> — consists of <b>dead plant remains</b> such as <b>leaves, bark and flowers</b>, plus the <b>dead remains of animals, INCLUDING FAECAL MATTER</b>." },
    { q: "Define decomposition and describe the PROCESSES and PRODUCTS of decomposition. (NCERT Exercise Q10)", hint: "Five steps, and what comes out.", a: "<b>PROCESSES (all operate SIMULTANEOUSLY):</b><br><b>1. Fragmentation</b> — <b>detritivores</b> (e.g., earthworm) break detritus into <b>smaller particles</b>.<br><b>2. Leaching</b> — <b>water-soluble inorganic nutrients</b> go down into the <b>soil horizon</b> and get <b>precipitated as unavailable salts</b>.<br><b>3. Catabolism</b> — <b>bacterial and fungal enzymes</b> degrade detritus into <b>simpler inorganic substances</b>.<br><b>4. Humification</b> — accumulation of <b>humus</b> (in the soil).<br><b>5. Mineralisation</b> — microbes further degrade humus, <b>releasing inorganic nutrients</b> (in the soil).<br><br><b>PRODUCTS:</b> <b>Carbon dioxide, water, inorganic nutrients</b> — and <b>HUMUS</b>." },
    { q: "Describe HUMUS fully — its three defining properties.", hint: "Dark, resistant, colloidal.", a: "<b>Humus</b> is a <b>dark-coloured AMORPHOUS substance</b> that accumulates during <b>humification</b>.<br><br>1. It is <b>HIGHLY RESISTANT to microbial action</b> and <b>undergoes decomposition at an extremely SLOW rate</b>.<br>2. It is <b>COLLOIDAL in nature</b>.<br>3. Because of this, it serves as a <b>RESERVOIR OF NUTRIENTS</b>.<br><br>It is <b>further degraded by some microbes</b> in the process called <b>mineralisation</b>, releasing inorganic nutrients." },
    { q: "What controls the RATE of decomposition? Give both categories with their effects.", hint: "Chemistry + climate.", a: "Decomposition is <b>largely an OXYGEN-REQUIRING process</b>. Its rate is controlled by:<br><br><b>1. CHEMICAL COMPOSITION OF DETRITUS</b><br>• <b>SLOWER</b> if detritus is rich in <b>LIGNIN and CHITIN</b>.<br>• <b>QUICKER</b> if detritus is rich in <b>NITROGEN</b> and <b>water-soluble substances like SUGARS</b>.<br><br><b>2. CLIMATIC FACTORS</b><br>• <b>TEMPERATURE and SOIL MOISTURE</b> are the <b>two most important</b> — they act through their <b>effects on the activities of soil microbes</b>.<br>• <b>WARM and MOIST</b> environment <b>favours</b> decomposition.<br>• <b>LOW TEMPERATURE and ANAEROBIOSIS INHIBIT</b> decomposition, resulting in a <b>BUILD-UP OF ORGANIC MATERIALS</b>." },
    { q: "Give an account of energy flow in an ecosystem. (NCERT Exercise Q11)", hint: "Sun → PAR → capture → trophic levels → 10% law → heat.", a: "<b>1. Source.</b> Except for the <b>deep-sea hydro-thermal ecosystem</b>, the <b>SUN is the ONLY source of energy</b> for all ecosystems on Earth.<br><br><b>2. Capture.</b> <b>Less than 50%</b> of incident solar radiation is <b>PAR</b>. Plants capture only <b>2&ndash;10% of the PAR</b> — and this small amount <b>sustains the entire living world</b>.<br><br><b>3. Direction.</b> Flow is <b>UNIDIRECTIONAL</b>: sun → producers → consumers. Ecosystems are <b>not exempt from the Second Law</b> and need a <b>constant supply of energy</b> to counteract the universal tendency toward <b>increasing disorderliness</b>.<br><br><b>4. Trophic transfer.</b> Producers (T1) → herbivores (T2) → carnivores (T3) → secondary carnivores (T4). The <b>amount of energy DECREASES at successive trophic levels</b>, following the <b>10 PER CENT LAW</b> — which <b>restricts the number of trophic levels</b>.<br><br><b>5. Loss.</b> Energy is <b>dissipated and lost as HEAT</b> at every step. It is <b>never recycled</b>. Dead organisms become <b>detritus</b>, the energy source for <b>decomposers</b>." },
    { q: "State the four key energy percentages in order, and the classic trap.", hint: "50 → 10 → 1 → 10.", a: "<b>&lt;50%</b> — of INCIDENT SOLAR RADIATION is <b>PAR</b>.<br><b>2&ndash;10%</b> — <b>of the PAR</b> is captured by plants.<br><b>~1%</b> — of the available sunlight is converted into <b>NPP</b> (ideal energy pyramid).<br><b>10%</b> — of energy is transferred <b>between trophic levels</b> (the <b>10 per cent law</b>).<br><br><b>THE TRAP:</b> 'What % of incident solar radiation is PAR?' → <b>50%</b>. 'What % of PAR is captured?' → <b>2&ndash;10%</b>. Students swap these constantly." },
    { q: "How does an ecosystem obey the First and Second Laws of Thermodynamics?", hint: "Conversion, and entropy.", a: "<b>First Law:</b> energy is neither created nor destroyed — the sun's radiant energy is <b>fixed and CONVERTED</b> by autotrophs into food, not manufactured. The flow is <b>unidirectional from sun → producers → consumers</b>.<br><br><b>Second Law:</b> ecosystems are <b>NOT exempt</b>. They need a <b>constant supply of energy</b> to synthesise the molecules they require, in order to <b>counteract the universal tendency toward INCREASING DISORDERLINESS (entropy)</b>." },
    { q: "Distinguish between the Grazing Food Chain and the Detritus Food Chain. (NCERT Exercise Q6a)", hint: "Start, organisms, and which ecosystem each dominates.", a: "<table class='cmp'><thead><tr><th>Feature</th><th>GFC</th><th>DFC</th></tr></thead><tbody><tr><td>Begins with</td><td><b>Living producers</b> (plants)</td><td><b>Dead organic matter</b> (detritus)</td></tr><tr><td>Main organisms</td><td>Herbivores → carnivores</td><td><b>Decomposers / saprotrophs</b> (fungi, bacteria)</td></tr><tr><td>Energy source</td><td><b>Sun</b>, directly</td><td><b>Detritus</b></td></tr><tr><td>Dominant in</td><td><b>AQUATIC</b> ecosystems (major conduit)</td><td><b>TERRESTRIAL</b> ecosystems (much larger fraction)</td></tr><tr><td>Trophic levels</td><td><b>Restricted</b> by the 10% law</td><td>Not similarly restricted</td></tr></tbody></table><br><b>Memory hook: 'Water grazes, Land rots.'</b>" },
    { q: "Write NCERT's grazing food chain with full trophic labelling.", hint: "Three organisms only.", a: "<b>GRASS → GOAT → MAN</b><br><br>Grass = <b>Producer</b> (first trophic level)<br>Goat = <b>Primary Consumer</b> / herbivore (second trophic level)<br>Man = <b>Secondary Consumer</b> / primary carnivore (third trophic level)" },
    { q: "Explain the detritus food chain fully, including what saprotrophs are and how they feed.", hint: "Dead matter, fungi, bacteria, enzymes.", a: "The <b>DFC begins with DEAD ORGANIC MATTER</b>. It is made up of <b>decomposers</b> — <b>heterotrophic organisms, mainly FUNGI and BACTERIA</b>, which meet their energy and nutrient requirements by <b>degrading dead organic matter or detritus</b>.<br><br>They are also known as <span class='kw'>SAPROTROPHS</span> (<b>sapro = to decompose</b>).<br><br><b>How they feed:</b> they <b>SECRETE DIGESTIVE ENZYMES</b> that <b>break down dead and waste materials into simple inorganic materials</b>, which are <b>subsequently ABSORBED by them</b>." },
    { q: "How and why does the DFC connect to the GFC? What is the result?", hint: "Prey, omnivores, and a name.", a: "The DFC may be connected with the GFC at some levels:<br>• Some organisms of the <b>DFC are PREY to GFC animals</b>.<br>• In a natural ecosystem, some animals — like <b>COCKROACHES and CROWS</b> — are <b>OMNIVORES</b>.<br><br>These <b>natural interconnections of food chains make it a FOOD WEB</b>." },
    { q: "Distinguish between a food chain and a food web. (NCERT Exercise Q6d)", hint: "Linear vs interconnected.", a: "<b>FOOD CHAIN:</b> a <b>single, LINEAR</b> sequence of who-eats-whom. An organism occupies <b>one</b> position. It <b>almost never exists in pure form</b> in nature.<br><br><b>FOOD WEB:</b> <b>many INTERCONNECTED</b> food chains. An organism may occupy <b>several</b> positions. This is what <b>actually exists</b> in nature.<br><br>Ecological pyramids are limited precisely because they <b>assume a simple food chain and cannot accommodate a food web</b>." },
    { q: "Define trophic level and list the first four levels with both names for each.", hint: "Functional level, not a species.", a: "A <b>trophic level</b> is the specific place an organism occupies in a food chain, based on the <b>source of its nutrition or food</b>.<br><br><b>T1</b> — <b>Producers</b><br><b>T2</b> — <b>Herbivores</b> = Primary consumers<br><b>T3</b> — <b>Primary carnivores</b> = Secondary consumers<br><b>T4</b> — <b>Secondary carnivores</b> = Tertiary consumers<br><br><b>Critical:</b> a trophic level is a <b>FUNCTIONAL LEVEL, NOT A SPECIES</b>." },
    { q: "Prove with NCERT's example that a species can occupy two trophic levels at once.", hint: "One bird, two diets.", a: "A <b>SPARROW</b>:<br>• is a <b>PRIMARY CONSUMER</b> (second trophic level) when it eats <b>seeds, fruits and peas</b>;<br>• is a <b>SECONDARY CONSUMER</b> (third trophic level) when it eats <b>insects and worms</b>.<br><br>Therefore a <b>given species may occupy more than one trophic level in the SAME ecosystem at the SAME time</b> — which is exactly why ecological pyramids have a <b>limitation</b>: they cannot account for it." },
    { q: "Define standing crop and explain why dry weight is preferred.", hint: "Snapshot of biomass. Water is the problem.", a: "Each trophic level has a certain <b>mass of living material at a particular time</b> — this is the <b>STANDING CROP</b>. It is measured as the <b>mass of living organisms (biomass)</b> or the <b>number in a unit area</b>.<br><br>Biomass may be expressed in <b>fresh or dry weight</b>, but <b>DRY WEIGHT is MORE ACCURATE</b>.<br><br><b>Why?</b> Because <b>fresh weight varies with water content</b>, which fluctuates with hydration, humidity and species. <b>Water contributes no organic matter and no energy</b>, so including it distorts the comparison. Dry weight reflects the true organic content." },
    { q: "State the 10 per cent law and its consequence. Work through a numerical example.", hint: "10,000 J at the base.", a: "<b>10 per cent law:</b> only <b>10 per cent of the energy is transferred to each trophic level from the LOWER trophic level</b>.<br><br><b>Consequence:</b> the <b>number of trophic levels in the grazing food chain is RESTRICTED</b>. There is simply not enough energy left to support additional levels.<br><br><b>Worked example (starting at 10,000 J):</b><br>Producers = <b>10,000 J</b><br>Herbivores = <b>1,000 J</b><br>Primary carnivores = <b>100 J</b><br>Secondary carnivores = <b>10 J</b><br>Tertiary carnivores = <b>1 J</b> — barely viable." },
    { q: "Define ecological pyramids and describe, with examples, the pyramids of number and biomass. (NCERT Exercise Q8)", hint: "Base, apex, and both inversions.", a: "An <b>ecological pyramid</b> is a graphical representation of the <b>food or energy relationship</b> between organisms at different trophic levels, expressed in terms of <b>number, biomass or energy</b>. The <b>BASE</b> = the <b>producers (first trophic level)</b>; the <b>APEX</b> = the <b>tertiary or top-level consumer</b>.<br><br><b>PYRAMID OF NUMBERS</b> — number of individuals at each level.<br>• <b>Upright (grassland):</b> nearly <b>6 million plants</b> support only <b>3 top carnivores</b>.<br>• <b>INVERTED (tree ecosystem):</b> a single big tree supports thousands of insects, which support fewer birds.<br><br><b>PYRAMID OF BIOMASS</b> — the standing crop at each level.<br>• <b>Upright (most terrestrial):</b> a sharp decrease in biomass at higher trophic levels.<br>• <b>INVERTED (the SEA):</b> a <b>small standing crop of phytoplankton supports a large standing crop of zooplankton</b> — the biomass of fishes far exceeds that of phytoplankton." },
    { q: "Why can the pyramid of ENERGY never be inverted? What does each bar represent?", hint: "Heat.", a: "Because when energy flows from a particular trophic level to the next, <b>SOME ENERGY IS ALWAYS LOST AS HEAT at each step</b>. Therefore <b>energy at a lower trophic level is ALWAYS more than at a higher level</b> — there is no physical route to an inversion.<br><br><b>Each bar</b> in the energy pyramid indicates the <b>amount of energy present at each trophic level in a given time, or annually per unit area</b>.<br><br>In an <b>ideal pyramid of energy</b>, primary producers convert only <b>1%</b> of the sunlight available to them into NPP." },
    { q: "Resolve the inverted-biomass paradox of the sea in full.", hint: "Snapshot vs rate. Turnover.", a: "<b>The paradox:</b> in the sea, the <b>biomass of fishes far exceeds that of phytoplankton</b> — so how does the small base feed the huge top?<br><br><b>The resolution:</b> <b>Biomass is a STANDING CROP — a SNAPSHOT at one instant, not a RATE.</b><br>• Phytoplankton have an <b>extremely high turnover rate</b>: they reproduce and are eaten within <b>hours to days</b>. Over a year they <b>produce an enormous total biomass</b>, but at any given moment <b>very little of it is standing around</b>.<br>• Long-lived fish, by contrast, <b>accumulate and hold</b> their biomass for years.<br><br><b>Energy still flows correctly downhill</b> — which is exactly why the <b>ENERGY pyramid stays UPRIGHT</b> even when the <b>BIOMASS pyramid FLIPS</b>." },
    { q: "Distinguish between an upright and an inverted pyramid, and list where each inversion occurs. (NCERT Exercise Q6c)", hint: "Tree, sea, never.", a: "<b>UPRIGHT:</b> the <b>base (producers) is the LARGEST</b>, and the pyramid narrows toward the apex. This is the case in <b>most</b> ecosystems for all three pyramid types.<br><b>INVERTED:</b> the <b>base is SMALLER</b> than the levels above it.<br><br><b>Where inversion happens:</b><br>• <b>Pyramid of NUMBERS → inverted in a TREE ecosystem.</b><br>• <b>Pyramid of BIOMASS → inverted in the SEA.</b><br>• <b>Pyramid of ENERGY → NEVER inverted. Always upright.</b><br><br><b>Memory hook: 'Tree flips Numbers, Sea flips Biomass, Nothing flips Energy.'</b>" },
    { q: "State the three limitations of ecological pyramids.", hint: "Three S's.", a: "<b>1. SAME SPECIES:</b> it <b>does not take into account the same species belonging to two or more trophic levels</b> (the sparrow problem).<br><b>2. SIMPLE CHAIN:</b> it <b>assumes a simple food chain</b>, something that <b>almost never exists in nature</b>; it <b>does not accommodate a food web</b>.<br><b>3. SAPROPHYTES:</b> <b>saprophytes are not given any place</b> in ecological pyramids, even though they play a <b>vital role</b> in the ecosystem." },
    { q: "Distinguish between production and decomposition. (NCERT Exercise Q6b)", hint: "Build vs break.", a: "<table class='cmp'><thead><tr><th>Feature</th><th>PRODUCTION</th><th>DECOMPOSITION</th></tr></thead><tbody><tr><td>Direction</td><td><b>BUILDS</b> complex organic matter from inorganic materials</td><td><b>BREAKS DOWN</b> complex organic matter into inorganic substances</td></tr><tr><td>Process</td><td><b>Photosynthesis</b></td><td><b>Fragmentation, leaching, catabolism, humification, mineralisation</b></td></tr><tr><td>Requires</td><td><b>Sunlight</b> and CO<sub>2</sub></td><td><b>Oxygen</b> (largely aerobic)</td></tr><tr><td>Performed by</td><td><b>Producers</b> (autotrophs)</td><td><b>Decomposers</b> (saprotrophs — fungi and bacteria)</td></tr><tr><td>Products</td><td>Organic matter / biomass</td><td>CO<sub>2</sub>, water, inorganic nutrients, humus</td></tr></tbody></table>" },
    { q: "Distinguish between litter and detritus. (NCERT Exercise Q6e)", hint: "One is a subset of the other.", a: "<b>LITTER</b> = the <b>surface layer of dead PLANT material</b> — fallen leaves, twigs, bark — lying on top of the soil.<br><br><b>DETRITUS</b> is <b>BROADER</b> — it is <b>ALL dead organic matter</b>: <b>dead plant remains AND dead animal remains AND faecal matter</b>.<br><br><b>Relationship:</b> litter is <b>one component of detritus</b>. Detritus is the raw material for decomposition." },
    { q: "Distinguish between primary and secondary productivity. (NCERT Exercise Q6f)", hint: "Who is doing the producing.", a: "<b>PRIMARY productivity</b> = the <b>rate of biomass production by PRODUCERS</b> (plants), during <b>photosynthesis</b>. Subdivided into <b>GPP</b> and <b>NPP</b> (NPP = GPP &minus; R).<br><br><b>SECONDARY productivity</b> = the <b>rate of formation of new organic matter by CONSUMERS</b>. It is the rate at which consumers assimilate food energy into their own biomass." },
    { q: "Define nutrient cycling. Name the two types with their reservoirs and NCERT's example element for each.", hint: "Gaseous vs sedimentary.", a: "<b>Nutrient cycling</b> = the <b>storage and movement of nutrient elements through the various components of the ecosystem</b>. Through this process, <b>nutrients are used REPEATEDLY</b>.<br><br><b>GASEOUS type:</b> reservoir = the <b>ATMOSPHERE or HYDROSPHERE</b>. Example element: <b>CARBON</b>.<br><b>SEDIMENTARY type:</b> reservoir = the <b>EARTH'S CRUST</b>. Example element: <b>PHOSPHORUS</b>.<br><br><b>Mnemonic: 'Carbon flies, Phosphorus lies.'</b><br><br>The <b>major reservoir of carbon on Earth is the OCEANS</b>." },
    { q: "Contrast the behaviour of ENERGY and NUTRIENTS in an ecosystem.", hint: "Flow vs cycle.", a: "<table class='cmp'><thead><tr><th>Feature</th><th>ENERGY</th><th>NUTRIENTS</th></tr></thead><tbody><tr><td>Path</td><td><b>UNIDIRECTIONAL — it FLOWS</b></td><td><b>CYCLIC — it CYCLES</b></td></tr><tr><td>Fate</td><td><b>Lost as HEAT</b> at every step</td><td><b>Reused repeatedly</b></td></tr><tr><td>Source</td><td>Must be <b>constantly resupplied by the sun</b></td><td>Drawn from a <b>reservoir</b> (atmosphere/hydrosphere or Earth's crust)</td></tr><tr><td>Recyclable?</td><td><b>NO</b></td><td><b>YES</b></td></tr></tbody></table>" },
    { q: "Define ecosystem services and give NCERT's example.", hint: "Products of processes.", a: "<b>Ecosystem services</b> are the <b>PRODUCTS OF ECOSYSTEM PROCESSES</b>.<br><br><b>NCERT's example:</b> the <b>purification of air and water by forests</b>." },
    { q: "Which is the only ecosystem on Earth not powered by the sun, and why does it matter?", hint: "Deep water.", a: "The <b>DEEP-SEA HYDRO-THERMAL ECOSYSTEM</b>.<br><br>NCERT phrases it as: '<b>Except for the deep-sea hydro-thermal ecosystem, sun is the ONLY source of energy for all ecosystems on Earth.</b>' Those vent communities run on <b>chemical energy</b> (chemosynthesis) rather than sunlight.<br><br>It matters because this exact exception is one of the most frequently asked one-liners from the chapter — questions phrased as 'the sun is the only source of energy for ALL ecosystems' are <b>FALSE</b>." },
    { q: "Fill in all five of NCERT's Exercise 1 blanks.", hint: "Producers, inverted, light, earthworms, oceans.", a: "<b>1(a)</b> Plants are called <b>PRODUCERS (autotrophs)</b> because they fix carbon dioxide.<br><b>1(b)</b> In an ecosystem dominated by trees, the pyramid (of numbers) is <b>INVERTED</b> type.<br><b>1(c)</b> In aquatic ecosystems, the limiting factor for productivity is <b>LIGHT</b>.<br><b>1(d)</b> Common detritivores in our ecosystem are <b>EARTHWORMS</b>.<br><b>1(e)</b> The major reservoir of carbon on earth is the <b>OCEANS</b>." },
    { q: "Answer NCERT Exercise Q2–Q5 with reasoning.", hint: "Producers, zooplankton, herbivores, 50%.", a: "<b>Q2. Largest population in a food chain?</b> → <b>PRODUCERS</b>. They form the base of the pyramid of numbers and support everything above.<br><br><b>Q3. The second trophic level in a lake?</b> → <b>ZOOPLANKTON</b>. Phytoplankton are the FIRST trophic level (producers).<br><br><b>Q4. Secondary producers are?</b> → <b>HERBIVORES</b>. They are the first level of consumers, and secondary productivity is the rate of formation of new organic matter by consumers.<br><br><b>Q5. Percentage of PAR in incident solar radiation?</b> → <b>50%</b>. The option '2&ndash;10%' is the trap — that is the fraction of PAR that plants CAPTURE, not the fraction of solar radiation that IS PAR." },
    { q: "Why is the pond a good teaching model, and what makes it self-sustainable?", hint: "Simple but complete.", a: "The pond is <b>fairly a self-sustainable unit</b> and a <b>rather simple example</b> that still explains even the <b>complex interactions that exist in an aquatic ecosystem</b>. It is a <b>shallow water body in which all four basic components of an ecosystem are well exhibited</b>.<br><br><b>Self-sustaining because it closes the loop:</b> autotrophs fix solar energy into organic matter → heterotrophs consume them → decomposers mineralise the dead matter → nutrients are <b>released back for reuse by the autotrophs</b> — and this repeats <b>over and over again</b>. Only ENERGY must be resupplied from outside (by the sun)." },
    { q: "List everything the 2023-24 rationalisation DELETED from this chapter.", hint: "Three big blocks.", a: "<b>DELETED:</b><br>• <b>Ecological Succession</b> — hydrarch, xerarch, pioneer species, sere, climax community.<br>• The detailed <b>CARBON cycle</b> and <b>PHOSPHORUS cycle</b> (with diagrams).<br>• <b>Ecosystem Services</b> with <b>Robert Constanza's</b> economic valuation.<br><br><b>WHAT SURVIVES (in the Summary and Exercises only):</b> the definition of nutrient cycling; the gaseous vs sedimentary distinction with carbon and phosphorus as examples; the fact that the OCEANS are the major carbon reservoir; and a one-line definition of ecosystem services (purification of air and water by forests)." },
    { q: "Why is the stratification of a forest described as 'vertical'? Give the layers.", hint: "Top to bottom.", a: "<b>Stratification</b> is the <b>VERTICAL distribution of different species occupying different levels</b> — species are layered by height, not spread horizontally.<br><br><b>Forest layers (top → bottom):</b><br>• <b>TREES</b> occupy the top vertical strata (layer)<br>• <b>SHRUBS</b> occupy the second<br>• <b>HERBS and GRASSES</b> occupy the bottom layers" },
    { q: "How is the number of trophic levels in a grazing food chain limited? Is the DFC similarly limited?", hint: "The 10% law — and think about where DFC energy comes from.", a: "In the GFC the number of trophic levels is <b>restricted by the 10 PER CENT LAW</b> — only 10% of the energy passes upward, so after four or five levels there is <b>not enough energy left</b> to support another.<br><br>The <b>DFC is not similarly restricted</b> in the same way, because it is fed by <b>detritus</b> — dead matter arriving from <b>every trophic level of the GFC simultaneously</b>, not from a single lower step. Its energy base is continually replenished from the whole system." },
    { q: "What happens to energy trapped in an organism when that organism dies?", hint: "It doesn't vanish.", a: "'<b>No energy that is trapped into an organism remains in it forever.</b>' The energy trapped by a producer is <b>either passed on to a consumer, or the organism dies</b>.<br><br>When any organism dies, it is <b>converted to DETRITUS or DEAD BIOMASS</b>, which <b>serves as an energy source for DECOMPOSERS</b>.<br><br><b>The death of an organism is the BEGINNING of the detritus food chain/web.</b>" },
    { q: "Explain the framing of an ecosystem as INPUT → TRANSFER → OUTPUT.", hint: "Three words, mapped to the four functions.", a: "<b>INPUT</b> = <b>PRODUCTIVITY</b> — the fixing of solar energy into organic matter by producers.<br><b>TRANSFER</b> = <b>FOOD CHAIN / FOOD WEB</b> and <b>NUTRIENT CYCLING</b> — energy and matter moving through the system.<br><b>OUTPUT</b> = <b>DEGRADATION (decomposition) and ENERGY LOSS</b> as heat.<br><br>This is precisely how NCERT introduces the chapter, and it maps onto the four functional components: <b>Productivity, Decomposition, Energy flow, Nutrient cycling</b>." },
    { q: "Why must ALL organisms at a trophic level be counted when constructing an ecological pyramid?", hint: "Generalisation.", a: "Because any calculation of <b>energy content, biomass or numbers must include ALL organisms at that trophic level</b>.<br><br>NCERT is explicit: '<b>No generalisations we make will be true if we take only a few individuals at any trophic level into account.</b>' Sampling a subset would distort the shape of the pyramid and invalidate any conclusion drawn from it." },
    { q: "In an aquatic ecosystem, name the producers, the primary consumers, and the second trophic level.", hint: "Careful — one word answer for the last part.", a: "<b>PRODUCERS (T1):</b> <b>phytoplankton</b>, algae and higher plants.<br><b>PRIMARY CONSUMERS (T2):</b> <b>zooplankton</b>; common aquatic herbivores also include <b>MOLLUSCS</b>.<br><b>The SECOND trophic level in a lake:</b> <b>ZOOPLANKTON</b>.<br><br><b>Trap:</b> students answer 'phytoplankton' for the second trophic level. Phytoplankton are the <b>FIRST</b>." },
    { q: "Why is a constant input of solar energy essential — why can't the ecosystem simply recycle its energy?", hint: "Second law.", a: "Because <b>energy flow is UNIDIRECTIONAL</b> and, at every transfer, <b>some energy is dissipated and lost as HEAT</b> to the environment. That heat is no longer available to do biological work — it cannot be re-fixed by a producer.<br><br>Ecosystems are <b>not exempt from the Second Law of Thermodynamics</b>: they need a <b>constant supply of energy</b> to synthesise the molecules they require and to <b>counteract the universal tendency toward increasing disorderliness</b>.<br><br><b>Nutrients cycle. Energy does not.</b>" },
    { q: "A grassland pyramid of numbers: give NCERT's exact figures and what they show.", hint: "Millions vs three.", a: "In a grassland ecosystem, an ecosystem based on the production of nearly <b>6 MILLION plants</b> supports only <b>THREE top carnivores</b>.<br><br>This is an <b>UPRIGHT pyramid of numbers</b>, and it dramatises how steeply numbers fall at successive trophic levels — a direct visual consequence of the <b>10 per cent law</b>." },
    { q: "List every 'always' and 'never' statement from this chapter.", hint: "Six of them.", a: "• Energy flow is <b>ALWAYS unidirectional</b>.<br>• The pyramid of energy is <b>ALWAYS upright — it can NEVER be inverted</b>.<br>• Energy at a lower trophic level is <b>ALWAYS more</b> than at a higher level.<br>• The sun is the <b>ONLY</b> energy source for all ecosystems — <b>EXCEPT</b> the deep-sea hydro-thermal ecosystem.<br>• All the steps of decomposition operate <b>SIMULTANEOUSLY</b> on the detritus.<br>• <b>Dry weight is ALWAYS more accurate</b> than fresh weight for measuring biomass." },
    { q: "GPP of an ecosystem is 1000 kcal m⁻² yr⁻¹ and respiration losses are 600. Find NPP, and state who it is available to.", hint: "One subtraction, then one definition.", a: "<b>NPP = GPP &minus; R = 1000 &minus; 600 = 400 kcal m<sup>&minus;2</sup> yr<sup>&minus;1</sup></b>.<br><br>This NPP is the <b>biomass available for consumption by HETEROTROPHS</b> — specifically, by <b>HERBIVORES AND DECOMPOSERS</b>.<br><br><b>Note the trap:</b> NPP is available to herbivores <b>and decomposers</b>, not to herbivores alone." }
  ],

  /* ---------- 6. QUIZ BATTLE — MCQs (106) ---------- */
  mcqs: [
    { q: "An ecosystem is best defined as:", o: ["The vertical layering of plants in a forest", "A community of plants only", "A group of organisms of the same species", "A functional unit of nature where organisms interact among themselves and with the physical environment"], c: 3, e: "It is a <b>functional unit of nature</b> — the interaction is both <b>among organisms</b> AND <b>with the physical environment</b>." },
    { q: "Which of the following is a TERRESTRIAL ecosystem?", o: ["Lake", "Estuary", "Wetland", "Grassland"], c: 3, e: "NCERT's terrestrial examples: <b>forest, grassland, desert</b>. Estuary, wetland and lake are aquatic." },
    { q: "Which of these is a MAN-MADE ecosystem?", o: ["Aquarium", "Desert", "Wetland", "Estuary"], c: 0, e: "<b>Crop fields and an aquarium</b> may be considered man-made ecosystems." },
    { q: "The vertical distribution of different species occupying different levels is called:", o: ["Zonation", "Stratification", "Standing crop", "Species composition"], c: 1, e: "<b>Stratification</b>. In a forest: trees on top, shrubs second, herbs and grasses at the bottom." },
    { q: "Identification and enumeration of plant and animal species of an ecosystem gives its:", o: ["Productivity", "Stratification", "Species composition", "Standing crop"], c: 2, e: "<b>Species composition</b> — one of the two structural features of an ecosystem." },
    { q: "Which layer of a forest do shrubs occupy?", o: ["The bottom layer", "Below the soil", "The top strata", "The second layer"], c: 3, e: "Trees = top strata; <b>shrubs = second</b>; herbs and grasses = bottom layers." },
    { q: "Which of the following is NOT one of the four functional aspects of an ecosystem?", o: ["Stratification", "Energy flow", "Productivity", "Decomposition"], c: 0, e: "<b>Stratification is a STRUCTURAL feature</b>, not a functional aspect. The four functions are productivity, decomposition, energy flow and nutrient cycling." },
    { q: "The abiotic components of an ecosystem are:", o: ["Producers, consumers and decomposers", "Air, water and soil", "Herbivores and carnivores", "Fungi and bacteria"], c: 1, e: "<b>Abiotic = inorganic materials: air, water and soil.</b> Biotic = producers, consumers, decomposers." },
    { q: "In a pond, which organisms are especially abundant at the BOTTOM?", o: ["Phytoplankton", "Free-swimming forms", "Fungi, bacteria and flagellates", "Marginal plants"], c: 2, e: "The <b>decomposers — fungi, bacteria and flagellates</b> — are especially abundant at the bottom of the pond." },
    { q: "The abiotic component of a pond includes:", o: ["Only the phytoplankton", "The zooplankton and free-swimming forms", "Only the water", "The water with dissolved inorganic and organic substances, plus the rich soil deposit at the bottom"], c: 3, e: "It includes both the <b>water with all dissolved substances</b> AND the <b>rich bottom soil deposit</b>." },
    { q: "Which of these regulates the rate of function of the entire pond?", o: ["Solar input, temperature cycle, day-length and climatic conditions", "The number of zooplankton", "The depth of the soil deposit", "The species of fungi present"], c: 0, e: "NCERT lists exactly these: <b>solar input, cycle of temperature, day-length and other climatic conditions</b>." },
    { q: "The autotrophic components of a pond include:", o: ["Fungi, bacteria and flagellates", "Phytoplankton, algae and floating/submerged/marginal plants", "Free-swimming fish", "Zooplankton and bottom dwellers"], c: 1, e: "<b>Phytoplankton, some algae, and the floating, submerged and marginal plants</b> at the edges." },
    { q: "Primary PRODUCTION is expressed in units of:", o: ["kcal only", "kg ha⁻¹ day⁻¹", "g m⁻² or kcal m⁻²", "g m⁻² yr⁻¹ only"], c: 2, e: "Production is an <b>AMOUNT</b>: g m<sup>−2</sup> (weight) or kcal m<sup>−2</sup> (energy). <b>Productivity</b> is a RATE and carries yr<sup>−1</sup>." },
    { q: "Productivity is expressed as:", o: ["tons only", "g m⁻²", "kcal m⁻²", "g m⁻² yr⁻¹ or kcal m⁻² yr⁻¹"], c: 3, e: "Productivity is a <b>RATE</b> — hence the yr<sup>−1</sup> — so that <b>different ecosystems can be compared</b>." },
    { q: "Gross Primary Productivity (GPP) is:", o: ["The rate of production of organic matter during photosynthesis", "The biomass left after respiration", "The rate of formation of organic matter by consumers", "The energy lost as heat"], c: 0, e: "GPP = the rate of production of organic matter during photosynthesis. A considerable part of it is used in <b>respiration</b>." },
    { q: "The correct formula for net primary productivity is:", o: ["NPP = GPP + R", "NPP = GPP − R", "GPP = NPP − R", "NPP = R − GPP"], c: 1, e: "<b>GPP − R = NPP.</b> Think: earn minus spend equals keep." },
    { q: "Net primary productivity is the biomass available for consumption by:", o: ["Herbivores only", "Carnivores only", "Herbivores and decomposers", "Producers"], c: 2, e: "NPP is available to <b>heterotrophs — herbivores AND decomposers</b>. 'Herbivores only' is the classic trap." },
    { q: "Secondary productivity is defined as:", o: ["GPP minus respiration", "The rate of decomposition", "The rate of production of organic matter during photosynthesis", "The rate of formation of new organic matter by CONSUMERS"], c: 3, e: "It refers to <b>consumers</b>, not producers." },
    { q: "The annual net primary productivity of the whole biosphere is approximately:", o: ["55 billion tons", "115 billion tons", "170 billion tons", "500 billion tons"], c: 2, e: "<b>~170 billion tons</b> (dry weight) of organic matter." },
    { q: "The annual net primary productivity of the oceans is approximately:", o: ["55 billion tons", "115 billion tons", "170 billion tons", "70 billion tons"], c: 0, e: "Only <b>55 billion tons</b> — despite the oceans covering ~70% of the surface." },
    { q: "Oceans occupy about what percentage of the Earth's surface?", o: ["70%", "90%", "50%", "60%"], c: 0, e: "About <b>70 per cent</b> — yet they contribute only 55 of the 170 billion tons of annual NPP." },
    { q: "The limiting factor for productivity in aquatic ecosystems is:", o: ["Carbon dioxide", "Light", "Temperature", "Oxygen"], c: 1, e: "<b>LIGHT.</b> Sunlight penetrates only a thin upper layer, so photosynthesis is confined to a shallow film of water. (NCERT Exercise 1c.)" },
    { q: "Which of these does primary productivity NOT depend on?", o: ["Availability of nutrients", "Photosynthetic capacity of plants", "Number of top carnivores", "Plant species inhabiting the area"], c: 2, e: "NCERT lists: <b>plant species, environmental factors, availability of nutrients, photosynthetic capacity</b>." },
    { q: "The earthworm is called the farmer's friend because it:", o: ["Photosynthesises in the soil", "Kills soil pathogens", "Fixes atmospheric nitrogen", "Breaks down complex organic matter and loosens the soil"], c: 3, e: "It is a <b>detritivore</b> — it fragments detritus and aerates/loosens the soil." },
    { q: "Detritus consists of:", o: ["Dead plant remains, dead animal remains AND faecal matter", "Only faecal matter", "Only dead plant remains", "Only dead animal remains"], c: 0, e: "Detritus = <b>leaves, bark, flowers + dead animal remains INCLUDING faecal matter</b>. It is the raw material for decomposition." },
    { q: "The correct sequence of steps in decomposition is:", o: ["Leaching → Fragmentation → Catabolism → Mineralisation → Humification", "Fragmentation → Leaching → Catabolism → Humification → Mineralisation", "Catabolism → Fragmentation → Leaching → Humification → Mineralisation", "Fragmentation → Catabolism → Leaching → Mineralisation → Humification"], c: 1, e: "<b>Fragmentation → Leaching → Catabolism → Humification → Mineralisation.</b> Mnemonic: 'Fresh Leaves Cook, Humus Made'." },
    { q: "Breaking down of detritus into smaller particles by detritivores is called:", o: ["Catabolism", "Leaching", "Fragmentation", "Humification"], c: 2, e: "<b>Fragmentation</b> — e.g., by the earthworm." },
    { q: "In leaching, water-soluble inorganic nutrients:", o: ["Evaporate into the atmosphere", "Are converted into humus", "Are absorbed by plants immediately", "Go down into the soil horizon and get precipitated as UNAVAILABLE salts"], c: 3, e: "The key word is <b>UNAVAILABLE</b> — leaching makes nutrients inaccessible, it does not release them." },
    { q: "Degradation of detritus into simpler inorganic substances by bacterial and fungal enzymes is called:", o: ["Catabolism", "Mineralisation", "Fragmentation", "Leaching"], c: 0, e: "<b>Catabolism</b> — driven by <b>bacterial and fungal ENZYMES</b>." },
    { q: "Humus is:", o: ["A crystalline mineral salt", "A dark-coloured amorphous substance, highly resistant to microbial action", "A rapidly decomposing sugar", "A gaseous product of decomposition"], c: 1, e: "Dark, amorphous, <b>highly resistant</b>, decomposes extremely slowly, <b>colloidal</b>, and serves as a <b>reservoir of nutrients</b>." },
    { q: "Humus serves as a reservoir of nutrients because it is:", o: ["Highly soluble", "Crystalline", "Colloidal in nature", "Gaseous"], c: 2, e: "Being <b>colloidal</b>, it holds and slowly releases nutrients." },
    { q: "The release of inorganic nutrients from humus by microbes is called:", o: ["Leaching", "Fragmentation", "Humification", "Mineralisation"], c: 3, e: "<b>Mineralisation.</b> Humification builds humus; mineralisation breaks it down and releases nutrients." },
    { q: "Which two steps of decomposition occur IN THE SOIL?", o: ["Humification and mineralisation", "Leaching and catabolism", "Fragmentation and leaching", "Catabolism and fragmentation"], c: 0, e: "NCERT: '<b>Humification and mineralisation occur during decomposition in the soil.</b>'" },
    { q: "The steps of decomposition:", o: ["Occur strictly one after the other", "All operate SIMULTANEOUSLY on the detritus", "Occur only in winter", "Occur only in anaerobic conditions"], c: 1, e: "NCERT is explicit: <b>all the steps operate simultaneously</b>." },
    { q: "Decomposition is largely a/an:", o: ["Nitrogen-requiring process", "Anaerobic process", "Oxygen-requiring process", "Light-requiring process"], c: 2, e: "Decomposition is <b>largely an OXYGEN-REQUIRING process</b>." },
    { q: "Decomposition is SLOWER if the detritus is rich in:", o: ["Water-soluble substances", "Nitrogen", "Sugars", "Lignin and chitin"], c: 3, e: "<b>Lignin and chitin</b> slow it down. <b>Nitrogen and sugars</b> speed it up." },
    { q: "Decomposition is QUICKER if the detritus is rich in:", o: ["Nitrogen and water-soluble substances like sugars", "Cellulose only", "Lignin", "Chitin"], c: 0, e: "Nitrogen and water-soluble sugars accelerate microbial breakdown." },
    { q: "The two most important CLIMATIC factors regulating decomposition are:", o: ["Light and wind", "Temperature and soil moisture", "Rainfall and altitude", "Pressure and salinity"], c: 1, e: "<b>Temperature and soil moisture</b> — through their effects on the <b>activities of soil microbes</b>." },
    { q: "Which conditions INHIBIT decomposition, causing a build-up of organic material?", o: ["Neutral pH and moderate rain", "Warm and moist conditions", "Low temperature and anaerobiosis", "High oxygen and high nitrogen"], c: 2, e: "<b>Low temperature + anaerobiosis</b> inhibit decomposition → organic material accumulates (this is how peat forms)." },
    { q: "Which ecosystem is NOT dependent on the sun as its energy source?", o: ["Desert", "Tropical rainforest", "Coral reef", "Deep-sea hydro-thermal ecosystem"], c: 3, e: "The <b>deep-sea hydro-thermal ecosystem</b> is NCERT's single stated exception." },
    { q: "What percentage of the incident solar radiation is photosynthetically active radiation (PAR)?", o: ["Less than 50%", "2–10%", "1%", "10%"], c: 0, e: "<b>Less than 50%</b> of incident solar radiation is PAR. (2–10% is the fraction of PAR that is CAPTURED — the classic trap.)" },
    { q: "What percentage of the PAR do plants actually capture?", o: ["100%", "2–10%", "25%", "50%"], c: 1, e: "Only <b>2–10% of the PAR</b> — and this small amount of energy sustains the entire living world." },
    { q: "In an ideal pyramid of energy, primary producers convert what percentage of available sunlight into NPP?", o: ["10%", "50%", "1%", "25%"], c: 2, e: "About <b>1 per cent</b>." },
    { q: "Ecosystems need a constant supply of energy in order to:", o: ["Create energy from nothing", "Reverse the flow of nutrients", "Violate the second law of thermodynamics", "Counteract the universal tendency toward increasing disorderliness"], c: 3, e: "Ecosystems are <b>not exempt</b> from the Second Law — they must fight entropy continuously." },
    { q: "The major producers in a TERRESTRIAL ecosystem are:", o: ["Herbaceous and woody plants", "Fungi and bacteria", "Zooplankton", "Phytoplankton and algae"], c: 0, e: "<b>Herbaceous and woody plants.</b> Phytoplankton/algae are aquatic producers." },
    { q: "Common herbivores in an AQUATIC ecosystem are:", o: ["Birds", "Molluscs", "Mammals", "Insects"], c: 1, e: "NCERT names <b>molluscs</b> as the aquatic herbivores; insects, birds and mammals are the terrestrial ones." },
    { q: "In NCERT's grazing food chain 'Grass → Goat → Man', Man is a:", o: ["Secondary consumer", "Decomposer", "Producer", "Primary consumer"], c: 0, e: "Grass = producer; goat = primary consumer; <b>man = secondary consumer</b>." },
    { q: "A secondary consumer is more correctly called a:", o: ["Secondary carnivore", "Producer", "Herbivore", "Primary carnivore"], c: 3, e: "Secondary <b>consumer</b> = primary <b>carnivore</b>. Tertiary consumer = secondary carnivore." },
    { q: "The detritus food chain begins with:", o: ["Dead organic matter", "Herbivores", "Sunlight", "Living green plants"], c: 0, e: "The DFC <b>begins with dead organic matter (detritus)</b>." },
    { q: "Saprotrophs are:", o: ["Herbivores", "Decomposers — mainly fungi and bacteria", "Top carnivores", "Producers"], c: 1, e: "'Sapro' = <b>to decompose</b>. They are the heterotrophic decomposers of the DFC." },
    { q: "How do decomposers obtain their nutrition?", o: ["By preying on herbivores", "By ingesting whole food particles", "By secreting digestive enzymes that break down dead material into simple inorganic materials, which they then ABSORB", "By photosynthesis"], c: 2, e: "They digest <b>externally</b> and then <b>absorb</b> the products." },
    { q: "In an AQUATIC ecosystem, the major conduit for energy flow is:", o: ["Chemosynthesis", "Leaching", "The detritus food chain", "The grazing food chain"], c: 3, e: "<b>GFC dominates in water.</b> Memory hook: 'Water grazes, Land rots.'" },
    { q: "In a TERRESTRIAL ecosystem, a much larger fraction of energy flows through:", o: ["The detritus food chain", "Photosynthesis", "The pyramid of numbers", "The grazing food chain"], c: 0, e: "<b>DFC dominates on land.</b> Most plant biomass is not eaten alive — it dies and is decomposed." },
    { q: "Which animals does NCERT name as OMNIVORES that connect the GFC and DFC?", o: ["Goats and cattle", "Cockroaches and crows", "Tigers and lions", "Earthworms and snails"], c: 1, e: "<b>Cockroaches and crows.</b> These natural interconnections make a food WEB." },
    { q: "Producers, herbivores and carnivores belong respectively to which trophic levels?", o: ["Third, second, first", "First, third, second", "First, second, third", "Second, first, third"], c: 2, e: "Producers = T1; herbivores (primary consumers) = T2; carnivores (secondary consumers) = T3." },
    { q: "A trophic level represents:", o: ["A geographical zone", "A taxonomic order", "A single species", "A functional level, NOT a species"], c: 3, e: "A <b>given species may occupy MORE THAN ONE trophic level</b> in the same ecosystem at the same time." },
    { q: "A sparrow eating insects and worms is functioning as a:", o: ["Producer", "Primary consumer", "Secondary consumer", "Decomposer"], c: 2, e: "Eating seeds/fruits/peas → primary consumer. Eating <b>insects and worms → secondary consumer</b>." },
    { q: "Standing crop is defined as:", o: ["The energy lost as heat at each trophic level", "The mass of living material at a trophic level at a particular time", "The rate of biomass production", "The number of trophic levels in a food chain"], c: 1, e: "It is a <b>snapshot of biomass (or number) per unit area</b> at one moment — not a rate." },
    { q: "Measurement of biomass in terms of DRY weight is more accurate because:", o: ["Fresh weight ignores the roots", "Dry weight is easier to measure", "Fresh weight varies with water content, which contributes no organic matter or energy", "Dry weight includes the water"], c: 2, e: "Water content fluctuates with hydration, humidity and species — it distorts comparisons." },
    { q: "According to the 10 per cent law, if producers hold 20,000 J, the energy at the THIRD trophic level is:", o: ["2000 J", "200 J", "20 J", "2 J"], c: 1, e: "T1 = 20,000 J → T2 = 2,000 J → <b>T3 = 200 J</b>." },
    { q: "The 10 per cent law explains why:", o: ["Decomposition is aerobic", "Oceans have low productivity", "Pyramids of biomass can be inverted", "The number of trophic levels in a grazing food chain is restricted"], c: 3, e: "After a few levels there simply isn't enough energy left to support another." },
    { q: "The base of an ecological pyramid represents:", o: ["Producers (the first trophic level)", "Decomposers", "Herbivores", "Top carnivores"], c: 0, e: "<b>Base = producers.</b> Apex = tertiary or top-level consumer." },
    { q: "In a grassland ecosystem, nearly 6 million plants support how many top carnivores?", o: ["3", "30", "300", "3000"], c: 0, e: "Only <b>three</b> — NCERT's Figure 12.4(a)." },
    { q: "The pyramid of NUMBERS is inverted in which ecosystem?", o: ["Grassland", "A tree ecosystem", "The sea", "A desert"], c: 1, e: "A single big <b>TREE</b> supports many insects, which support fewer birds → inverted." },
    { q: "The pyramid of BIOMASS is generally inverted in:", o: ["A forest", "A grassland", "The sea", "A crop field"], c: 2, e: "In the <b>sea</b>, the biomass of fishes far exceeds that of phytoplankton." },
    { q: "In an inverted pyramid of biomass in the sea:", o: ["There are no producers", "Energy flows upward and downward", "A large standing crop of phytoplankton supports a small standing crop of zooplankton", "A small standing crop of phytoplankton supports a large standing crop of zooplankton"], c: 3, e: "A <b>SMALL</b> phytoplankton standing crop supports a <b>LARGE</b> zooplankton standing crop." },
    { q: "Which pyramid can NEVER be inverted?", o: ["Pyramid of numbers", "Pyramid of biomass", "Pyramid of energy", "All three can be inverted"], c: 2, e: "The <b>pyramid of ENERGY is always upright</b>, because some energy is always lost as heat at each step." },
    { q: "The reason the energy pyramid is always upright is that:", o: ["Some energy is always lost as heat at each transfer", "Decomposers are excluded", "Biomass is always higher at the base", "Producers are always more numerous"], c: 0, e: "The heat loss is inescapable — energy at a lower level is <b>always</b> more than at a higher level." },
    { q: "Each bar in a pyramid of energy indicates:", o: ["The dry weight of organisms at that level", "The amount of energy present at that trophic level in a given time or annually per unit area", "The rate of decomposition", "The number of individuals at that trophic level"], c: 1, e: "Energy per unit area, per unit time." },
    { q: "Which of the following is NOT a limitation of ecological pyramids?", o: ["They assume a simple food chain and cannot accommodate a food web", "Saprophytes are not given any place", "They cannot be drawn for terrestrial ecosystems", "They do not account for a species belonging to two or more trophic levels"], c: 2, e: "The three real limitations are the <b>three S's</b>: Same species, Simple chain, Saprophytes skipped." },
    { q: "Saprophytes are:", o: ["The same as producers", "Placed at the apex of ecological pyramids", "Placed at the base of ecological pyramids", "Not given any place in ecological pyramids, despite playing a vital role"], c: 3, e: "This is one of the three stated <b>limitations</b> of ecological pyramids." },
    { q: "Nutrient cycling is defined as:", o: ["The storage and movement of nutrient elements through the various components of the ecosystem", "The loss of nutrients as heat", "The vertical layering of species", "The unidirectional flow of energy"], c: 0, e: "Through this process, <b>nutrients are used repeatedly</b> — unlike energy, which is lost." },
    { q: "The reservoir for a GASEOUS nutrient cycle is:", o: ["The Earth's crust", "The atmosphere or hydrosphere", "The soil humus", "The detritus layer"], c: 1, e: "Gaseous cycle (e.g., <b>carbon</b>) → reservoir = <b>atmosphere or hydrosphere</b>." },
    { q: "The reservoir for a SEDIMENTARY nutrient cycle is:", o: ["The atmosphere", "The hydrosphere", "The Earth's crust", "The biosphere"], c: 2, e: "Sedimentary cycle (e.g., <b>phosphorus</b>) → reservoir = <b>Earth's crust</b>. 'Carbon flies, Phosphorus lies.'" },
    { q: "Phosphorus follows which type of nutrient cycle?", o: ["Hydrological", "Atmospheric", "Gaseous", "Sedimentary"], c: 3, e: "<b>Sedimentary</b> — its reservoir is the Earth's crust." },
    { q: "The major reservoir of carbon on Earth is:", o: ["The oceans", "Fossil fuels", "The atmosphere", "Forests"], c: 0, e: "The <b>oceans</b>. (NCERT Exercise 1e.)" },
    { q: "Ecosystem services are:", o: ["The trophic levels of a food web", "The products of ecosystem processes", "The four functional components of an ecosystem", "The abiotic components"], c: 1, e: "Example given by NCERT: the <b>purification of air and water by forests</b>." },
    { q: "Which statement about energy and nutrients is CORRECT?", o: ["Both energy and nutrients cycle", "Both energy and nutrients flow unidirectionally", "Energy flows unidirectionally; nutrients cycle", "Nutrients flow unidirectionally; energy cycles"], c: 2, e: "<b>Energy FLOWS (and is lost as heat). Nutrients CYCLE (and are reused).</b> This is the single most examined idea in the chapter." },
    { q: "Plants are called producers because they:", o: ["Decompose detritus", "Store phosphorus", "Eat other organisms", "Fix carbon dioxide"], c: 3, e: "NCERT Exercise 1(a): plants are <b>producers (autotrophs)</b> because they fix CO₂." },
    { q: "Which has the LARGEST population in a food chain?", o: ["Producers", "Primary consumers", "Secondary consumers", "Decomposers"], c: 0, e: "<b>Producers</b> — they form the broad base of the pyramid of numbers. (NCERT Exercise Q2.)" },
    { q: "The SECOND trophic level in a lake is:", o: ["Phytoplankton", "Zooplankton", "Benthos", "Fishes"], c: 1, e: "<b>Zooplankton.</b> Phytoplankton are the FIRST trophic level (producers) — this is the trap." },
    { q: "Common detritivores in our ecosystem are:", o: ["Phytoplankton", "Fungi", "Earthworms", "Bacteria"], c: 2, e: "<b>Earthworms</b> — they carry out FRAGMENTATION, the first step of decomposition. (NCERT Exercise 1d.)" },
    { q: "The death of an organism marks the beginning of:", o: ["Photosynthesis", "Nutrient uptake", "The grazing food chain", "The detritus food chain/web"], c: 3, e: "Dead organisms become <b>detritus</b> — the starting point of the DFC." },
    { q: "Which statement about the amount of energy at successive trophic levels is TRUE?", o: ["It decreases", "It fluctuates randomly", "It increases", "It stays the same"], c: 0, e: "It <b>decreases</b> — 10% law. Organisms at each level depend on the level below for their energy." },
    { q: "In most ecosystems, the pyramids of number, biomass and energy are:", o: ["All inverted", "All upright", "Number inverted, others upright", "Energy inverted, others upright"], c: 1, e: "In <b>most</b> ecosystems all three are <b>upright</b>. The two exceptions are the tree (numbers) and the sea (biomass)." },
    { q: "Any calculation of energy, biomass or numbers in an ecological pyramid must:", o: ["Use fresh weight only", "Sample only the dominant species", "Include ALL organisms at that trophic level", "Exclude decomposers and juveniles"], c: 2, e: "NCERT: 'No generalisations we make will be true if we take only a few individuals at any trophic level into account.'" },
    { q: "Which is the correct relationship?", o: ["Litter and detritus are identical", "Detritus contains no faecal matter", "Litter is broader than detritus", "Detritus is broader than litter"], c: 3, e: "<b>Detritus is broader</b> — it includes dead plant remains, dead animal remains AND faecal matter. Litter (dead plant material on the soil surface) is one part of it." },
    { q: "Production and decomposition differ in that:", o: ["Production builds complex organic matter from inorganic; decomposition breaks it back down", "Both build organic matter", "Both require sunlight", "Production breaks down organic matter; decomposition builds it"], c: 0, e: "Production = photosynthesis (needs sunlight). Decomposition = breakdown (needs oxygen)." },
    { q: "Which of the following correctly describes energy flow?", o: ["Cyclic, from consumers back to producers", "Unidirectional, from the sun to producers to consumers", "Bidirectional between all trophic levels", "Random"], c: 1, e: "<b>Unidirectional.</b> All organisms depend on producers directly or indirectly, and energy is lost as heat at each step." },
    { q: "The pyramid of biomass in most terrestrial ecosystems shows:", o: ["An inverted shape", "A sharp INCREASE in biomass at higher trophic levels", "A sharp DECREASE in biomass at higher trophic levels", "Equal biomass at all levels"], c: 2, e: "NCERT Figure 12.4(b): a <b>sharp decrease</b> in biomass at higher trophic levels." },
    { q: "Which of the following pairs is CORRECTLY matched?", o: ["Leaching — release of available nutrients", "Catabolism — earthworm", "Fragmentation — bacterial enzymes", "Humification — accumulation of humus in soil"], c: 3, e: "Fragmentation → detritivores (earthworm). Catabolism → bacterial/fungal enzymes. Leaching → nutrients become <b>UNAVAILABLE</b> salts. Humification → humus accumulates in the soil. ✔" },
    { q: "An ecosystem's INPUT, TRANSFER and OUTPUT correspond respectively to:", o: ["Productivity; food web + nutrient cycling; degradation and energy loss", "Decomposition; productivity; energy flow", "Energy loss; nutrient cycling; productivity", "Stratification; species composition; productivity"], c: 0, e: "This is exactly how NCERT frames the chapter's structure." },
    { q: "Which statement about the number of trophic levels in a DETRITUS food chain is most accurate?", o: ["It is restricted by the same 10% law as the GFC", "It is not restricted in the same way, because detritus arrives from every level of the GFC", "It always has exactly three levels", "It has no trophic levels"], c: 1, e: "The DFC's energy base is <b>continually replenished by dead matter from the entire system</b>, not by a single lower step." },
    { q: "Zooplankton in a pond are:", o: ["Abiotic components", "Producers", "Consumers", "Decomposers"], c: 2, e: "<b>Consumers</b>, along with the free-swimming and bottom-dwelling forms." },
    { q: "Which of these is NOT a product of decomposition?", o: ["Carbon dioxide", "Water", "Inorganic nutrients", "Glucose"], c: 3, e: "Decomposition yields <b>CO₂, water and inorganic nutrients</b> (plus humus). Glucose is a product of <b>production</b> (photosynthesis)." },
    { q: "Which statement about GPP is TRUE?", o: ["A considerable amount of GPP is utilised by plants in respiration", "GPP is the biomass available to herbivores", "GPP is the rate of formation of organic matter by consumers", "GPP is always equal to NPP"], c: 0, e: "That respiration cost is exactly why <b>NPP = GPP − R</b>, and it is NPP (not GPP) that heterotrophs get." },
    { q: "A pyramid of numbers with a very narrow base and progressively wider levels above suggests:", o: ["A grassland ecosystem", "A tree ecosystem", "The open sea", "A desert"], c: 1, e: "One tree (narrow base) → many insects → fewer birds. This is the <b>inverted pyramid of numbers</b> in a <b>tree</b> ecosystem." },
    { q: "Which of the following statements is FALSE?", o: ["Nutrients are used repeatedly in an ecosystem", "Energy is lost as heat at each trophic transfer", "Energy can be recycled within an ecosystem", "The sun is the only energy source for almost all ecosystems"], c: 2, e: "<b>Energy can NEVER be recycled.</b> It flows unidirectionally and is dissipated as heat." },
    { q: "The rich soil deposit at the bottom of a pond is classified as:", o: ["An autotrophic component", "A consumer", "A decomposer", "An abiotic component"], c: 3, e: "It is part of the pond's <b>abiotic</b> component, along with the water and its dissolved substances." },
    { q: "Which is TRUE of the pyramid of energy in a food chain?", o: ["It is always upright", "It excludes producers", "It is measured in numbers of individuals", "It may be inverted in aquatic ecosystems"], c: 0, e: "<b>Always upright, never inverted</b> — heat loss at every step guarantees it." },
    { q: "The rate of assimilation of food energy by consumers is called:", o: ["Net primary productivity", "Secondary productivity", "Standing crop", "Gross primary productivity"], c: 1, e: "<b>Secondary productivity</b> — the rate of formation of new organic matter by consumers." },
    { q: "In the pond ecosystem, the sequence of events that repeats over and over is:", o: ["Release → conversion → decomposition → consumption", "Consumption → decomposition → conversion → release", "Conversion of inorganic to organic → consumption by heterotrophs → decomposition and mineralisation → release for reuse", "Decomposition → consumption → conversion → storage"], c: 2, e: "Autotrophs fix energy → heterotrophs consume → decomposers mineralise → nutrients released for reuse → repeat." },
    { q: "Which of the following would you find at the APEX of an ecological pyramid?", o: ["Decomposers", "Producers", "Herbivores", "The tertiary or top-level consumer"], c: 3, e: "Base = producers; <b>apex = tertiary/top-level consumer</b>." },
    { q: "NPP of the whole biosphere is ~170 billion tons and ocean NPP is 55 billion tons. Land NPP is therefore approximately:", o: ["55 billion tons", "115 billion tons", "170 billion tons", "225 billion tons"], c: 1, e: "170 − 55 = <b>115 billion tons</b>." },
    { q: "Which of the following is a correct statement about consumers?", o: ["They are heterotrophs and depend on plants directly or indirectly", "They fix carbon dioxide", "They form the first trophic level", "They are autotrophs"], c: 0, e: "Consumers = <b>heterotrophs</b>. All animals depend on plants directly or indirectly for food." },
    { q: "Which term describes the interconnection of many food chains in a natural ecosystem?", o: ["Food chain", "Food web", "Trophic level", "Standing crop"], c: 1, e: "A <b>food web</b> — created because omnivores and shared prey link chains together." }
  ],

  /* ---------- 7. MATCH-UP (70 pairs → 10 shuffled sets of 7) ---------- */
  match: [
    /* SET A — Structure */
    { term: "Ecosystem", def: "Functional unit of nature where organisms interact with each other and the physical environment" },
    { term: "Species composition", def: "Identification and enumeration of the plant and animal species of an ecosystem" },
    { term: "Stratification", def: "Vertical distribution of species at different levels" },
    { term: "Trees, shrubs, herbs and grasses", def: "Top, second and bottom strata of a forest" },
    { term: "Abiotic components", def: "Air, water and soil" },
    { term: "Biotic components", def: "Producers, consumers and decomposers" },
    { term: "Forest, grassland, desert", def: "Terrestrial ecosystems" },
    { term: "Pond, lake, wetland, river, estuary", def: "Aquatic ecosystems" },
    { term: "Crop field and aquarium", def: "Man-made ecosystems" },

    /* SET B — The pond */
    { term: "Water plus dissolved substances plus bottom soil", def: "The abiotic component of a pond" },
    { term: "Phytoplankton, algae, floating and submerged plants", def: "The autotrophic component of a pond" },
    { term: "Zooplankton, free-swimming and bottom-dwelling forms", def: "The consumers of a pond" },
    { term: "Fungi, bacteria and flagellates", def: "The decomposers of a pond, most abundant at the bottom" },
    { term: "Solar input, temperature cycle, day-length", def: "What regulates the rate of function of the entire pond" },

    /* SET C — Productivity */
    { term: "Primary production", def: "The AMOUNT of biomass produced per unit area over a time period" },
    { term: "Productivity", def: "The RATE of biomass production" },
    { term: "g per square metre per year", def: "The unit of productivity" },
    { term: "GPP", def: "Rate of production of organic matter during photosynthesis" },
    { term: "NPP", def: "GPP minus respiration losses; the biomass available to heterotrophs" },
    { term: "Secondary productivity", def: "Rate of formation of new organic matter by consumers" },
    { term: "170 billion tons", def: "Annual NPP of the whole biosphere (dry weight)" },
    { term: "55 billion tons", def: "Annual NPP of the oceans" },
    { term: "Light", def: "The limiting factor for productivity in aquatic ecosystems" },

    /* SET D — Decomposition */
    { term: "Detritus", def: "Dead plant and animal remains including faecal matter — raw material for decomposition" },
    { term: "Fragmentation", def: "Detritivores break detritus into smaller particles" },
    { term: "Leaching", def: "Water-soluble nutrients sink into the soil and precipitate as unavailable salts" },
    { term: "Catabolism", def: "Bacterial and fungal enzymes degrade detritus into simpler inorganic substances" },
    { term: "Humification", def: "Accumulation of dark, amorphous, colloidal humus in the soil" },
    { term: "Mineralisation", def: "Microbes degrade humus and release inorganic nutrients" },
    { term: "Earthworm", def: "The farmer's friend — a detritivore that fragments detritus and loosens soil" },
    { term: "Humus", def: "Highly resistant to microbial action; colloidal; a reservoir of nutrients" },
    { term: "Lignin and chitin", def: "Detritus components that SLOW decomposition" },
    { term: "Nitrogen and sugars", def: "Detritus components that SPEED UP decomposition" },
    { term: "Temperature and soil moisture", def: "The two most important climatic factors regulating decomposition" },
    { term: "Warm and moist", def: "Conditions that favour decomposition" },
    { term: "Low temperature and anaerobiosis", def: "Conditions that inhibit decomposition and cause organic build-up" },

    /* SET E — Energy flow */
    { term: "Deep-sea hydro-thermal ecosystem", def: "The only ecosystem not powered by the sun" },
    { term: "Less than 50%", def: "Fraction of incident solar radiation that is PAR" },
    { term: "2 to 10%", def: "Fraction of PAR actually captured by plants" },
    { term: "About 1%", def: "Fraction of available sunlight converted to NPP in an ideal energy pyramid" },
    { term: "10 per cent law", def: "Only a tenth of the energy passes to the next trophic level" },
    { term: "Second law of thermodynamics", def: "Why ecosystems need a constant energy supply to counteract disorderliness" },
    { term: "Herbaceous and woody plants", def: "Major producers in a terrestrial ecosystem" },
    { term: "Phytoplankton, algae and higher plants", def: "Producers in an aquatic ecosystem" },
    { term: "Molluscs", def: "Common herbivores in an aquatic ecosystem" },

    /* SET F — Food chains */
    { term: "Grass, goat, man", def: "NCERT's grazing food chain" },
    { term: "Grazing food chain", def: "Begins with living producers; the major conduit in aquatic ecosystems" },
    { term: "Detritus food chain", def: "Begins with dead organic matter; dominant in terrestrial ecosystems" },
    { term: "Saprotroph", def: "A decomposer; 'sapro' means to decompose" },
    { term: "Cockroaches and crows", def: "Omnivores that link the GFC and the DFC" },
    { term: "Food web", def: "The natural interconnection of many food chains" },
    { term: "Trophic level", def: "An organism's place in a food chain, based on its source of nutrition" },
    { term: "Sparrow", def: "Primary consumer on seeds; secondary consumer on insects and worms" },
    { term: "Standing crop", def: "Mass of living material at a trophic level at a particular time" },
    { term: "Dry weight", def: "The more accurate way to measure biomass" },

    /* SET G — Pyramids */
    { term: "Base of an ecological pyramid", def: "The producers, or first trophic level" },
    { term: "Apex of an ecological pyramid", def: "The tertiary or top-level consumer" },
    { term: "Six million plants, three top carnivores", def: "NCERT's upright grassland pyramid of numbers" },
    { term: "Inverted pyramid of numbers", def: "Found in a tree ecosystem" },
    { term: "Inverted pyramid of biomass", def: "Found in the sea — small phytoplankton crop supports large zooplankton crop" },
    { term: "Pyramid of energy", def: "ALWAYS upright — can never be inverted, because energy is lost as heat" },
    { term: "Same species in two levels; simple chain; saprophytes ignored", def: "The three limitations of ecological pyramids" },

    /* SET H — Nutrient cycling & exercises */
    { term: "Nutrient cycling", def: "Storage and movement of nutrient elements through the ecosystem; nutrients are reused" },
    { term: "Gaseous cycle", def: "Reservoir is the atmosphere or hydrosphere — e.g., carbon" },
    { term: "Sedimentary cycle", def: "Reservoir is the Earth's crust — e.g., phosphorus" },
    { term: "Oceans", def: "The major reservoir of carbon on Earth" },
    { term: "Ecosystem services", def: "Products of ecosystem processes, e.g., purification of air and water by forests" },
    { term: "Energy", def: "Flows unidirectionally and is lost as heat; can never be recycled" },
    { term: "Nutrients", def: "Cycle through the ecosystem and are used repeatedly" },
    { term: "Zooplankton", def: "The second trophic level in a lake" }
  ],

  /* ---------- 8. BUILD THE PATHWAY (9 sets) ---------- */
  pathways: [
    {
      title: "The Five Steps of Decomposition",
      prompt: "Order the steps by which detritus is converted back into inorganic nutrients. (Remember: in nature they all run simultaneously — this is the logical order.)",
      steps: ["Detritus (dead plant and animal remains + faecal matter)", "Fragmentation — detritivores break detritus into smaller particles", "Leaching — water-soluble nutrients sink into the soil horizon", "Catabolism — bacterial and fungal enzymes degrade detritus", "Humification — dark, amorphous humus accumulates in the soil", "Mineralisation — microbes degrade humus", "Inorganic nutrients released (CO2, water, nutrients)"]
    },
    {
      title: "The Energy Cascade — Sun to NPP",
      prompt: "Sequence the fate of solar energy from the moment it strikes the Earth to the moment it becomes usable plant biomass.",
      steps: ["Incident solar radiation reaches the Earth", "Less than 50% of it is photosynthetically active radiation (PAR)", "Plants capture only 2 to 10 per cent of the PAR", "Captured energy is fixed as organic matter — this is GPP", "A considerable part of GPP is burned in plant respiration (R)", "GPP minus R leaves NPP", "NPP is the biomass available to herbivores and decomposers"]
    },
    {
      title: "Trophic Levels — Base to Apex",
      prompt: "Order the trophic levels from the base of an ecological pyramid to its apex.",
      steps: ["First trophic level — Producers", "Second trophic level — Herbivores (primary consumers)", "Third trophic level — Primary carnivores (secondary consumers)", "Fourth trophic level — Secondary carnivores (tertiary consumers)"]
    },
    {
      title: "The 10 Per Cent Law — Energy Ladder",
      prompt: "Starting with 10,000 J at the producers, build the energy ladder up the grazing food chain.",
      steps: ["Producers — 10,000 J", "Herbivores — 1,000 J", "Primary carnivores — 100 J", "Secondary carnivores — 10 J", "Tertiary carnivores — 1 J (the chain runs out of energy)"]
    },
    {
      title: "The Pond — A Self-Sustaining Cycle",
      prompt: "Sequence the repeating cycle that makes the pond a self-sustainable ecosystem.",
      steps: ["Solar energy enters the pond", "Autotrophs convert inorganic material into organic material", "Heterotrophs (consumers) eat the autotrophs", "Organisms die and become dead matter", "Decomposers decompose and mineralise the dead matter", "Inorganic nutrients are released back into the water and soil", "Autotrophs reuse the nutrients — and the cycle repeats"]
    },
    {
      title: "The Detritus Food Chain (DFC)",
      prompt: "Sequence how energy moves through the detritus food chain.",
      steps: ["An organism dies, producing dead organic matter (detritus)", "Saprotrophs — mainly fungi and bacteria — colonise the detritus", "They secrete digestive enzymes onto the dead material", "Enzymes break it down into simple inorganic materials", "The decomposers ABSORB the simple materials", "Inorganic nutrients are returned to the ecosystem"]
    },
    {
      title: "The Grazing Food Chain (GFC)",
      prompt: "Build NCERT's grazing food chain with its trophic labels.",
      steps: ["Sun — the source of energy", "Grass — Producer (first trophic level)", "Goat — Primary consumer / herbivore (second trophic level)", "Man — Secondary consumer / primary carnivore (third trophic level)"]
    },
    {
      title: "The Nutrient Cycle Loop",
      prompt: "Sequence the path of a nutrient element as it cycles through an ecosystem.",
      steps: ["Nutrient sits in its reservoir (atmosphere/hydrosphere for gaseous; Earth's crust for sedimentary)", "Producers absorb and assimilate the nutrient", "The nutrient passes to consumers through the food chain", "The organism dies and becomes detritus", "Decomposition and mineralisation release the nutrient", "The nutrient returns to the soil or reservoir", "It is absorbed by producers again — nutrients are used repeatedly"]
    },
    {
      title: "From Detritus to Humus to Nutrients",
      prompt: "Trace the specific fate of a fallen leaf, from litter to released mineral nutrient.",
      steps: ["A leaf falls and joins the litter/detritus layer", "Detritivores such as earthworms fragment it", "Bacterial and fungal enzymes catabolise the fragments", "Humification converts residues into dark, amorphous humus", "Humus resists microbial action and acts as a nutrient reservoir", "Some microbes slowly degrade the humus", "Mineralisation releases inorganic nutrients for plant uptake"]
    }
  ],

  /* ---------- 9. BOSS BATTLE (27 — hard, integrative, numerical) ---------- */
  boss: [
    { q: "In an ecosystem, GPP is 1200 kcal m⁻² yr⁻¹ and respiration losses are 750 kcal m⁻² yr⁻¹. The NPP is:", o: ["1950", "750", "450", "1200"], c: 2, e: "NPP = GPP − R = 1200 − 750 = <b>450 kcal m<sup>−2</sup> yr<sup>−1</sup></b>." },
    { q: "If the producers of a grassland trap 40,000 J of energy, how much is available to a SECONDARY CARNIVORE under the 10% law?", o: ["4000 J", "400 J", "40 J", "4 J"], c: 2, e: "40,000 (T1) → 4,000 (T2, herbivore) → 400 (T3, primary carnivore) → <b>40 J (T4, secondary carnivore)</b>." },
    { q: "Assertion: The pyramid of biomass in the sea is inverted. Reason: Energy flow in the sea is reversed, moving from consumers to producers.", o: ["Both A and R are true, and R is the correct explanation", "Both A and R are true, but R is NOT the correct explanation", "A is true, R is false", "Both A and R are false"], c: 2, e: "<b>A is TRUE, R is FALSE.</b> The biomass pyramid inverts because phytoplankton have a very high turnover rate (biomass is a snapshot, not a rate). <b>Energy flow is NEVER reversed</b> — which is exactly why the ENERGY pyramid stays upright." },
    { q: "A student writes: 'Plants capture 50% of the incident solar radiation.' How many errors are in this statement?", o: ["None — it is correct", "One error", "Two errors", "Three errors"], c: 2, e: "<b>TWO errors.</b> (1) Less than 50% of incident radiation is <b>PAR</b> — it is not 'captured'. (2) Plants capture only <b>2–10% OF THE PAR</b>, not 50% of anything." },
    { q: "Which of the following statements is FALSE?", o: ["The sun is the only energy source for all ecosystems except the deep-sea hydro-thermal one", "Nutrients are used repeatedly through nutrient cycling", "Energy at a lower trophic level is always more than at a higher level", "The pyramid of energy may be inverted in aquatic ecosystems"], c: 3, e: "The <b>pyramid of ENERGY can NEVER be inverted</b> — energy is always lost as heat at each step." },
    { q: "Statement I: NPP is the biomass available for consumption by heterotrophs. Statement II: Heterotrophs here means only herbivores.", o: ["Only I is correct", "Only II is correct", "Both I and II are correct", "Neither is correct"], c: 0, e: "<b>Only I.</b> NCERT specifies the heterotrophs as <b>herbivores AND DECOMPOSERS</b>. Forgetting decomposers is the single most common NPP error." },
    { q: "Match: (i) Fragmentation (ii) Catabolism (iii) Mineralisation. Who performs each?", o: ["Bacterial enzymes; detritivores; water", "Water; microbes; earthworms", "Microbes; earthworms; fungal enzymes", "Detritivores; bacterial/fungal enzymes; microbes degrading humus"], c: 3, e: "Fragmentation → <b>detritivores (earthworm)</b>. Catabolism → <b>bacterial and fungal ENZYMES</b>. Mineralisation → <b>microbes degrading humus</b>, releasing inorganic nutrients." },
    { q: "Oceans cover ~70% of the Earth's surface but produce only 55 of the biosphere's ~170 billion tons of annual NPP. The BEST explanation is:", o: ["Light penetrates only a thin upper layer, so photosynthesis is confined to a shallow film of water", "Ocean temperatures are too low for photosynthesis", "There are no producers in the ocean", "Ocean water lacks carbon dioxide"], c: 0, e: "<b>LIGHT is the limiting factor</b> in aquatic ecosystems. (Nutrient scarcity in open-ocean surface waters compounds it.)" },
    { q: "Which combination is entirely CORRECT?", o: ["GFC dominates terrestrial; DFC dominates aquatic", "GFC dominates aquatic; DFC dominates terrestrial", "GFC and DFC dominate equally in both", "Neither GFC nor DFC operates in aquatic ecosystems"], c: 1, e: "<b>'Water grazes, Land rots.'</b> GFC is the major conduit in AQUATIC ecosystems; a much larger fraction of energy flows through the DFC in TERRESTRIAL ecosystems." },
    { q: "A pyramid of numbers is drawn for a single large tree, the insects feeding on it, the small birds eating the insects, and the larger birds eating the small birds. Its shape is:", o: ["Perfectly upright", "Inverted at the base, then narrowing", "A perfect rectangle", "Inverted throughout"], c: 1, e: "One tree → thousands of insects (widens), then fewer small birds, then fewer large birds (narrows). The base is <b>inverted</b>. This is why the pyramid of numbers is not always reliable." },
    { q: "Assertion: A trophic level is a functional level, not a species. Reason: A sparrow can be a primary consumer and a secondary consumer in the same ecosystem at the same time.", o: ["Both A and R are true, and R is the correct explanation", "Both A and R are true, but R is NOT the correct explanation", "A is true, R is false", "A is false, R is true"], c: 0, e: "Both true, and the sparrow is precisely NCERT's illustration of why a trophic level is a <b>function, not a species</b>." },
    { q: "Which of the following is NOT a limitation of ecological pyramids?", o: ["They cannot accommodate a food web", "They do not account for a species occupying two trophic levels", "Saprophytes are given no place", "They cannot be expressed in terms of energy"], c: 3, e: "Ecological pyramids <b>can</b> be expressed in terms of energy — that is one of the three types. The other three options are the real limitations (the three S's)." },
    { q: "An ecosystem's detritus is rich in lignin and chitin, and the climate is cold and waterlogged. What will happen?", o: ["Decomposition will be strongly inhibited, causing a build-up of organic material", "Decomposition rate will be unaffected", "Humification will be skipped", "Extremely rapid decomposition"], c: 0, e: "<b>Both</b> factors slow it: lignin/chitin resist breakdown, and <b>low temperature + anaerobiosis (waterlogging)</b> inhibit microbial activity → <b>organic material accumulates</b>. This is how peat bogs form." },
    { q: "Which sequence correctly ranks these energy figures from largest to smallest?", o: ["Energy transferred per trophic level > PAR in solar radiation > PAR captured by plants", "PAR in solar radiation > PAR captured by plants > sunlight converted to NPP", "PAR captured by plants > PAR in solar radiation > energy transferred per trophic level", "PAR in solar radiation > energy transferred per trophic level > PAR captured by plants"], c: 1, e: "<b>PAR ≈ 50% > PAR captured 2–10% > sunlight converted to NPP ≈ 1%.</b> (The 10% law describes transfer BETWEEN trophic levels, not solar capture — do not mix it in.)" },
    { q: "In a lake, if phytoplankton are the first trophic level, then benthic detritivores feeding on dead phytoplankton belong to:", o: ["The first trophic level", "The pyramid of energy only", "The grazing food chain", "The detritus food chain"], c: 3, e: "They feed on <b>dead organic matter</b> → they are part of the <b>DETRITUS food chain</b>, not the GFC." },
    { q: "Which statement about standing crop is CORRECT?", o: ["It is a snapshot of biomass or number at a particular time", "It always increases at higher trophic levels", "It is best measured in fresh weight", "It is a rate, measured per year"], c: 0, e: "<b>Standing crop is a snapshot — not a rate.</b> That distinction is the key to resolving the inverted-biomass paradox. And <b>dry weight</b> is the more accurate measure." },
    { q: "GPP = 100 units. Respiration = 60 units. Herbivores consume the entire NPP but assimilate only 10% of it. Secondary productivity is:", o: ["10 units", "6 units", "4 units", "40 units"], c: 2, e: "NPP = 100 − 60 = <b>40</b>. Herbivores assimilate 10% of 40 = <b>4 units</b>." },
    { q: "Which pair is INCORRECTLY matched?", o: ["Sedimentary cycle — reservoir in the Earth's crust", "Carbon — sedimentary cycle", "Phosphorus — sedimentary cycle", "Gaseous cycle — reservoir in the atmosphere or hydrosphere"], c: 1, e: "<b>Carbon follows a GASEOUS cycle</b>, not a sedimentary one. 'Carbon flies, Phosphorus lies.'" },
    { q: "Why can the DFC support more trophic transfers than the GFC seems able to?", o: ["Because decomposers photosynthesise", "Because energy flows backwards in the DFC", "Because decomposers violate the 10% law", "Because detritus arrives continually from EVERY trophic level of the GFC, not from a single lower step"], c: 3, e: "The DFC's energy base is <b>continually replenished from the whole system</b> — dead matter from producers, herbivores and carnivores alike." },
    { q: "In a pyramid of energy, if the producers' bar reads 1,000,000 kcal m⁻² yr⁻¹, the herbivore bar reads approximately:", o: ["1,000,000", "100,000", "10,000", "1,000"], c: 1, e: "10% law: <b>100,000 kcal m<sup>−2</sup> yr<sup>−1</sup></b>." },
    { q: "Which is the CORRECT statement about the second law of thermodynamics and ecosystems?", o: ["Ecosystems obey it, and therefore need a constant energy supply to counteract increasing disorderliness", "It explains why nutrients cannot be recycled", "It permits energy to be recycled indefinitely", "Ecosystems are exempt from it"], c: 0, e: "Ecosystems are <b>NOT exempt</b>. Entropy is why energy must be constantly resupplied by the sun — and why energy can never cycle." },
    { q: "Which of the following, taken together, correctly describes decomposition?", o: ["Anaerobic; five steps occurring sequentially; slowed by nitrogen", "Aerobic; five steps operating simultaneously; slowed by lignin and chitin", "Aerobic; three steps occurring sequentially; slowed by sugars", "Anaerobic; two steps; accelerated by chitin"], c: 1, e: "<b>Largely oxygen-requiring; ALL steps operate simultaneously; lignin and chitin slow it; nitrogen and sugars speed it up.</b>" },
    { q: "A forest converts CO₂ into biomass and also purifies air and water. The purification is an example of:", o: ["Primary productivity", "Nutrient cycling", "An ecosystem service", "Secondary productivity"], c: 2, e: "<b>Ecosystem services</b> = the products of ecosystem processes. NCERT's exact example is the purification of air and water by forests." },
    { q: "Which of these figures is CORRECTLY paired with what it describes?", o: ["170 billion tons — annual NPP of the land alone", "6 million — top carnivores supported in a grassland", "3 — plants in a grassland pyramid of numbers", "55 billion tons — annual NPP of the oceans"], c: 3, e: "Grassland: <b>~6 million plants</b> support <b>3 top carnivores</b>. Biosphere NPP = <b>170</b> billion tons total; <b>oceans = 55</b>; land = the remaining ~115." },
    { q: "Why does an inverted pyramid of BIOMASS not violate the laws of thermodynamics?", o: ["Because biomass is a standing crop (a snapshot), while energy flow is a rate — phytoplankton turn over extremely fast", "Because decomposers add energy to the system", "Because the sun contributes energy directly to fish", "Because energy can flow backwards in aquatic systems"], c: 0, e: "Phytoplankton are produced and eaten within hours to days, so their total annual production is enormous even though very little stands around at any instant. <b>Energy still flows correctly downhill.</b>" },
    { q: "In NCERT's list, which of the following is NOT one of the four functional components of an ecosystem?", o: ["Nutrient cycling", "Species composition", "Decomposition", "Productivity"], c: 1, e: "<b>Species composition is a STRUCTURAL feature</b> (with stratification). The four FUNCTIONAL components are productivity, decomposition, energy flow and nutrient cycling." },
    { q: "A given ecosystem shows an upright pyramid of numbers, an inverted pyramid of biomass, and an upright pyramid of energy. Which ecosystem is it most likely to be?", o: ["A grassland", "A tropical forest", "The sea", "A desert"], c: 2, e: "<b>The SEA.</b> Phytoplankton are numerous (upright numbers) but have a tiny standing crop (inverted biomass); the energy pyramid, as always, stays upright." }
  ]
};
